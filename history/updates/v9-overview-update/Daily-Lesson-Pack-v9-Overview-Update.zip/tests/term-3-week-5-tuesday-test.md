# Test Plan — Term 3 Week 5 Tuesday

## Lookup result

- Day: Tuesday
- Mathematics topic: Equivalent fractions
- WA code: WA4MNAUN7
- Mathematics focus: Generate equivalent fractions by multiplying the numerator and denominator by the same whole number.
- Writing toolkit: Elaboration with supporting details
- Writing focus: Explicitly teach how to expand a simple factual sentence into a developed paragraph.
- Shared Reading: Costa Rica (North America)
- Guided Reading: Barbados (North America)
- Guided Reading group: Low group
- HASS: excluded

## Progression decision

The previous scheduled lesson is assumed completed because no contrary status
has been supplied. The plan advances to the scheduled Tuesday focus.

## Required resource intent

### Mathematics

Teach **Equivalent fractions**, not a substitute topic.
Use models and symbols that support this focus. Task representations must remain
incomplete until students act; answers must show the requested reasoning.

### Writing

Teach **Elaboration with supporting details**.
The lesson must produce direct evidence of this toolkit component rather than a
generic country-research activity.

### Shared Reading

Create an original whole-class information text about
**Costa Rica**. Use it to teach comprehension and an
information-text feature relevant to the writing toolkit.

### Guided Reading

Create a separate text about **Barbados**, pitched to the
**Low group**. Include teacher questions and expected
responses.

### Independence check

Morning Work must use neither Costa Rica nor
Barbados and must not pre-teach either reading passage.

## Test verdict

PASS — the lookup provides a coherent, non-duplicated plan with the correct
mathematics progression, writing-toolkit stage, country allocations and guided
reading group.

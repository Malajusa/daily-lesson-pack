# Daily Lesson Pack v9 Overview Update

This patch extends Daily Lesson Pack v8. It does not remove the v8 rules.

## Mandatory term-overview reference

For Term 3 Year 4/5 daily packs, read both:

- `references/term-3-four-day-overview.md`
- `references/term-3-four-day-overview.json`

Use the JSON for deterministic term/week/day lookup and the Markdown file for explanatory planning rules.

The overview applies to Monday, Tuesday, Thursday and Friday. Wednesday is outside the overview unless the user explicitly requests it.

## Default progression

Assume the previous scheduled lesson was taught and sufficiently completed unless the user explicitly states otherwise.

- Monday normally follows the preceding Friday.
- Tuesday follows Monday.
- Thursday follows Tuesday.
- Friday follows Thursday.
- Missing lesson-status data is not evidence that a lesson was missed.
- Do not repeat, delay, consolidate or reteach merely because status is absent.
- Apply an explicit user or status exception when one exists.

## Mathematics authority

The weekly mathematics topic and WA code in the overview are authoritative.

The day-level lesson focus must advance through the specified four-day arc. Do not replace the topic with a representation used to teach it.

Before generating mathematics resources, confirm:

1. correct term, week and day;
2. correct weekly topic and WA code;
3. correct day-level focus;
4. continuity from the previous scheduled lesson;
5. task slides do not reveal answers;
6. answer slides model the strategy requested in the task.

## Information-report writing toolkit

Writing is planned as a cumulative toolkit for producing an information report.

Each week has one toolkit component. The daily pattern is:

- Monday: analyse and introduce the component;
- Tuesday: explicitly teach it;
- Thursday: apply it in drafting or revision;
- Friday: edit, consolidate or publish it.

Every writing lesson must:

- name the toolkit component;
- explicitly teach or apply that component;
- show a model or worked example when needed;
- require a student product that demonstrates the component;
- avoid replacing writing instruction with country-fact collection;
- build towards an independently written information report.

HASS is not generated from this overview.

## Country-based reading

Shared Reading and Guided Reading use original texts about countries in Europe, Africa, North America or South America.

Any country from those continents is suitable.

For each day:

- use the overview's assigned country when one is specified;
- Shared Reading and Guided Reading must use different countries;
- Morning Work must use a third, independent passage or context;
- do not lightly simplify the Shared Reading text for Guided Reading;
- do not repeat the same information sequence across the texts.

Shared Reading is a whole-class comprehension and information-text lesson.

Guided Reading must match the fixed group:

- Monday: very low;
- Tuesday: low;
- Thursday: above level;
- Friday: approximately Year 9 level.

Each Guided Reading resource must include a student text, teacher prompts, expected responses, vocabulary support, literal comprehension, inference and an appropriate extended response.

## Pre-export stop check

Do not export when any item below fails:

- The term/week/day lookup matches the overview.
- Wednesday has not been inserted without an explicit request.
- The mathematics focus matches the overview.
- The writing focus matches the scheduled toolkit component and daily stage.
- The Shared and Guided Reading countries differ.
- The Guided Reading level matches the day.
- Morning Work, Shared Reading and Guided Reading are independent.
- No HASS lesson or HASS printable has been generated from this overview.
- Previous lessons were assumed complete unless an explicit exception says otherwise.

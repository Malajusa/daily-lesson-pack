# SKILL.md insertion — Term 3 Four-Day Overview

Add `references/term-3-four-day-overview.md` and
`references/term-3-four-day-overview.json` to the Required References list.

Insert the following workflow step after resolving the target date:

> For Term 3, resolve the week and day from
> `references/term-3-four-day-overview.json`. Use its mathematics topic,
> WA code, day-level mathematics focus, information-report toolkit focus,
> Shared Reading country and Guided Reading country/group as mandatory
> planning inputs. Apply explicit user exceptions, but do not silently
> substitute another sequence.

Insert the complete rules from `PATCH-NOTES-v9.md` after the v8
`Passage Independence` section and before `Missing Information`.

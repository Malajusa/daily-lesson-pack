# Source Index Addendum — v9

## Authoritative current sources

1. User instruction in the current conversation.
2. Explicit lesson-status exception, when present.
3. Authoritative timetable and calendar.
4. `references/term-3-four-day-overview.json` for Term 3 week/day lookup.
5. `references/term-3-four-day-overview.md` for explanatory overview rules.
6. Existing Daily Lesson Pack v8 references and curriculum sources.

## Superseded planning behaviour

Do not use a generic five-day weekly sequence for this Term 3 overview.
Do not generate Wednesday planning unless explicitly requested.
Do not generate HASS from this overview.
Do not treat missing status as a reason to repeat the prior lesson.

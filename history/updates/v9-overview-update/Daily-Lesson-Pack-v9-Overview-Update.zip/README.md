# Daily Lesson Pack v9 Overview Update

This package is an update layer for the existing Daily Lesson Pack v8 skill.

## Contents

- `PATCH-NOTES-v9.md` — mandatory new planning rules.
- `SKILL-INSERTION-v9.md` — precise insertion instructions for SKILL.md.
- `references/term-3-four-day-overview.md` — human-readable overview.
- `references/term-3-four-day-overview.json` — deterministic planning lookup.
- `references/source-index-v9-addendum.md` — source hierarchy update.
- `tests/term-3-week-5-monday-test.md` — Monday planning test.
- `tests/term-3-week-5-tuesday-test.md` — Tuesday planning test.

The package does not reconstruct missing v8 reference files. It is designed to
be merged with the current v8 skill package.

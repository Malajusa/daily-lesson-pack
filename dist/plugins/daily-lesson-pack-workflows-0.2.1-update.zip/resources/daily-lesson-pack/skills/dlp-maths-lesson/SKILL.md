---
name: dlp-maths-lesson
description: Generate the main Daily Lesson Pack Mathematics teaching sequence using the universal Mathematics instruction canon, explicit mathematical language, verified representations and aligned independent evidence.
---

# DLP Mathematics Lesson

## Interactive Mathematics lessons

When adapting or auditing an existing browser/app lesson bank, read
`references/interactive-maths-lessons.md` before authoring. Use its authored
teaching contract, problem-first state review and four separate QA verdicts.
The application mode retains the application build/acceptance workflow; it does
not claim complete-pack release or require a fictional timetable/PPTX.

## Mandatory evidence workflow (v3)

Read `references/qa-workflow-v3.md` and the applicable entries in
`references/qa-requirements.json` before generation or review. This workflow
governs release evidence and supersedes older run-ID-only independence checks
and report-only release commands below. Use `scripts/content_source.py` for
canonical task text and complete review coverage. Required checks cannot be
replaced by a broad component PASS. Only the complete-pack release command may
authorise classroom-ready output.

## Resolved instructional preferences

Read `references/creator-settings-contract.md` and use the orchestrator's frozen
`instructional_calibration` when present. Do not independently reload or save
private settings, change the requested warm-up count, or infer student attainment
from enrolment year. Legacy inputs use the documented public defaults, not hidden
chat memory. Existing final-artifact and independent-review gates still apply.

## Ownership

Own the main Mathematics lesson. Do not absorb the cumulative Mathematics warm-up into this sequence.

The Mathematics warm-up is retrieval. The main lesson owns prerequisite checking, explicit teaching, guided practice, independent application and exit evidence for the scheduled lesson focus.

## Mandatory references

Before planning or generating the lesson, read and apply:

- `references/year-level-context-contract.md`;
- the active year-level profile supplied by the orchestrator;
- `references/universal-maths-instruction-canon.md`;
- `references/fraction-equivalence-standard.md` when equivalence or fraction-decimal conversion is taught;
- `references/slide-deck-quality-standards.md`;
- `references/semantic-colour-standard.md`;
- `references/panel-containment-standard.md`.
- `references/strategic-animation-standard.md`.

The universal Mathematics canon is the authoritative pedagogical and mathematical-communication standard for this component. The active year-level profile controls developmental pitch, expected prior knowledge, reasonable number types/magnitudes, scaffolding and demand. The user's current overview controls what is being taught now.

A current explicit user instruction may alter the lesson mode, slide count, context or representation, but it does not override mathematical accuracy, truthful representation or answer integrity.

Do not use another year profile's calibration merely because its examples are available. In particular, do not create Year 6 difficulty by mechanically enlarging Year 4/5 numbers, text length or step count.

## Internal planning contract

Before creating student-facing content, complete the planning contract required by the universal Mathematics canon:

1. active year-level profile and profile version/status;
2. curriculum concept and boundary;
3. lesson mode;
4. one central new idea, or `none` for review/assessment;
5. prerequisite knowledge to retrieve;
6. quantities, units, properties, structures or relationships students must notice;
7. what changes and what remains invariant;
8. technical vocabulary and notation;
9. selected representation or representations and why each is useful;
10. principal anticipated misconception;
11. highest independent demand;
12. aligned exit evidence.

Keep this planning record internal or teacher-facing. Do not place planning metadata on student slides.

Also receive one unique timetable `instance_id`, available minutes and purpose.
When the same day has two Mathematics blocks, plan and report both instances
separately. Use a visible resume/breakpoint slide or heading so the second block
does not disappear inside one undifferentiated sequence.

## Topic integrity and scope

Identify the actual mathematical concept before choosing a representation. A number line, fraction wall, array, graph or diagram may support the topic but must not silently become the lesson topic.

For overview-controlled days, the weekly Mathematics topic/code and day-level focus must agree with the authoritative current user/school overview for the active class/year level.

Unless the lesson is explicitly review, consolidation or extension, introduce one central new mathematical idea. Do not combine several substantial new concepts merely because they share a broad topic label.

Classify the lesson as one primary mode:

- concept introduction;
- procedure development;
- fluency development;
- reasoning;
- problem solving;
- review/assessment.

Use the mode to determine the balance of explanation, modelling, guidance and independent work. Do not apply an identical `I do / We do / You do` ratio to every lesson.

## Mathematics slide clarity standard

Every student-facing Mathematics task must communicate:

- the **action** students take;
- the **mathematical focus**;
- any required **representation/resource**;
- the expected **student output**.

Each slide must stand alone well enough that a relief teacher and a student operating at the intended profile can determine what is required.

Avoid vague conversational shorthand. Do not use phrases such as `Does it settle it?`, `useful form`, `efficient proof` or similar wording that requires students to infer the mathematical decision. State the decision literally.

Use precise technical vocabulary with a plain-language explanation. Do not replace terms such as `factor`, `product`, `numerator`, `denominator`, `fractional unit`, `interval`, `axis`, `sample space`, `expression` or `equation` with vague substitutes when the technical term is required.

## Meaning before procedure

For any newly introduced method, establish the mathematical meaning before presenting procedural steps.

The explanation must identify the relevant quantities, units, relationships, what changes and what remains invariant. A mnemonic may support later recall but must not replace the explanation.

Do not make procedural shortcuts such as `borrow`, `move the decimal`, `keep the bottom number`, `flip and multiply`, `length times width` or `move it across and change the sign` the primary teaching explanation. Where such language is useful after meaning is established, connect it explicitly to the underlying mathematics.

## Teaching sequence

Keep cumulative retrieval, prerequisite checking and new teaching distinct.

For a new or fragile concept, use this default sequence:

1. focused prerequisite check;
2. explicit establishment of the concept and relationship;
3. one complete teacher model from start to finish;
4. immediate check for understanding;
5. unresolved `We do` / guided example;
6. guided practice with fading scaffolds;
7. independent application at a modelled demand;
8. reasoning, application or exit evidence measuring the intended concept.

Calibrate the amount of scaffolding, independent load and reasoning demand to the active year-level profile rather than to historical examples from another class.

### Respond to demonstrated understanding

Read `examples/benchmarks/maths-demand-progression-regression.md` when planning
or reviewing demand. Use a concise opening probe of the **intended learning**
as well as any prerequisite check; one task may serve both if it exposes both.
An easier prerequisite alone cannot show whether the planned teaching is needed.
Collect independent responses: speed or vocal confidence alone does not establish
readiness for a group or the class.

In the existing teacher briefing/notes name the evidence, teacher action,
destination task ID/final slide and skipped models for each conditional route:

- **Support:** teach the identified difficulty, then independently recheck a
  fresh task before fading support.
- **Normal teaching:** model/guided work addresses what the opening reveals.
- **Advance:** skip already demonstrated work and use a prepared unfamiliar or
  constrained task. Keep enough connected mathematics available for the block.

For mixed readiness make concurrent support and advancement usable without the
teacher inventing resources. Do not turn routes into permanent groups or infer
readiness from enrolment. Each substantial task needs a stated added demand or
justified practice purpose, plausible duration, hints and exact teacher answers
or valid-solution criteria. Record task IDs before assembly and actual slide
destinations afterwards. Do not allocate long practice to copying established
solutions.

Check immediate understanding, mixed readiness and initial difficulty before
returning the component. Use a fresh aligned exit application. Review
`MATHS.OPENING.DIAGNOSTIC`, `MATHS.TASK.PROGRESSION`,
`MATHS.ADVANCE.ROUTE` and `MATHS.TASK.SUFFICIENCY` under
`references/release-boundaries.json`; every scheduled block needs its own evidence.

Do not treat a token warm-up as prerequisite teaching.

During concept introduction or procedure development, students should make an observable response after no more than two consecutive explanation/model slides unless an explicit current instruction or active profile requires another structure.

A `We do` slide must require student participation. It must not already show the completed answer, final landing point, completed model or all working.

## Mathematical representations

Before drawing, define what the representation must prove or show and why that representation is suitable.

Verify all relevant quantities, labels, scales, intervals, partitions, coordinates, dimensions, geometric properties, graph values and sample-space outcomes.

A visual, verbal explanation and equation shown together must describe the same quantities, units and relationships. Make the correspondence explicit rather than assuming students will infer it.

Use the minimum number of representations needed to establish understanding. Each additional representation must add mathematical meaning.

Photographs may establish context but must not function as mathematical models unless their quantity, partition, scale and perspective are exact. Prefer flat, editable diagrams when decorative perspective or shadows could obscure equality, scale or correspondence.

When colour identifies corresponding quantities or meaningful changes, maintain the same colour relationship across the representation, language and notation. Do not rely on colour alone.

## Question and answer architecture

Before building each worked model, record its entry state, meaningful click
stages, native target IDs, retained working, prediction prompts and final state.
Use on-click Appear within the same slide by default where staging supports the
reasoning; use Disappear only for a meaningful removal. Keep exact quantities
and invariants at every stage. Do not depend on sshow or substitute transitions
and duplicated slides. Apply the standard's export and playback checks to the
final assembled file; disclose unavailable playback truthfully.

Task slides must not reveal the answer through completed working, answer-coloured objects, final landing points, completed models or teaching-only cues.

Answer slides must:

- answer the exact task;
- model the requested strategy or representation;
- show sufficient working or reasoning;
- fulfil every requested action such as explain, compare, justify, label, prove, draw or write an equation;
- acknowledge alternative valid methods or answers where relevant;
- place the primary answer in bold or otherwise visually dominant form;
- highlight meaningful mathematical changes rather than adding only a tick.

If the prompt asks students to explain with a model, a verbal answer without the model fails.

## Model-to-practice alignment

Compare the hardest independent task with the teaching sequence before release.

Independent work must not introduce an unmodelled conceptual demand. An unfamiliar
application of established concepts can require independent strategy selection:
alignment does not require demonstrating every solution pathway or supplying a
nearly identical example. Identify connected extension and provide optional hints;
teach genuinely new concepts/representations before treating them as secure
independent work. Check alignment in:

- concept;
- operation or relationship;
- representation;
- number type and magnitude;
- number of steps;
- strategy selection;
- language demand;
- reasoning demand;
- expected output.

When independent work includes more than one operation or method at a given level of complexity, model each at that complexity first unless one is explicitly labelled as extension.

The active year-level profile sets the reasonable ceiling for independent demand; an extension should not automatically become next-year content.

## Variation, misconceptions and task types

Sequence examples using purposeful variation. Change one mathematically important feature at a time unless deliberately testing transfer.

Where a concept is defined by properties or boundaries, use a carefully selected example and non-example when this will clarify the distinction.

When including a misconception, use plausible student reasoning for the active year-level profile. The answer should identify the mistaken assumption, the mathematical property or relationship it violates, the correct reasoning and a supporting representation where useful.

Distinguish task type accurately:

- calculation applies a known process;
- reasoning explains, compares, justifies, classifies, generalises, proves or evaluates;
- problem solving requires students to determine useful mathematics and construct a pathway.

A routine worded calculation is not automatically problem solving.

## Established fraction requirements

For fraction comparison, explicitly teach strategy selection where relevant: same denominator, same numerator, equivalence, benchmark to one-half, distance from one, and mixed/improper representation. Explain when a method is inconclusive.

When teaching fraction operations, identify the fractional unit and explain how the numerator counts units. Do not make `add/subtract the top numbers and keep the bottom number` the primary explanation.

Apply only those fraction demands that are appropriate to the current lesson focus and active year-level profile.

When converting equivalent fractions to tenths or hundredths, apply
`references/fraction-equivalence-standard.md`. Show the original partition, the
repartitioning of every part, the same invariant amount and the multiplicative
change to numerator and denominator. A finished hundred grid alone is not an
explanation of equivalence.

## Differentiation

Differentiate through representation, scaffold, reasoning, abstraction, strategy selection and context—not only by assigning more questions.

State the common central idea and use task-specific readiness evidence to select
conditional support, prerequisite intervention, independent practice and connected
challenge. Enrolment year is not evidence of readiness. With no observations,
provide a diagnostic check and conditional teacher responses; do not invent groups.
Supported success requires an independent recheck before support is faded.
Do not replace year streams with permanent Support/Core/Challenge membership.
Apply the frozen instructional_calibration supplied by the orchestrator; creator
retrieval defaults are an emphasis, not a ceiling or a student attainment claim.

Do not define higher attainment as completing the same task with more working or checking. Where students choose between levels, each task must be a complete mathematical task at a different level of complexity rather than a different completeness standard for one question.

## Component acceptance result

Before returning the component for assembly, record `PASS` or `FAIL` and substantiate these checks:

- active year profile resolved and matched to the orchestrator;
- no cross-year calibration leakage;
- planning contract completed;
- timetable instance and time budget verified;
- lesson mode and central idea controlled;
- prerequisite retrieval distinct from the warm-up;
- meaning established before procedure;
- representation selected for a stated mathematical purpose;
- representation exactness verified;
- representation/language/notation correspondence verified;
- task-specific readiness checks and conditional support/challenge verified;
- technical vocabulary verified;
- guided-practice answer withheld;
- hardest independent demand matched to a modelled precursor and active profile;
- answer slides fulfil every task requirement;
- exit evidence measures the intended concept;
- rendered readability, semantic colour and panel containment passed.

Use the stable audit IDs required by `component-instance-contract.md`:
`MATHS.PLANNING`, `MATHS.REPRESENTATION.PURPOSE`,
`MATHS.REPRESENTATION.EXACTNESS`, `MATHS.DIFFERENTIATION`,
`MATHS.POINT_OF_NEED`, `MATHS.READINESS.CHECK`,
`MATHS.MODEL_PRACTICE`, `MATHS.EXIT` and `VISUAL.READABILITY`.
Add `MATHS.BLOCK.BREAKPOINT` when the day contains multiple Mathematics
instances and `MATHS.FRACTION.REPARTITIONING` when the fraction-equivalence
standard applies. Every check cites specific planning evidence, slides or notes.

A missing check, unsupported `PASS` or unresolved defect is a component failure.

## QA

Fail the component if:

- the active year-level profile is missing, unresolved or inconsistent with the orchestrator;
- content relies on another year profile's calibration without explicit authorisation;
- instructions are ambiguous;
- lesson scope combines several unplanned new concepts;
- two scheduled Mathematics blocks are collapsed into one unmarked instance;
- estimated teaching time exceeds the timetable block;
- a procedure is taught without mathematical meaning;
- the representation changes the mathematical focus;
- a diagram or model is mathematically inaccurate;
- an equivalence lesson shows only a final decimal grid without the repartitioning relationship;
- support or challenge is assigned from enrolment year or invented ability membership;
- a decorative image is used as mathematical evidence;
- a visual, explanation and equation do not correspond;
- a `We do` or task slide reveals the answer;
- an answer does not model the requested method or representation;
- independent work introduces an unmodelled demand;
- independent demand is inappropriate for the active year profile;
- technical vocabulary is vague or inaccurate;
- a misconception is implausible or diagnostically useless for the active profile;
- a task labelled reasoning/problem solving is only routine calculation;
- the exit check measures only the representation rather than the concept;
- a valid alternative answer is rejected without a stated restriction;
- the rendered slide is unreadable, visually misleading or poorly contained.

Use `examples/benchmarks/universal-maths-canon-regression.md` whenever a change affects Mathematics pedagogy, representations, task architecture or QA. Test at least two different concept families and fail the change if improvement in one area breaks another.

Use `examples/benchmarks/year-profile-isolation-regression.md` whenever a shared Mathematics rule or a year profile changes in a way that can alter mathematical pitch.

---
name: daily-lesson-pack
description: Use when creating, revising or reviewing a teacher’s timetable-aligned Daily Lesson Pack, including individual daily teaching components, Python-entry-script requests and authorised interactive Mathematics lesson adaptations.
---

# Daily Lesson Pack — Orchestrator

## Interactive Mathematics lessons

When adapting or auditing an existing browser/app lesson bank, read
`references/interactive-maths-lessons.md` before authoring. Use its authored
teaching contract, problem-first state review and four separate QA verdicts.
The application mode retains the application build/acceptance workflow; it does
not claim complete-pack release or require a fictional timetable/PPTX.

## Mandatory evidence workflow (v3)

Read `references/qa-workflow-v3.md` and the applicable entries in
`references/qa-requirements.json` before generation or review. This workflow
governs release evidence and supersedes older run-ID-only independence checks
and report-only release commands below. Use `scripts/content_source.py` for
canonical task text and complete review coverage. Required checks cannot be
replaced by a broad component PASS. Only the complete-pack release command may
authorise classroom-ready output.

## Mandatory supported generation path

Daily Lesson Pack generation must use the repository-owned build and release
pipeline. The supported finalisation entry point is
`scripts/build_daily_pack.py`; it validates and stages the canonical artefact set
and delegates release to the repository-owned final audit.

- Do not substitute an ad-hoc `python-pptx`, PptxGenJS, LibreOffice or other
  independent presentation generator for the repository workflow.
- The repository-owned deck builder is `scripts/dlp_deck/` (CLI:
  `scripts/dlp_deck_cli.py`; guide: `references/deck-renderer.md`). Build every
  teaching deck from a spec through it: it measures text, sizes panels to their
  content, refuses content that does not fit at the role floor, renders every
  slide and inspects the render. It is part of the repository workflow, not a
  substitute for it. Do not hand-place shapes or set sizes to "make it fit".
- If direct cross-skill invocation is unavailable, execute the bundled component
  contracts and produce canonical context, component and content records before
  assembly. Generic generation is not an authorised fallback.
- A request for “PowerPoint as a Python script” changes the requested interface,
  not the Daily Lesson Pack workflow. Any Python entry script must invoke
  `scripts/build_daily_pack.py` / the repository runtime rather than recreate
  lesson authoring, layout rules or QA independently.
- Before presenting any deck, run `python scripts/dlp_deck_cli.py check` (or
  `build_deck_artifact` in governed mode), then open the contact sheet and the
  individual slide PNGs and fix the **spec** until the inspector passes and the
  slides read well. If LibreOffice or PyMuPDF is unavailable, say the deck is
  unverified; never describe an unrendered deck as checked.
- A generated deck without complete independent release evidence is a
  **candidate** only and may be supplied only when explicitly labelled
  unreleased / review-pending.
- Describe a deck as released or classroom-ready only when
  `scripts/audit_release_bundle.py` records PASS for the same deck and manifest
  hashes that are being delivered. A model assertion, a neighbouring PASS file
  or an earlier pack's release decision is not release evidence.

## Executable agent orchestration (v2, opt-in host interface)

For hosts providing structured agent executions, use `scripts/agent_orchestrator.py`
and `skills/registry.v2.json` above the supported build/release pipeline. The
operator guide is `docs/AGENT-ORCHESTRATION.md`. Keep `skills/registry.json` as the
compatible skill-discovery interface; it does not control v2 execution.

The host resolves timetable/curriculum facts before `scripts/build_execution_plan.py`
freezes the source-hashed context. Python owns dependency barriers, ownership,
required checks, cumulative attempt budgets, same-hash QA and release eligibility.
Repeated timetable blocks remain separate instances. Mathematics needs an
explicit independent critic before assembly. QA is explicitly invoked, never
implicitly selected or replaced by a generator's PASS assertion.

The host adapter supplies actual execution receipts, raw transcripts and a
trusted ContentSource-based assembly command. No provider or general lesson
renderer is auto-configured. `--stop-after components` returns validated canonical
records only, never a released pack. Any content repair invalidates all applicable
pack QA. Missing/malformed reviews, exhausted budgets or ambiguous defects leave
an unreleased result. Existing context/component schema 2, content/manifest schema 3
and the repository release authority remain unchanged.

## Creator defaults and real saved settings

Read `references/creator-settings-contract.md` before resolving preferences.
Automatically load `config/creator-defaults.json` and any authenticated host's
configured private classroom settings; do not ask the creator to select a preset.
The orchestrator CLI supports a private `settings` binding and source-backed
current `instructional_overrides`. Clear ongoing changes are saved only through
`scripts/teacher_context_store.py` after actual teacher authority, revision checks
and a successful read-after-write. Never claim that a transient session is durable
storage or that a proposal has been saved. Unsupported/ambiguous scope is not
silently made permanent. Generators and reviewers cannot mutate this store.

Freeze the resolved calibration and project it to every specialist. Main Year 5
direction and Year 3/4 retrieval are configurable creator defaults, not student
placements. A timetable, current lesson focus or attainment still needs evidence.
The sidecar and narrow candidate-status guards do not install or activate a host.

## Purpose

Apply `references/strategic-animation-standard.md` to projected models and
explanations. Route reveal planning to component owners and preserve native
within-slide timing during assembly. Maintain component question/answer pairs,
static print views and final-file evidence. Do not assume sshow is required.
No animation instruction waives the supported build or independent QA workflow.

Coordinate a classroom-ready daily pack. Do not generate detailed subject content in this skill when a specialised component skill owns it.

The orchestrator owns:
- active year-level profile resolution;
- date, term, week and timetable resolution;
- separation of year-level context from teacher/school runtime context;
- source hierarchy and progression decisions;
- specialist-subject exclusions;
- component routing;
- cross-component consistency;
- final assembly, briefing and print plan;
- release only after `dlp-pack-qa` passes.

The specialised skills own the pedagogy, wording and slide rules for their component, interpreted through the active year-level profile.

## Request routing

### Daily pack

Use this orchestrator for a named day's Daily Lesson Pack. Resolve the active year profile and runtime teacher context, invoke the required components, assemble them, then run independent QA.

### Component-only request

When the user asks for one named Daily Lesson Pack component, use the **component-only** path. Resolve the shared context needed by that component, create only the requested component instance, and invoke its owning specialist. Set the frozen run context `request_scope` to `component-only` and set `required_artifacts` to the artefacts actually requested or required by that component; a deck-only component request must not acquire a full-pack briefing merely because Daily Pack normally includes one. On the executable orchestration path use `--stop-after components`.

Do not assemble or release a full Daily Lesson Pack, and do not generate unrelated components merely because they normally appear on the same day. A component-only result remains subject to its owning component contract and release boundary; complete-pack release evidence must not be implied when full-pack assembly and QA did not run.

### Existing-pack audit or revision

Route the supplied Daily Lesson Pack directly through `dlp-pack-qa`. If it fails, send each defect only to the owning component skill, revise that component, rebuild the affected artefact, and re-run the complete applicable QA suite.

### Weekly Mathematics pack

A complete Term/Week Mathematics pack belongs to the standalone `weekly-maths-pack` skill. Route the request there rather than rebuilding weekly Mathematics logic inside this Daily Lesson Pack orchestrator. If direct skill routing is unavailable, use the standalone Weekly Maths Pack contract supplied in the environment; do not duplicate its full rules here.

## Context architecture

Before resolving a pack, read all three:

- `references/year-level-context-contract.md`;
- `references/shared-class-context-contract.md`;
- `references/term-week-day-planning-contract.md`.

They serve different purposes and must not be collapsed. The term/week/day
contract governs how a selected maintained Level A/Level B plan becomes the
requested Level C day plan; it does not replace the year profile or the actual
timetable.

### Year-level contextual base

The active year-level profile defines stable developmental and curriculum-facing calibration: expected prior knowledge, language load, reasonable task demand, independence, scaffolding and year-appropriate misconceptions/representations.

Supported year profiles must be explicitly authored under `references/year-level-profiles/`
and registered in `references/year-level-profiles/registry.json`. The runtime,
profile audit and package builders validate that registry against the exact
profile sources. Read its subject coverage and maturity alongside the profile;
coverage describes system capability, never a learner ceiling or placement.
Do not silently approximate an unsupported year by reusing another profile.

Current profiles include:

- `year-4-5` — established calibrated baseline;
- `year-6` — isolated calibration scaffold; follow its release-status rules until mature.

### User/school runtime context

The teacher supplies or connects the current timetable, Maths/English overviews,
current sequence, maintained term/week planning where selected, interruptions,
class/output constraints and lesson-status exceptions. These determine **what is
being taught now and when**, not the definition of the year level.

A user's timetable, class size or overview must never be copied into a year-level
profile merely because it was used to generate a pack.

### Term → Week → Day planning hierarchy

When the current run explicitly selects a maintained plan, apply
`references/term-week-day-planning-contract.md`.

- **Level A — Term overview** owns term scope, curriculum mapping, assessment
  timing and major constraints.
- **Level B — Weekly teaching overview** owns the timetable-agnostic ordered
  lesson sequence for the selected week.
- **Level C — Daily plan** maps the next applicable Level B lessons onto the
  actual timetable and expands them through the owning component skills.

For the creator's maintained 2026 Term 4 Year 4/5 plan, the repository source is
`planning/2026/term-4/` and the plan ID is
`2026-t4-year-4-5-room-11`. Use it only when the current request or an
authoritative maintained class context selects that plan. Its presence in the
package does not make it a universal Year 4/5 default and does not authorise its
use for another teacher/class.

A Level C generator may elaborate pedagogy, examples, resources, warm-ups,
printables and slide treatment, but it must not silently replace the selected
Level B lesson focus with another topic.

## Source hierarchy

Read `references/shared-class-context-contract.md`,
`references/term-week-day-planning-contract.md`,
`references/default-pack-profile.json` and
`references/component-instance-contract.md` before resolving a daily pack.
They define the reproducible pack defaults, required day inputs, maintained
planning resolution, instance-level timetable model and memory-independence
boundary.

Use sources in this order:

1. the user's current explicit instruction;
2. an authoritative lesson-status exception for the selected sequence;
3. the selected maintained Level B weekly teaching overview;
4. the selected maintained Level A term overview and other current-run
   user/school planning sources;
5. the actual timetable and interruptions for Level C placement/time feasibility;
6. the active year-level profile for developmental/curriculum pitch;
7. bundled universal component-skill defaults and instructional canons.

When no maintained Level A/B plan is selected, current-run timetable, overviews,
unit plans and explicit day-level focus remain the lesson-planning sources under
the existing runtime-context rules.

For **current lesson focus and local sequencing**, a selected weekly overview or
the user's current overview/program outranks the year-level profile. The actual
timetable constrains placement and available time; it does not silently rewrite
the selected weekly sequence.

For **developmental pitch**, the active year-level profile outranks historical examples from another year level or class.

Do not use chat memory, saved personal context, another account's Project context or an unstated standing preference as evidence for timetable facts, lesson focus, progression, copy quantity or classroom routines. A remembered detail may identify a question to ask, but it must not silently supply the answer. The repository package plus current-run sources must be sufficient to reproduce the pack in a clean account.

Assume the previous scheduled lesson was covered sufficiently to advance unless an authoritative runtime source explicitly records partial completion, cancellation or reteaching. Missing status is not evidence that a lesson was missed.

If a user's overview defines only some weekdays, do not invent the missing day's focus from another day or another user's historic sequence. Use the requested teacher's explicit day-level focus or another authoritative current-run source.

The school calendar is not a planning source for this skill. Do not infer school dates or timetable events from calendar lookups. Explicit requested verification is a separate task and does not silently alter the supplied timetable.

## Year-profile isolation rule

Apply changes at the narrowest justified scope.

- A Year 6 calibration correction belongs in `references/year-level-profiles/year-6.md` unless evidence shows it is universal.
- A Year 4/5 calibration correction belongs in `references/year-level-profiles/year-4-5.md` unless evidence shows it is universal.
- A teacher/school preference belongs in runtime context unless deliberately promoted after broader validation.
- A truly universal pedagogy, QA or rendering improvement belongs in the relevant shared component/core contract.

Year-level profiles are protected baselines, not immutable files. Deliberate improvements are allowed. Cross-year drift is not.

When a shared/core change could affect task demand, language, assumed prior knowledge or scaffolding, apply `examples/benchmarks/year-profile-isolation-regression.md` before release.

## Mandatory visual exemplar

For every teaching deck, read `references/visual-exemplar-standard.md` and use
`assets/visual-exemplars/t3w6-tuesday-edited-visual-exemplar.pptx` as the
approved **visual-only** design source. Verify its SHA-256 before use. Preserve
its role-colour grammar, full-height left rail, compact eyebrow/title hierarchy,
primary/secondary panel structure, Trebuchet MS typography and efficient use of
the 16:9 canvas.

`scripts/dlp_deck/` encodes this grammar (theme `dlp`, frame `rail`, profile
`classroom`); the exemplar remains the visual authority, and the renderer's
output must still be compared with it at full size. The `green`/`navy` themes,
`header` frame and `staff` profile exist only for non-lesson decks and are not
valid for a Daily Lesson Pack release.

Do not inherit the exemplar's lesson wording, year-level pitch, sequencing errors or superseded pedagogy. The current orchestrator, active year profile, component contracts, Mathematics canon and regression records remain authoritative for content.

For Morning Work specifically, also read
`examples/benchmarks/t3w8-wednesday-morning-work-exemplar.md` and use
`assets/visual-exemplars/t3w8-wednesday-morning-work-exemplar.pptx` as the
teacher-approved component exemplar. Its checksum, approved characteristics
and content-firewall rules are defined in that benchmark.

## Mandatory Mathematics canon

For every main Mathematics lesson, `dlp-maths-lesson` must read and apply `references/universal-maths-instruction-canon.md` before generation. For fraction equivalence or fraction-decimal conversion, it must also apply `references/fraction-equivalence-standard.md`. The component must complete the canon's internal planning contract and substantiate its Mathematics acceptance checks before assembly.

Mathematics warm-ups and Morning Work apply the canon's mathematical-accuracy, terminology, representation, question/answer and answer-integrity rules while remaining retrieval tasks rather than new teaching.

The universal Mathematics canon does not replace the active year profile or visual standards. Mathematics content must pass the year-level calibration, mathematical-instruction canon and shared projected-readability, semantic-colour and panel-containment standards.

## Scope boundary

Art, Japanese, Science, Music and Physical Education are specialist-led under the current core contract. Name their timetable block only unless the user explicitly supplies another authorised component contract. Do not generate lessons, slides, printables, answers, contingencies, preparation tasks or status capture for them by default.

`Student guided learning` is teacher-supervised but has no standing Daily Lesson Pack sequence. Name the block unless an authoritative current plan identifies the activity.

HASS requires a separate authoritative HASS plan or an explicit current user instruction. Do not invent HASS from reading contexts.

## Component routing

Route to these skills when the component is required:

- `dlp-morning-work`
- `dlp-literacy-warmup`
- `dlp-shared-reading`
- `dlp-guided-reading`
- `dlp-writing-lesson`
- `dlp-numeracy-warmup`
- `dlp-maths-lesson`
- `dlp-pack-qa`

If direct cross-skill invocation is unavailable, read and execute the corresponding bundled contract at `skills/<skill-name>/SKILL.md`. This fallback is mandatory; never silently substitute generic generation.

Every content-component handoff must include:

- `active_year_profile`;
- profile path/version/status;
- current lesson focus from runtime sources;
- curriculum boundary where available;
- relevant timetable/time constraint;
- explicit user overrides;
- source provenance required for QA.

## Orchestration workflow

1. Load creator defaults and configured private settings, apply source-backed current overrides, and resolve the active registered profile without asking for a preset.
2. Load the matching registered profile under `references/year-level-profiles/`. Use its registered status and revision; a caller cannot promote a scaffold to calibrated. If no supported profile exists, mark year profile `unresolved` and block classroom-ready release rather than borrowing another profile.
3. Resolve exact date, term, week, day, timetable and interruptions from the current run's supplied sources.
4. If a maintained Level A/B plan is explicitly selected, resolve the requested
   week and next applicable lesson focus under
   `references/term-week-day-planning-contract.md`: apply any authoritative
   lesson-status exception first, then Level B, then Level A, and map the result
   onto the actual timetable. Otherwise resolve Maths and English/literacy
   sequence, day-level focus and status exceptions from the user's current
   overview/unit sources as before.
5. Record the selected Level A file, Level B file, timetable source and any
   status exception in source provenance. Missing status means no exception; it
   is not evidence that teaching was missed or that learning was mastered.
6. Verify and load the approved visual-only exemplar.
7. Build one shared context object containing only information the components need: active year profile/path/status, pack profile, runtime source provenance, lesson focus, curriculum boundary, authorised local allocation, time available and output constraints. Record each scheduled block as a unique instance under `references/component-instance-contract.md`.
8. Prepare an instance-level time and slide budget before generation. Include response, discussion, transition and resource-handling time. If the estimate exceeds the timetable allocation, reduce scope or ask for a decision; do not build an overfull deck.
9. Route each required instance to its specialised skill and require an evidence-bearing component acceptance result before assembly. Repeated owners are valid when instance IDs differ. For `dlp-maths-lesson`, require the universal Mathematics planning contract, active profile and canon checks in the evidence.
10. Record schema-v2 scheduled instances, a generation run ID and each instance's `PASS` or `FAIL`, active year profile, estimated minutes, stable check IDs, concrete evidence and artefact/slide range. After assembly, bind the unchanged evidence record to the assembled deck SHA-256. A freeform assertion is not evidence.
11. Block assembly until every scheduled content instance records `PASS`. This gate does not replace independent final QA.
12. Keep Morning Work, Literacy warm-up and Shared Reading distinct. Represent Guided Reading only according to its current component contract.
13. Keep the Mathematics warm-up separate from prerequisite checking and the main Mathematics lesson.
14. Assemble components in timetable order. Slide 1 is Morning Work when required. Mark resumptions after timetable breaks visibly.
15. Create only useful printables. Prefer books, mini-whiteboards, oral work and manipulatives when a worksheet adds no value and those modes are authorised by runtime context.
16. Create the teacher briefing and any weekly printing plan from the actual generated resources and current-run quantities.
17. Send the complete assembled pack, context-source record, active year-profile record, presentation-audit evidence and component-acceptance record to `dlp-pack-qa`.
18. If QA returns FAIL, route each defect only to its owning component, revise, and rerun the full applicable suite.
19. Release only after repository-owned contract and year-profile audits, warning dispositions, independent semantic review and independent rendered visual review pass for the same deck hash and the active year profile's release requirements are satisfied.

If actual printing is requested and copy quantity cannot be resolved from an authoritative runtime source, treat quantity as unresolved rather than inventing it.

If any required runtime input in `references/shared-class-context-contract.md` is unresolved, ask one concise question and block classroom-ready release. Do not use remembered context to fill the gap.

If the active year-level profile itself is marked calibration/candidate-only, generated output may be reviewed and refined, but must not be labelled as an established classroom-ready baseline until the profile's release conditions are met.

## Cross-component invariants

- Every content component uses the same active year-level profile as the orchestrator.
- Morning Work and Shared Reading must not reuse the same passage.
- Literacy warm-up uses 10 self-contained `Reminder -> Question -> Answer` sequences unless the user changes the count. A question must not depend on remembered content from another slide.
- Guided Reading follows its own current component contract and authorised schedule; never infer ability labels from the year profile.
- Numeracy warm-up uses 5 `Question -> Answer` pairs (10 slides total) under the default pack profile. Each question slide contains separate All, Most and Some tasks.
- Shared Reading must alternate each paragraph-and-question slide with its immediately following matched answer slide; answers are not revealed early on question slides.
- The writing lesson teaches the current writing focus resolved from the selected
  weekly plan or the user's current overview; a historical class genre or weekday
  progression is not a universal default.
- Student-facing instructions must state the action, mathematical/literacy focus, any required representation or resource, and the expected student output where applicable.
- When a task transforms supplied language, name the exact operation. For example, say `Combine the two sentences using the conjunction “because”`, not merely `Write a sentence`.
- Student-facing task language must be understandable within the active year profile. Accurate technical terminology is retained and explained rather than replaced by vague substitutes.
- Teacher preparation, timing, misconceptions and answers belong in the briefing or notes, not as clutter on student task slides.
- Warm-up slides use the established projected-readability and semantic-colour standards.
- Every meaningful Numeracy warm-up task/answer is at least 36 pt; substantive `Why` text is at least 28 pt. Compliance is assessed per text element, not by the largest text on the slide.
- No generic whiteboard footer is required unless the user explicitly requests one. The Mathematics green `Why` panel is instructional content, not a generic footer instruction.
- The main Mathematics lesson must apply the complete universal Mathematics canon, including meaning before procedure, purposeful representation, genuine guided practice, model-to-practice alignment and complete answer modelling.
- Mathematics uses a shared central idea, task-specific readiness checks, conditional support and connected challenge. Enrolment year alone cannot assign a pathway; absent learner evidence remains unknown. Prior supported success requires an independent recheck before support is faded.
- Two Mathematics timetable blocks require two unique instances and a visible breakpoint. A final hundred grid alone cannot explain fraction equivalence; show repartitioning and the invariant amount.
- Mathematics warm-ups and Morning Work must remain retrieval while still using exact mathematics, precise terminology and non-revealing question slides.
- A Mathematics question requiring a model, explanation, comparison, justification, proof, label or equation must have an answer slide that demonstrates every requested element.

## Assembly outputs

Daily mode normally produces:
- one coherent teaching deck;
- only necessary student printables;
- separate teacher answers where useful;
- a concise daily briefing;
- a weekly printing plan when requested/applicable and supported by current-run quantities.

For a relief day, keep the timetable but make teacher-led sequences self-contained: explicit materials, scripts, answers, stopping points and independent alternatives. Keep teacher-facing preparation out of Morning Work.

## Release rule

The orchestrator never self-certifies quality. `dlp-pack-qa` is the release authority.
Execute it in a fresh reviewer agent/process under the v3 workflow; reading its
instructions in the generator thread is not independent QA.

Run the deterministic contract audit during final QA:

`python scripts/audit_pack_contract.py --deck <deck> --context-record <context.json> --component-record <record.json> --out <report.json>`

Run the profile-isolation audit against the same inputs and deck:

`python scripts/audit_year_profile_context.py --deck <deck> --context-record <context.json> --component-record <record.json> --out <year-profile-report.json>`

If the user explicitly changes a warm-up count, also pass `--literacy-count <n>` or `--numeracy-count <n>` with the authorised count.

Run the projected-readability and panel-containment audits on the final deck:

Read `examples/projected-readability-regression.md`,
`examples/semantic-colour-regression.md` and
`examples/panel-containment-regression.md` when generating or reviewing teaching
slides. Use their concrete failure cases alongside the controlling standards;
illustrative ranges never override a component's current release boundaries.

- `python scripts/audit_slide_typography.py --deck <deck> --dispositions <warning-ledger.json> --out <report.json>`
- `python scripts/audit_panel_containment.py --deck <deck> --out <report.json>`
- `python scripts/audit_visual_exemplar.py --deck <deck> --review-record <visual-review.json> --out <report.json>`

Aggregate both contract reports and all presentation/review reports with
`scripts/audit_release_bundle.py`. Do not create a
deck-specific release script containing expected slide counts or exact answer
strings. Any automated warning without a slide-specific, evidence-bearing
disposition remains a release failure.

Apply the existing classroom-feedback regression records whenever the affected components change. Treat those records as approved Year 4/5 benchmarks where their content is Year 4/5-specific; do not use them as Year 6 pitch sources.

Apply `examples/benchmarks/memory-independent-wednesday-regression.md` whenever context routing, source precedence, overview handling, timetable resolution or packaging changes.

Apply `examples/benchmarks/year-profile-isolation-regression.md` whenever year-profile routing, a year profile, or a shared rule that can affect pitch changes.

For any change affecting Mathematics pedagogy, representations, task architecture or QA, also apply `examples/benchmarks/universal-maths-canon-regression.md` to at least two different concept families before release.

Apply `examples/benchmarks/t3w7-thursday-known-failure.md` whenever scheduling,
Numeracy count, mixed-year Mathematics, fraction equivalence, typography,
warning handling or release certification changes.

Apply `examples/benchmarks/t3w8-tuesday-bypass-known-failure.md` whenever routing,
generation entry points, packaging, component acceptance, presentation QA or
release certification changes. A request for a Python-generated PowerPoint does
not waive the repository runtime, timetable/context provenance or release gates.

Any audit or applicable regression failure blocks release.

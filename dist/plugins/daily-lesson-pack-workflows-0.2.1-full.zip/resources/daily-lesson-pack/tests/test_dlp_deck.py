"""Tests for the supported deck renderer (scripts/dlp_deck).

Render-level tests need LibreOffice; they are skipped (not passed) when it is
missing so a host without it cannot mistake a skipped check for a pass.
"""
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

try:
    import pymupdf as fitz  # noqa: E402
except ImportError:  # PyMuPDF < 1.24.3
    import fitz  # noqa: E402
from pptx import Presentation  # noqa: E402
from pptx.util import Inches, Pt  # noqa: E402

from dlp_deck import DeckBuilder, LayoutError, engine, inspect_deck, metrics, render, tokens  # noqa: E402
from dlp_deck.assembly import build_deck_artifact  # noqa: E402
from dlp_deck.engine import Band, Block, PanelSpec  # noqa: E402
from pack_evidence import audit_pack, digest  # noqa: E402

HAVE_SOFFICE = shutil.which("soffice") is not None or shutil.which("libreoffice") is not None
needs_render = unittest.skipUnless(HAVE_SOFFICE, "LibreOffice (soffice) is required for render-level tests")


def blk(style, text, **kw):
    return Block(style, metrics.plain_paras(text), text, **kw)


def run_audit(script, deck, out):
    res = subprocess.run([sys.executable, str(ROOT / "scripts" / script), "--deck", str(deck), "--out", str(out)],
                         capture_output=True, text=True)
    return res.returncode, json.loads(Path(out).read_text())


class TokenTests(unittest.TestCase):
    def test_every_theme_pair_meets_contrast(self):
        for name, theme in tokens.THEMES.items():
            for role, c in theme["roles"].items():
                self.assertGreaterEqual(tokens.contrast(c["ink"], c["fill"]), 4.5, f"{name}/{role} ink on fill")
                if role != "dark" and c["ink"] != "FFFFFF":
                    self.assertGreaterEqual(tokens.contrast(c["accent_text"], c["fill"]), 4.5, f"{name}/{role} accent on fill")
                    self.assertGreaterEqual(tokens.contrast(c["accent_text"], theme["bg"]), 4.5, f"{name}/{role} accent on bg")
            self.assertGreaterEqual(tokens.contrast(theme["band_ink"], theme["band"]), 4.5, name)
            self.assertGreaterEqual(tokens.contrast(theme["band_kicker"], theme["band"]), 4.5, name)
            self.assertGreaterEqual(tokens.contrast(theme["ink"], theme["bg"]), 7.0, name)

    def test_dlp_theme_matches_approved_exemplar_colours(self):
        roles = tokens.THEMES["dlp"]["roles"]
        self.assertEqual((roles["amber"]["fill"], roles["amber"]["strong"]), ("FFF3BF", "D6A900"))
        self.assertEqual((roles["blue"]["fill"], roles["blue"]["strong"]), ("EAF2F8", "005A9C"))
        self.assertEqual((roles["green"]["fill"], roles["green"]["strong"]), ("EAF7EE", "1B7F3A"))
        self.assertEqual(roles["neutral"]["fill"], "FFFFFF")
        self.assertEqual(tokens.FONT, "Trebuchet MS")

    def test_classroom_floors_match_standard(self):
        c = tokens.PROFILES["classroom"]
        self.assertGreaterEqual(c["warmup_main_floor"], 36.0)
        self.assertGreaterEqual(c["ranges"]["support"][0], 28.0)
        self.assertGreaterEqual(c["ranges"]["label"][0], 22.0)
        self.assertGreaterEqual(c["ranges"]["body"][0], 24.0)


class MetricsTests(unittest.TestCase):
    def test_emphasis_never_changes_visible_text(self):
        text = "The bird uses its beak to crack the seed."
        paras = metrics.plain_paras(text, emphasis=[{"text": "beak", "scale": 1.3}])
        self.assertEqual(paras[0].text, text)
        self.assertEqual(len(paras[0].runs), 3)

    def test_wider_box_never_adds_lines(self):
        paras = metrics.plain_paras("A subject-specific noun gives the reader a clearer picture than a vague noun.")
        lines = [metrics.measure(paras, 32, w).n_lines for w in (3, 4, 5, 6, 8, 11)]
        self.assertEqual(lines, sorted(lines, reverse=True))

    def test_hyphen_is_a_break_opportunity(self):
        paras = metrics.plain_paras("subject-specific")
        wide = metrics.measure(paras, 48, 11.0).n_lines
        narrow = metrics.measure(paras, 48, 3.3).n_lines
        self.assertEqual(wide, 1)
        self.assertEqual(narrow, 2)

    def test_no_break_space_keeps_text_together_and_matches_space_width(self):
        self.assertEqual(metrics.char_width("\u00a0"), metrics.char_width(" "))
        lines = [l for p in metrics.measure(metrics.plain_paras("4,300 + 600 =\u00a0____"), 36, 3.2, default_bold=True).paras
                 for l in p.lines]
        self.assertEqual(lines[-1], "=\u00a0____")

    def test_bold_is_wider(self):
        self.assertGreater(metrics.text_width_pt("Instructional", 30, bold=True), metrics.text_width_pt("Instructional", 30))

    @needs_render
    def test_model_never_under_predicts_rendered_lines(self):
        import random
        random.seed(11)
        words = "the bird uses its beak to crack seed because leaves tilt towards light subject-specific noun hundreds regroup coaching evidence".split()
        cases = []
        prs = Presentation()
        prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
        from dlp_deck import pptx_writer as W
        for _ in range(18):
            size = random.choice([22, 28, 32, 36])
            width = random.choice([4.5, 6.0, 8.0, 11.0])
            bold = random.choice([False, True])
            text = " ".join(random.choice(words) for _ in range(random.randint(5, 14))).capitalize() + "."
            slide = prs.slides.add_slide(prs.slide_layouts[6])
            tb = W.add_textbox(slide, 0.5, 0.5, width, 6.0, name="t")
            W.style_text_frame(tb.text_frame, anchor="top")
            W.fill_paragraphs(tb.text_frame, metrics.plain_paras(text), size_pt=size, bold=bold, color="000000", accent_color="000000", align="l")
            cases.append((text, size, width, bold))
        with tempfile.TemporaryDirectory() as td:
            deck = Path(td) / "calib.pptx"
            prs.save(deck)
            pdf, _ = render.render_pdf(deck, Path(td) / "out")
            doc = fitz.open(pdf)
            for (text, size, width, bold), page in zip(cases, doc):
                bases = set()
                for b in page.get_text("rawdict")["blocks"]:
                    for line in b.get("lines", []):
                        for span in line["spans"]:
                            for ch in span["chars"]:
                                bases.add(round(ch["origin"][1]))
                rendered, last = 0, -99
                for b in sorted(bases):
                    if b - last > size * 0.5:
                        rendered += 1
                    last = b
                predicted = metrics.measure(metrics.plain_paras(text), size, width - 2 * tokens.FRAME["text_inset_in"],
                                            default_bold=bold).n_lines
                self.assertGreaterEqual(predicted, rendered, f"model under-predicted lines for {text!r} at {size} pt")


class EngineTests(unittest.TestCase):
    REGION = (0.62, 1.38, 12.08, 5.58)

    def test_fits_and_uses_largest_sensible_size(self):
        bands = [Band([PanelSpec("a", "blue", [blk("main", "The bird uses its ____ to crack the seed.")])])]
        sol = engine.solve(bands, self.REGION)
        self.assertTrue(sol.ok)
        self.assertEqual(sol.sizes["main"], tokens.PROFILES["classroom"]["ranges"]["main"][1])

    def test_never_shrinks_below_floor_and_reports_failure(self):
        bands = [Band([PanelSpec("a", "blue", [blk("body", "word " * 300)])])]
        sol = engine.solve(bands, self.REGION)
        self.assertFalse(sol.ok)
        self.assertEqual(sol.failure.code, "content_does_not_fit_at_floor_size")
        self.assertGreater(sol.failure.required_h_in, sol.failure.available_h_in)
        self.assertEqual(sol.sizes["body"], 28.0)

    def test_warmup_main_never_below_36(self):
        bands = [Band([PanelSpec("a", "blue", [blk("main", "Solve it. " * 14)])])]
        sol = engine.solve(bands, self.REGION, warmup=True)
        self.assertTrue(sol.ok)
        self.assertGreaterEqual(sol.sizes["main"], 36.0)

    def test_siblings_share_one_size_and_hierarchy_is_kept(self):
        tiers = [PanelSpec(f"t{i}", "blue", [blk("label", "ALL"), blk("question", text)])
                 for i, text in enumerate(["4,300 + 600 = ____", "4,320 + 680 = ____ and show the jump", "43,200 + 6,800 = ____"])]
        why = PanelSpec("why", "green", [blk("support", "Why do we regroup ten hundreds?")])
        sol = engine.solve([Band(tiers), Band([why])], self.REGION, warmup=True)
        self.assertTrue(sol.ok)
        sizes = {pb.block.text: pb.size_pt for pp in sol.panels for pb in pp.blocks if pb.block.style == "question"}
        self.assertEqual(len(set(sizes.values())), 1)
        self.assertGreater(sol.sizes["question"], sol.sizes["support"])
        self.assertGreater(sol.sizes["support"], sol.sizes["label"])

    def test_blocks_are_padded_inside_panels_and_panels_do_not_overlap(self):
        bands = [Band([PanelSpec("a", "amber", [blk("label", "HEAD"), blk("body", "Some body text that wraps over a few lines. " * 3)]),
                       PanelSpec("b", "blue", [blk("body", "Other text.")])], widths=[2, 1]),
                 Band([PanelSpec("c", "green", [blk("support", "Footer reasoning text.")])])]
        sol = engine.solve(bands, self.REGION)
        self.assertTrue(sol.ok)
        for pp in sol.panels:
            for pb in pp.blocks:
                self.assertGreaterEqual(pb.x - pp.x, 0.15 - 1e-9)
                self.assertGreaterEqual(pb.y - pp.y, 0.15 - 1e-9)
                self.assertGreaterEqual(pp.x + pp.w - (pb.x + pb.w), 0.15 - 1e-9)
                self.assertGreaterEqual(pp.y + pp.h - (pb.y + pb.h), 0.15 - 1e-9)
        for i, a in enumerate(sol.panels):
            for b in sol.panels[i + 1:]:
                overlap_x = min(a.x + a.w, b.x + b.w) - max(a.x, b.x)
                overlap_y = min(a.y + a.h, b.y + b.h) - max(a.y, b.y)
                self.assertFalse(overlap_x > 1e-6 and overlap_y > 1e-6, f"{a.spec.id} overlaps {b.spec.id}")
        self.assertLessEqual(max(pp.y + pp.h for pp in sol.panels), self.REGION[1] + self.REGION[3] + 1e-6)

    def test_panel_grows_with_content(self):
        short = engine.solve([Band([PanelSpec("a", "blue", [blk("body", "Short.")]), PanelSpec("b", "blue", [blk("body", "Short.")])])],
                             self.REGION)
        long_text = "A much longer sentence that has to wrap onto several lines at this size. " * 3
        mixed = engine.solve([Band([PanelSpec("a", "blue", [blk("body", long_text)]), PanelSpec("b", "blue", [blk("body", "Short.")])])],
                             self.REGION)
        self.assertGreaterEqual(mixed.sizes["body"], 28.0)
        self.assertLessEqual(mixed.sizes["body"], short.sizes["body"])

    def test_title_fit_prefers_one_line_then_two(self):
        self.assertEqual(engine.fit_title("Short title", 12.0)[1], 1)
        size, lines, height = engine.fit_title("A very long title that cannot possibly fit on one line at thirty points across the slide width", 12.0)
        self.assertEqual(lines, 2)
        self.assertGreater(height, tokens.FRAME["title_line_h_in"])


def sample_spec():
    return json.loads((ROOT / "examples" / "deck-spec-sample.json").read_text())


class BuilderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def build(self, spec=None, **kw):
        b = DeckBuilder(**{**sample_spec()["meta"], "title": "t", **kw})
        for s in (spec or sample_spec())["slides"]:
            b.add_slide(s)
        report = b.save(self.dir / "deck.pptx")
        return b, report

    def test_ownership_names_follow_the_panel_standard(self):
        self.build()
        prs = Presentation(self.dir / "deck.pptx")
        for slide in list(prs.slides)[:6]:
            names = [s.name for s in slide.shapes]
            panels = {n.split(":", 2)[2] for n in names if n.startswith("DLP:panel:")}
            self.assertTrue(panels)
            for n in names:
                if n.startswith("DLP:") and not n.startswith("DLP:panel:"):
                    self.assertIn("|panel=", n)
                    self.assertIn(n.split("|panel=")[1], panels)
            self.assertIn("Title", names)

    def test_plugin_geometry_audits_pass(self):
        self.build()
        code, rep = run_audit("audit_panel_containment.py", self.dir / "deck.pptx", self.dir / "pc.json")
        self.assertEqual(rep["overall_status"], "pass", rep.get("coverage_issues"))
        self.assertGreater(rep["summary"]["paired_text_boxes"], 10)
        code, rep = run_audit("audit_slide_typography.py", self.dir / "deck.pptx", self.dir / "ty.json")
        self.assertEqual(code, 0, rep)
        self.assertEqual(rep["overall_status"], "pass")

    def test_visual_exemplar_grammar_metrics(self):
        from audit_visual_exemplar import inspect_deck as exemplar_metrics
        b = DeckBuilder(theme="dlp", frame="rail", profile="classroom")
        for i in range(4):
            for role in ("amber", "blue", "green"):
                b.add_slide({"id": f"{role}{i}", "layout": "focus", "role": role, "eyebrow": "SAMPLE", "title": f"Slide {role} {i}",
                             "primary": {"blocks": [{"style": "main", "text": "A short main statement."}]},
                             "secondary": [{"blocks": [{"style": "support", "text": "Supporting direction."}]}]})
        b.save(self.dir / "grammar.pptx")
        m = exemplar_metrics(self.dir / "grammar.pptx")
        self.assertGreaterEqual(m["rail_coverage"], 0.95)
        self.assertGreaterEqual(m["panel_coverage"], 0.90)
        self.assertGreaterEqual(m["trebuchet_share"], 0.80)
        for role, count in m["role_colour_counts"].items():
            self.assertGreaterEqual(count, 4, role)

    def test_every_run_has_explicit_size_font_and_colour(self):
        self.build()
        prs = Presentation(self.dir / "deck.pptx")
        for slide in prs.slides:
            for shape in slide.shapes:
                if shape.has_text_frame:
                    for p in shape.text_frame.paragraphs:
                        for r in p.runs:
                            self.assertIsNotNone(r.font.size, shape.name)
                            self.assertEqual(r.font.name, "Trebuchet MS", shape.name)
                            self.assertIsNotNone(r.font.color.rgb, shape.name)

    def test_overlong_content_fails_closed(self):
        spec = {"slides": [{"id": "x", "layout": "focus", "role": "blue", "title": "Too much",
                            "primary": {"blocks": [{"style": "body", "text": "Many words here. " * 120}]}}]}
        b = DeckBuilder()
        b.add_slide(spec["slides"][0])
        self.assertTrue(b.failures)
        with self.assertRaises(LayoutError):
            b.save(self.dir / "never.pptx")
        self.assertFalse((self.dir / "never.pptx").exists())

    def test_reveal_creates_one_click_per_step_and_reopens(self):
        self.build()
        prs = Presentation(self.dir / "deck.pptx")
        xml = prs.slides[4]._element.xml
        self.assertEqual(xml.count('nodeType="clickEffect"'), 3)
        self.assertIn("<p:bldLst>", xml)
        ids = {s.shape_id for s in prs.slides[4].shapes}
        import re
        for spid in re.findall(r'spTgt spid="(\d+)"', xml):
            self.assertIn(int(spid), ids)

    def test_staff_green_header_frame_builds(self):
        spec = {"slides": [{"id": "a", "layout": "cards", "cols": 3, "role": "neutral", "eyebrow": "PD • CARDS", "title": "Three principles",
                            "items": [{"head": "TRUST", "role": "amber", "text": "Safety and respect."},
                                      {"head": "PARTNERSHIP", "role": "blue", "text": "Equals working together."},
                                      {"head": "EVIDENCE", "role": "green", "text": "Decisions follow what we see."}]}]}
        b = DeckBuilder(theme="green", frame="header", profile="staff")
        for s in spec["slides"]:
            b.add_slide(s)
        b.save(self.dir / "green.pptx")
        prs = Presentation(self.dir / "green.pptx")
        first = [s.name for s in prs.slides[0].shapes][0]
        self.assertEqual(first, "Header band")      # band is behind the title so the title is read first and is visible

    def test_images_need_alt_text(self):
        from PIL import Image
        Image.new("RGB", (60, 40), "white").save(self.dir / "p.png")
        b = DeckBuilder(base_dir=str(self.dir))
        with self.assertRaises(ValueError):
            b.add_slide({"id": "i", "layout": "focus", "role": "blue", "title": "Img",
                         "primary": {"blocks": [{"image": "p.png"}]}})


class GovernedTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.p = Path(self.tmp.name)
        self.content = {
            "schema_version": 3,
            "instances": [{"id": "lit", "owner": "dlp-literacy-warmup", "start": "08:30", "duration_minutes": 20, "purpose": "retrieval"}],
            "tasks": [{"id": "q1", "instance_id": "lit", "operation": "combine",
                       "fields": {"prompt": "Join the sentences using but: The day was hot. The night was cool.",
                                  "answer": "The day was hot, but the night was cool.",
                                  "reminder": "Use but to join two ideas that contrast.", "cue": "Changed word: but"},
                       "demands": [{"id": "response", "action": "combine", "answer_quote": "The day was hot, but the night was cool."}]}],
            "documents": {"brief": {"fields": {"text": "Teach the contrast conjunction but."}},
                          "ui": {"fields": {"eye_rem": "LITERACY WARM-UP 1 OF 10 • REMINDER", "eye_q": "LITERACY WARM-UP 1 OF 10 • QUESTION",
                                            "eye_a": "LITERACY WARM-UP 1 OF 10 • ANSWER", "t_rem": "Remember: but shows contrast",
                                            "t_q": "Join the sentences", "t_a": "The day was hot, but the night was cool"}}},
        }
        self.context = {"timetable_instances": self.content["instances"], "required_artifacts": ["deck", "briefing", "student", "answers"]}
        (self.p / "content.json").write_text(json.dumps(self.content))
        (self.p / "context.json").write_text(json.dumps(self.context))
        self.spec = {"meta": {"warmup": True}, "slides": [
            {"id": "rem", "layout": "focus", "role": "amber", "eyebrow": "@ui/eye_rem", "title": "@ui/t_rem",
             "primary": {"blocks": [{"style": "main", "text": "@q1/reminder"}]}},
            {"id": "q", "layout": "focus", "role": "blue", "eyebrow": "@ui/eye_q", "title": "@ui/t_q",
             "primary": {"blocks": [{"style": "main", "text": "@q1/prompt"}]}},
            {"id": "a", "layout": "focus", "role": "green", "eyebrow": "@ui/eye_a", "title": "@ui/t_a",
             "primary": {"blocks": [{"style": "main", "text": "@q1/answer"}]},
             "secondary": [{"blocks": [{"style": "support", "dlp_role": "cue", "text": "@q1/cue"}]}]}]}

    def tearDown(self):
        self.tmp.cleanup()

    def test_literal_text_and_unapproved_visuals_are_refused(self):
        from content_source import ContentSource
        source = ContentSource(self.p / "content.json")
        with self.assertRaises(ValueError):
            DeckBuilder(source=source, theme="green")
        with self.assertRaises(ValueError):
            DeckBuilder(source=source, frame="header")
        with self.assertRaises(ValueError):
            DeckBuilder(source=source, profile="staff")
        b = DeckBuilder(source=source)
        with self.assertRaises(ValueError):
            b.add_slide({"id": "x", "layout": "focus", "role": "blue", "eyebrow": "@ui/eye_q", "title": "A literal title",
                         "primary": {"blocks": [{"style": "main", "text": "@q1/prompt"}]}})

    @needs_render
    def test_governed_deck_passes_the_full_pack_audit(self):
        result = build_deck_artifact(self.spec, content_path=self.p / "content.json", out_dir=self.p)
        self.assertEqual(result["inspect"]["status"] in ("PASS", "WARN"), True, result["inspect"]["summary"])
        manifest = {"schema_version": 3, "artifacts": [result["artifact"]], "bindings": result["bindings"], "renders": result["renders"]}
        for role, record, field in [("briefing", "brief", "text"), ("student", "q1", "prompt"), ("answers", "q1", "answer")]:
            text = (self.content["documents"]["brief"]["fields"]["text"] if record == "brief"
                    else self.content["tasks"][0]["fields"][field])
            doc = fitz.open()
            page = doc.new_page()
            page.insert_textbox(fitz.Rect(40, 40, 550, 200), text, fontsize=12, fontname="helv")
            doc.save(self.p / f"{role}.pdf")
            doc.close()
            png = self.p / f"renders/{role}-001.png"
            fitz.open(self.p / f"{role}.pdf")[0].get_pixmap().save(png)
            manifest["artifacts"].append({"id": role, "role": role, "path": f"{role}.pdf", "sha256": digest(self.p / f"{role}.pdf"), "pages": 1})
            manifest["bindings"].append({"artifact": role, "record": record, "field": field, "page": 1, "bbox": [40, 40, 550, 200]})
            manifest["renders"].append({"artifact": role, "page": 1, "path": f"renders/{role}-001.png", "sha256": digest(png),
                                        "artifact_sha256": digest(self.p / f"{role}.pdf")})
        manifest["content_sha256"] = digest(self.p / "content.json")
        manifest["context_sha256"] = digest(self.p / "context.json")
        (self.p / "manifest.json").write_text(json.dumps(manifest))
        errors, _, _ = audit_pack(self.p / "manifest.json", self.p / "content.json", self.p / "context.json")
        self.assertEqual(errors, [])
        # every text shape is bound exactly once
        deck_bindings = [b for b in result["bindings"] if b["artifact"] == "deck"]
        prs = Presentation(self.p / "pack.pptx")
        text_shapes = sum(1 for s in prs.slides for sh in s.shapes if sh.has_text_frame and sh.text.strip())
        self.assertEqual(len(deck_bindings), text_shapes)

    def test_rewritten_text_after_build_breaks_the_binding(self):
        from content_source import ContentSource
        source = ContentSource(self.p / "content.json")
        b = DeckBuilder(source=source)
        for s in self.spec["slides"]:
            b.add_slide(s)
        b.save(self.p / "pack.pptx")
        b.apply_bindings(source)
        prs = Presentation(self.p / "pack.pptx")
        shape = [sh for sh in prs.slides[1].shapes if sh.name.startswith("DLP:main")][0]
        shape.text_frame.paragraphs[0].runs[0].text = "A paraphrased prompt"
        prs.save(self.p / "pack.pptx")
        from pack_evidence import extract, normal
        binding = [x for x in source.bindings if x["field"] == "prompt"][0]
        self.assertNotEqual(normal(extract(self.p / "pack.pptx", binding)), normal(self.content["tasks"][0]["fields"]["prompt"]))


@needs_render
class InspectorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def _planted(self):
        prs = Presentation()
        prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        from pptx.enum.shapes import MSO_SHAPE
        from pptx.dml.color import RGBColor
        panel = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(1.5), Inches(5.0), Inches(1.6))
        panel.fill.solid()
        panel.fill.fore_color.rgb = RGBColor(0xEA, 0xF2, 0xF8)
        tb = slide.shapes.add_textbox(Inches(1.0), Inches(1.6), Inches(4.6), Inches(1.4))
        tb.text_frame.word_wrap = True
        run = tb.text_frame.paragraphs[0].add_run()
        run.text = "This sentence is far too long for the little box it was put in and so it spills out of the panel."
        run.font.size = Pt(32)
        run.font.name = "Trebuchet MS"
        run.font.color.rgb = RGBColor(0x11, 0x18, 0x27)
        prs.save(self.dir / "planted.pptx")
        return self.dir / "planted.pptx"

    def test_flags_text_escaping_its_panel(self):
        deck = self._planted()
        pdf, _ = render.render_pdf(deck, self.dir / "r")
        report = inspect_deck.inspect_deck(deck, pdf)
        codes = {i["code"] for s in report["slides"] for i in s["issues"] if i["severity"] == "fail"}
        self.assertEqual(report["status"], "FAIL")
        self.assertTrue(codes & {"text_escapes_panel", "text_outside_text_box"}, codes)

    def test_clean_sample_deck_passes(self):
        b = DeckBuilder(**sample_spec()["meta"])
        for s in sample_spec()["slides"]:
            b.add_slide(s)
        deck = self.dir / "sample.pptx"
        b.save(deck)
        pdf, plan = render.render_pdf(deck, self.dir / "r")
        report = inspect_deck.inspect_deck(deck, pdf)
        self.assertEqual(report["summary"]["fail"], 0, inspect_deck.format_report(report))
        for slide in report["slides"]:
            self.assertEqual(slide["located"], slide["text_shapes"])

    def test_renders_every_page_with_hashes(self):
        b = DeckBuilder(**sample_spec()["meta"])
        for s in sample_spec()["slides"]:
            b.add_slide(s)
        deck = self.dir / "sample.pptx"
        b.save(deck)
        manifest = render.render_all(deck, self.dir / "r")
        self.assertEqual(len(manifest["renders"]), len(sample_spec()["slides"]))
        for entry in manifest["renders"]:
            self.assertEqual(entry["sha256"], digest(entry["path"]))
            self.assertEqual(entry["artifact_sha256"], digest(deck))


@needs_render
class CliTests(unittest.TestCase):
    def test_selftest_passes_end_to_end(self):
        with tempfile.TemporaryDirectory() as td:
            res = subprocess.run([sys.executable, str(ROOT / "scripts" / "dlp_deck_cli.py"), "selftest", "--out-dir", td],
                                 capture_output=True, text=True)
            self.assertEqual(res.returncode, 0, res.stdout + res.stderr)
            self.assertIn("CHECK PASS", res.stdout)
            self.assertTrue((Path(td) / "contact-sheet.jpg").is_file())

    def test_build_failure_writes_no_deck_and_exits_2(self):
        with tempfile.TemporaryDirectory() as td:
            spec = Path(td) / "bad.json"
            spec.write_text(json.dumps({"slides": [{"id": "x", "layout": "focus", "role": "blue", "title": "Too much",
                                                    "primary": {"blocks": [{"style": "body", "text": "Many words here. " * 120}]}}]}))
            res = subprocess.run([sys.executable, str(ROOT / "scripts" / "dlp_deck_cli.py"), "build", str(spec), "--out", str(Path(td) / "o.pptx")],
                                 capture_output=True, text=True)
            self.assertEqual(res.returncode, 2)
            self.assertFalse((Path(td) / "o.pptx").exists())
            self.assertIn("content_does_not_fit_at_floor_size", res.stderr)


if __name__ == "__main__":
    unittest.main()

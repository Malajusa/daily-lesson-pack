# Semantic Colour Regression Example

## Purpose

Use this example to check that the Daily Lesson Pack applies colour as an instructional signal rather than decoration. It is a specification for regression testing, not a fixed lesson that overrides the active curriculum sequence.

In the source notation below, `/` is used only to keep the Markdown readable. Any student-facing slide generated from this example must render fractions with a vinculum or properly stacked fraction, never a forward slash.

## Test A — Mathematics warm-up pair

### Intended concept

Adding and subtracting fractions with like denominators.

### Prompt slide structure

Keep the established three-column layout with literal labels ALL, MOST and
SOME. The question slide contains these three tasks only: no WHY panel,
reasoning prompt or fourth task. Reserve the bottom green WHY panel for the
immediately following answer slide.

**ALL**

Calculate: `2/7 + 3/7`

**MOST**

A bottle is `7/10` full. Sam drinks `3/10` of the bottle. What fraction of the bottle remains?

**SOME**

Complete: `□/12 + 5/12 = 11/12`

### Semantic-colour mapping

- neutral background and ordinary text;
- one blue instructional accent identifies the denominator in each fraction and the matching denominator in any fraction bar used on the slide;
- do not assign unrelated colours to the three calculations;
- `ALL`, `MOST` and `SOME` retain their fixed labels and positions, so colour is not required to know the task tier;
- the green footer treatment means `Why/reasoning` only.

### Answer slide

**ALL:** `5/7`

**MOST:** `4/10`

**SOME:** `6/12 + 5/12 = 11/12`

**Why:** The denominator stays the same because the size of the equal parts has not changed; only the number of those parts changes.

Mirror the preceding question's tier order and positions. Keep meaningful
tasks and answers at least 36 pt and the answer-slide WHY explanation at least
28 pt. Reflow or shorten content before reducing type.

The denominator receives the same blue signal wherever it reappears. The complete answers remain readable and meaningful if the colour is removed.

### Fail examples

- placing a WHY panel or reasoning task on the question slide;
- red `All`, amber `Most`, green `Some` traffic-light coding;
- every numerator and denominator given a different colour;
- different denominator colours in question and answer slides;
- saturated card backgrounds that make the three columns compete with the mathematics;
- colour as the only distinction between levels.

## Test B — Shared Reading slide

### Paragraph

**Mangrove roots slow moving water. As waves pass through the tangled roots, the water meets resistance and loses some energy. This means less wave energy reaches the shoreline, which can reduce erosion and damage.**

### Question

What does the **resistance** from mangrove roots do to the waves?

### Semantic-colour mapping

- paragraph and question are separated by spacing/panel structure before colour is applied;
- the word `resistance` uses the same restrained blue signal in the paragraph and question because students must connect the question directly to that part of the text;
- no other vocabulary is automatically highlighted;
- the rest of the paragraph stays neutral and high contrast;
- the answer slide may retain the cue during modelling, then the next independent reading item should remove the cue if students are expected to locate evidence without it.

### Expected answer

The resistance makes the waves lose some energy before they reach the shoreline.

### Fail examples

- colouring several interesting words with unrelated hues;
- using a coloured paragraph background as the only separation between paragraph and question;
- highlighting the whole sentence when only one correspondence matters;
- retaining strong evidence highlights on every independent comprehension item.

## Regression acceptance criteria

Both test slides pass only when:

1. every non-neutral colour has an identifiable instructional role;
2. repeated concepts keep the same colour;
3. the slide remains understandable in greyscale;
4. text and meaningful graphics meet the required contrast thresholds;
5. colour does not replace labels, fixed position, symbols or explicit wording;
6. the visual signal directs attention to the intended relationship rather than to decoration;
7. the cue is reduced when the next task requires independent identification.

# Original manual HTML control review cases

These are authored expectations and deliberate defect descriptions, not executed
browser observations or teaching-acceptance receipts. Browser acceptance for this
supplement is NOT_RUN. Use the evidence template on the exact final artifact;
leave missing evidence UNVERIFIED. Cases are original synthetic examples and
contain no student data. Do not mark a case PASS because its expected answer is
printed here.

## Valid equivalence case

Purpose: show that repartitioning changes the count and size of equal parts while
preserving the selected amount. Controls: `Repartition by 2`, `Reset`. A fixed
rectangle initially contains two equal parts with one selected and label `1/2`.

- From initial, activate Repartition: expect four equal parts, two selected,
  label `2/4`, identical whole and selected area, every original part subdivided.
- Repartition again: expect eight equal parts, four selected, label `4/8`.
  The authored maximum is eight; Repartition becomes disabled.
- Repeat attempts at the maximum: expect unchanged coherent `4/8`, no new parts
  and no duplicate action. Disabled keyboard controls follow native focus rules.
- Reset after the maximum: expect the complete initial diagram, `1/2` label,
  Repartition enabled and feedback cleared or restored as authored.
- Reset while already initial: expect no harmful change. Repartition again:
  expect exactly the same `2/4` state as the first action.
- Repeat with ordinary pointer input, keyboard Tab/Shift+Tab plus native
  Enter/Space, and touch in a supported narrow viewport. Record each separately;
  inspect reachable targets, visible focus and post-update focus.

## Valid conversion control (different concept family)

Purpose: express the same mass in different units. A single half-kilogram model
has label `0.5 kg`. Controls: `Show grams`, `Reset`.

- Show grams changes the visible label to `500 g`, preserving the represented
  mass and model. A second activation is intentionally idempotent.
- Reset restores `0.5 kg`; replay produces `500 g` again.
- Mathematical checks use `0.5 × 1000 = 500`. A diagram which stays unchanged is
  correct here; reject a blanket rule that all teaching controls require motion.
- Repeat each claimed input mode. This is legitimate fractional mass, not a
  requirement to avoid fractions in unit conversion.

## Negative cases that must block a software PASS

1. Detached handler: Repartition receives a normal click but the original `1/2`
   state remains. A present control or successful input call is insufficient.
2. Text-only update: label becomes `2/4` but only two parts remain. Fail visible
   model correspondence even though the numeric value is equivalent.
3. Visual no-op: DOM count says four rectangles but interior partition lines are
   absent or the updated diagram is hidden. Fail the visible expected result.
4. Stale label: four correct parts appear but the label remains `1/2` where this
   control's authored notation is `2/4`. Fail the promised count correspondence.
5. Wrong maths: four unequal parts, three selected parts, a changed whole, changed
   selected area, or only selected original parts subdivided. Fail exactness.
6. Broken Reset: labels restore but geometry/selection or enabled state does not.
   Fail; test replay to expose stale state and duplicate listeners.
7. Zero-control inventory on a claimed interactive page: fail, even if the
   runner reports zero failures. Investigate omitted/custom controls first.
8. Failed page load or missing dependency: fail the run before interaction
   checks. An empty error page is not a successfully tested static lesson.
9. Missing keyboard/touch evidence: report UNVERIFIED for those claims; never
   relabel a mouse click as touch or DOM handler invocation as keyboard input.
10. Changed source after review: reject the stale observations and re-test the
    affected controls on the new final file.

## Review outcome

Record the observed result and evidence for each state before deciding. If the
browser/renderer is unavailable, the contract and authored expectations can be
reviewed as instructions, but actual interaction, visual and device verdicts
remain UNVERIFIED / NOT_RUN. Existing independent teaching-review requirements
still apply. No one-off fixture or template grants release authority.

# User/school runtime context and memory-independence contract

## Purpose

This contract defines the **runtime context** a teacher supplies so the Daily Lesson Pack can adapt to that teacher's timetable, current overviews and school sequence without relying on hidden chat memory.

It is deliberately separate from `year-level-context-contract.md`.

- Runtime context answers: **What is this class teaching now, when, and under what local constraints?**
- A selected maintained Level A/Level B plan answers: **What is the agreed term scope and ordered teaching sequence for this week?**
- The active year-level profile answers: **What is an appropriate developmental and curriculum-facing pitch for this year level?**
- The creator-settings contract answers: **Which authorised preferences apply for this class and date?**
- The pack profile answers: **What stable slide counts and release behaviours apply across supported profiles?**

Load `default-pack-profile.json` as the bundled architecture profile. A current
user instruction may override a profile field for that run, but the resolved
value and source must be written to the context record.

A teacher's timetable or overview must never become the definition of a year-level profile.

## Runtime context fields

Resolve these from the current request, current-run files, connected authoritative sources or an explicitly selected reusable user/school context file:

1. active registered profile, automatically selected from creator defaults or authorised preferences unless the current request overrides it;
2. exact date, term, week and day;
3. that teacher's timetable for the requested day, including interruptions;
4. the selected maintained term/week plan, when the current request or authorised
   class context selects one;
5. current Mathematics overview/topic and day-level focus, resolved from the
   selected weekly plan when it covers Mathematics or otherwise from another
   authoritative current source;
6. current English/literacy overview/toolkit stage and day-level focus, resolved
   from the selected weekly plan when it covers English or otherwise from another
   authoritative current source;
7. any explicit lesson-status exception from the preceding scheduled lesson;
8. current class size or printing quantity when printing is requested;
9. any local scope changes, specialist blocks or school-specific routines that materially affect the pack.

Do not require the same timetable, overview format, term sequence or class size from different users.

## No bundled class defaults as year-level assumptions

Represent each teaching block using `component-instance-contract.md`. Repeated
subject owners are not merged. Every instance has a unique ID, start time,
duration and purpose before component generation begins.

Assume the preceding scheduled lesson was completed sufficiently to advance
unless an explicit status exception says it was partial, cancelled or requires
reteaching.

Do not treat any of the following as universal or year-level defaults:

- mixed Year 4/5 enrolment;
- a fixed class size or `29 copies` rule;
- one school's timetable;
- a four-day Monday/Tuesday/Thursday/Friday overview;
- a fixed Information Report unit;
- a particular Shared Reading country sequence;
- one teacher's Wednesday arrangement;
- a school-specific assembly or specialist schedule.

These may be used only when they are supplied or explicitly selected as current runtime context for that user/class.

## Source hierarchy for runtime facts

For lesson focus inside an explicitly selected maintained plan, apply
`term-week-day-planning-contract.md`: current user instruction first, then any
authoritative lesson-status exception, then the selected Level B weekly teaching
overview, then its Level A term overview. The actual timetable controls Level C
placement and available time.

For other runtime facts, use:

1. the user's current explicit instruction;
2. current-run timetable/overview/unit files;
3. explicitly selected maintained user/school context;
4. authoritative school planning material explicitly supplied for this run;
5. older local planning only when it is clearly still current.

The presence of a bundled dated creator plan is not selection. Do not apply it
to another teacher or class unless that current run explicitly selects it.

Chat memory, saved personal context and another account's Project context may help identify what to look for, but must not silently supply timetable facts, lesson focus, class size, copy quantity or local routines.

## Progression rule

Assume the preceding scheduled lesson was completed sufficiently to advance unless an authoritative runtime source records partial completion, cancellation or required reteaching.

If a selected Level B weekly overview defines an ordered lesson sequence, keep
that sequence timetable-agnostic and map the next applicable lesson onto the
actual Level C day/block. Do not invent weekday labels in Level B.

If another overview defines a day-level sequence, follow that sequence. If it
does not define a requested day and no selected Level B plan resolves the focus,
use the teacher's supplied current focus rather than inventing a bridge from
another day.

## Missing-input behaviour

If a required runtime field is unavailable or contradictory:

1. resolve it from another authoritative current-run source where possible;
2. otherwise ask one concise question that resolves the highest-impact ambiguity;
3. do not guess from chat memory or an older generated deck;
4. do not release the pack as classroom-ready until the ambiguity is resolved;
5. record the source used for each resolved field in the temporary context-source record supplied to final QA.

When printing is requested and quantity is not supplied or otherwise authoritative, treat it as unresolved rather than inheriting another user's class size.

## Clean-account acceptance condition

The skill is portable only when a fresh account with no relevant memory can produce the intended pack using:

- the installed repository release;
- an active year-level profile;
- that user's current timetable;
- either that user's selected maintained Level A/Level B planning sources or
  their current Maths and English/literacy overviews/explicit day-level focus;
- any required lesson-status exception;
- any local class/output constraints needed for the requested artefacts.

If the same supplied inputs produce materially weaker pedagogy, visual design or QA in a clean account, treat that as a skill defect rather than a missing-memory issue.

## Privacy boundary

Do not store student names, diagnoses, assessment records or other personal student information in the portable runtime-context contract or year-level profiles.

## Authorised persistence is not hidden recall

`creator-settings-contract.md` supersedes any interpretation that all preferences
must be supplied again each run. Real private revisioned settings may load
automatically. Current lesson facts still need valid planning sources. The school
calendar is not a source for this skill. Nothing here authorises student records,
private bindings or saved settings to enter a portable package.

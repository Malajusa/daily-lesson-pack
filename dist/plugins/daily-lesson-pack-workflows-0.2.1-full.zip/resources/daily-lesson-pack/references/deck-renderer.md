# Supported deck renderer (`scripts/dlp_deck/`)

This is the repository-owned way to turn a deck **spec** into a PPTX that meets
the visual exemplar, projected-readability and panel-containment standards. It
exists because those standards cannot be met by writing slide geometry from
memory: text has to be *measured*, panels have to *grow to their content*, and
the result has to be *looked at*. The renderer does the measuring; the check
loop does the looking.

It is a layout engine, not a content author. It never decides wording,
sequencing, differentiation or answers, and a passing `check` never releases a
pack. Release still needs the independent rendered-review record bound to the
deck SHA-256 (`visual-exemplar-standard.md`, `qa-workflow-v3.md`).

## Requirements

| Need | Used for | If missing |
| --- | --- | --- |
| Python 3.10+ with `python-pptx`, `PyMuPDF` (`requirements.txt`) | write PPTX, read the rendered PDF | `pip install -r requirements.txt` |
| LibreOffice (`soffice`) | render the deck to PDF/PNG for the inspector | `render`/`inspect`/`check` stop with a clear error; `build` still works but the deck is **unverified** |
| Trebuchet MS (optional) | exact on-screen metrics | the renderer substitutes a metric-compatible sans (Liberation Sans/Arimo) and records which in `render-manifest.json` |

Run `python scripts/dlp_deck_cli.py selftest` first. If it fails, say what is
missing; do not fall back to hand-built slides.

## The loop

```text
python scripts/dlp_deck_cli.py check spec.json --out-dir work
```

1. **build** - spec to `work/<spec name>.pptx`. Fails closed (exit 2, no PPTX
   written; `<spec name>.layout-failures.json` lists each slide, the height
   required and the height available) if any content does not fit at its
   role's floor size.
2. **render** - LibreOffice to PDF, then one 1920 px PNG per slide plus
   `work/contact-sheet.jpg`, with a SHA-256 for every page.
3. **inspect** - the render-level inspector finds each text shape's glyphs in
   the PDF and checks them against the shape, its panel, the slide and the
   type floors (table below).
4. **audits** - for the `classroom` profile, the plugin's own
   `audit_slide_typography.py` and `audit_panel_containment.py` run on the same
   deck. Results are summarised in `work/check-summary.json`.

Then **open `contact-sheet.jpg` and the individual PNGs and look at them.** The
inspector catches geometry; it cannot see whether a slide reads well. Check
hierarchy (what is the first thing the eye lands on), balance, empty space,
and whether any panel is a small island of text in a big box. Change the
**spec**, never the PPTX, and re-run. Stop only when `CHECK PASS` and the slides
look right.

### What the inspector fails (hard) and warns on

| Fail | Meaning |
| --- | --- |
| `text_outside_text_box` | rendered glyphs fall outside their own text box |
| `text_escapes_panel` / `text_touches_panel_edge` | text crosses, or is within 0.10 in of, its panel edge |
| `text_off_slide` | text within 0.05 in of the slide edge |
| `below_role_floor` / `font_size_unknown` | a run is below the role's floor, or has no explicit size |
| `render_font_size_differs` | the renderer scaled the text (shrink-on-overflow) so the rendered size is not the authored size |
| `low_contrast` | under 4.5:1 (3:1 for large text) against the fill behind it |
| `text_overlaps_text` | two text shapes' glyphs overlap |
| `near_blank_slide` | almost nothing on the slide |

Warnings (fix unless there is a reason): `tight_panel_padding` (< 0.15 in),
`text_near_slide_edge`, `orphan_last_line` (one short word), `low_canvas_use`,
and `text_not_located_in_render` (the inspector could not find a shape's text
in the PDF, so that shape is unchecked - treat as unverified and look at it).
Page markers are exempt from floors. `inspect` works on **any** PPTX, including
one the renderer did not make - use it on a received deck before touching it.

## Spec format

```jsonc
{
  "meta": {"title": "...", "theme": "dlp", "frame": "rail", "profile": "classroom", "warmup": false},
  "slides": [
    {"id": "q1", "layout": "focus", "role": "blue", "component": "Shared Reading",
     "title": "Plain-language title",
     "primary":   {"blocks": [{"style": "main", "text": "The bird uses its ____ to crack the seed."}]},
     "secondary": [{"blocks": [{"style": "support", "dlp_role": "instruction", "text": "Choose one."}]}]}
  ]
}
```

`python scripts/dlp_deck_cli.py layouts` prints every layout and field.
`examples/deck-spec-sample.json` is a runnable example (`selftest` builds it).

- **Layouts:** `panels` (rows of side-by-side panels, the general case), `focus`
  (one dominant panel + supporting panels), `triad` (All / Most / Some + Why),
  `steps` (row or column), `columns`, `cards`, `statement`, `section`.
- **Roles:** `amber` reminder/teacher model, `blue` question/task, `green`
  answer/model, `neutral` cue/evidence, `dark` emphasis (non-lesson decks).
  The eyebrow states the role in words so colour is never the only signal.
- **Block styles:** `main`/`question` (the thing students look at), `body`
  (passages and models), `support` (instructions, cues, reasons), `label`
  (All/Most/Some, WHY, step heads), `num`. Style sets the type range; do not
  put an instruction in `main` to make it bigger.
- **Emphasis:** `"emphasis": [{"text": "beak", "scale": 1.3}]` changes only
  how a substring looks. The visible text is unchanged so bindings stay exact.
- **Reveal:** `"reveal": n` on panels/steps/columns/cards adds native on-click
  Appear animation, one click per group, in order. Apply it only where the
  component contract calls for stepped reveal.
- **Images** need `"alt"`. Pure decoration is marked decorative automatically.

## How fitting works (so you can predict it)

- Each text style has a **range** (floor, ceiling). `classroom` ranges are the
  projected standards: main/question 32-54 pt, body and support at least 28 pt,
  label at least 22 pt, warm-up main at least 36 pt. `staff` is a relaxed scale
  for meeting-room decks and is **never** valid for a lesson release.
- The solver picks the **largest** size that fits, using one shared size per
  style across every panel on a slide, so sibling panels always match and
  hierarchy (main > support > label) is preserved.
- Panels size to their content, then spare height is shared out (capped) and
  the remainder is centred, which removes the "tiny text in a huge box" look.
  Panels keep at least 0.15 in padding on every side.
- Text widths come from baked Arial-metric tables x 1.05. The model is
  calibrated never to predict *fewer* lines than a real render. It does not
  know Trebuchet's exact widths, so the render check is not optional.
- **A `FitFailure` is a content problem, not a font problem.** The renderer
  will not go below a floor. Apply the repair order from
  `slide-deck-quality-standards.md` (shorten, remove teacher-facing text,
  merge/enlarge regions, reflow the panel, trim decoration, **split the
  slide**) and rebuild. Do not edit the PPTX text size by hand.

## Themes, frames and profiles

| Setting | Values | Release rules |
| --- | --- | --- |
| `theme` | `dlp` (approved exemplar palette), `green`, `navy` | only `dlp` is valid for a lesson release |
| `frame` | `rail` (full-height left role rail, the exemplar), `header` (top band) | only `rail` is valid for a lesson release |
| `profile` | `classroom`, `staff` | only `classroom` is valid for a lesson release |

Non-lesson decks (staff PD, parent sessions) may use `green`/`navy`, `header`
and `staff`; say in the hand-off that it is not Daily Lesson Pack release
material. Every theme's text pairs are contrast-tested.

## Governed mode (Daily Lesson Pack decks)

For a real pack, text must come from `content.json` through `ContentSource`,
and every text shape must be bound (`qa-workflow-v3.md`). Governed mode enforces
that: any literal string in the spec is refused, the theme/frame/profile are
forced to the release set, and one binding is recorded per text shape.

```python
from dlp_deck.assembly import build_deck_artifact
result = build_deck_artifact(spec, content_path="content.json", out_dir=work, artifact_id="deck")
# result["artifact"], ["bindings"], ["renders"] go straight into the manifest;
# result["inspect"] is the render-inspector report; result["contact_sheet"] is the review image.
```

Strings in a governed spec are `"@record/field"` or `{"ref": record, "field": field}`.
Do not edit the produced PPTX text afterwards: bindings compare the exact
extracted text, so a paraphrase breaks them (by design). Tables and page-number
text are not supported in governed mode because they cannot be bound; put tabular
content in a panel as lines, or request a contract change.

`build_deck_artifact` does **not** write the manifest, assemble the PDFs, run the
release audit or provide review. A trusted `ASSEMBLE_CANONICAL_PACK` command
calls it for the deck deliverable only.

## Known gaps

- Keep an expression with its blank (`= ____`) by joining them with a no-break
  space (U+00A0) in the content. The measurer treats it as unbreakable and as
  wide as a space, and source bindings still match because their comparison
  normalises it (NFKC) to an ordinary space. Without it a card can wrap the blank
  onto a line of its own.

- Metrics are Arial-based; layouts are proofed in the render, which uses a
  substitute font if Trebuchet MS is absent. PowerPoint and Keynote may wrap
  a line differently from LibreOffice, so keep the inspector's warnings clean
  and leave the shipped slack (do not cut panels to the pixel).
- `audit_slide_typography.py` matches the support-text floor by exact role
  name; shapes named `DLP:explanation|panel=<id>` do not trigger its 28 pt
  rule. The renderer's own inspector enforces the floor by style, so rely on it.
- The renderer is a layout tool. Structural, pedagogic and release checks stay
  with the component contracts and the independent reviewer.

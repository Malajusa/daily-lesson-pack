# Interactive HTML: control expected-state QA supplement

Apply only when interactive HTML is requested or supplied for review. This is a
narrow supplement to `interactive-maths-lessons.md` and the four existing
mathematics, instruction, visual and software verdicts. Keep all PPT/PDF,
independent-review, source-binding and classroom-release checks unchanged. A
static page legitimately requiring no controls is outside this supplement; an
interactive claim with zero inventoried controls fails, rather than passing an
empty test loop. No new renderer, app platform or external service is required.

## Bind the final file and inventory before testing

1. Identify the exact final HTML/export or application build, SHA-256 of its
   bytes, linked asset/build hashes, lesson/scene ID, browser/version, viewport,
   input mode and reviewer/run. Recheck hashes after testing. A changed file
   invalidates affected results. An earlier preview is not the final artifact.
2. Load it in the intended browser. Retain navigation status, load failures,
   console/page errors and missing assets. Failed navigation or an error page
   cannot establish zero controls or a clean pass.
3. Inventory every rendered user control and content-dependent variant, including
   custom clickable elements, navigation, selection, reveal, submit and Reset.
   Identify each by a stable locator and accessible name. Compare discovered
   controls with the planned inventory; omissions, duplicates or zero controls
   for a claimed interactive resource fail. Do not infer success from the count
   of buttons, listeners, screenshots, passed assertions or a zero exit code.

## A record for every control and tested transition

Author expectations before running the action, using the teaching purpose and
mathematics rather than copying output back as an oracle. Repeat the record for
materially different before states and enabled/disabled limits:

- Control ID, locator, accessible name, lesson/scene and teaching purpose
- Before: learner-visible text/notation, diagram quantities/geometry, current
  selection, bounds and focus; reference to observed initial evidence
- Normal user action: exact click/tap/key/selection/drag and input value; no call
  to internal handlers, forced DOM mutation or assignment of application state
- Expected after: exact visible change, invariant quantities, label/diagram
  correspondence, enabled/disabled state, feedback and focus where applicable
- Observed after: independently read visible output and mathematical geometry,
  screenshot/state evidence with hashes and console/page errors
- Verdict and reason: PASS, FAIL, or UNVERIFIED; name the actual tested mode,
  browser/viewport, evidence and missing claims. A missing required observation
  blocks a passing software verdict. A fixture pass is not a lesson release.

A successful click is only delivery of input. It does not prove the teaching
change happened. For a visual model, a changed label with an unchanged or hidden
diagram fails; a diagram-only change with stale notation also fails. A no-op can
be correct at a specified bound or for an idempotent action, but its unchanged
state must be the authored expectation. Do not require arbitrary motion.

## Input modes, reset, repeat and bounds

- Pointer: operate normally and verify target reachability. Do not force clicks
  through overlays or bypass disabled controls to manufacture a pass.
- Keyboard: start from the page entry point, follow Tab/Shift+Tab to controls,
  inspect visible focus, and use each control's native keys. Enter/Space are
  appropriate for buttons; selects/sliders need their documented keys. Check
  usable focus after updates, reachable Reset and no unintended extra action.
- Touch: use actual touch input or explicit touch emulation at the claimed
  narrow viewport; verify taps/gestures and reachability. A mouse click or a
  `touch` attribute is not touch evidence. Record emulation separately from
  testing a physical device; unsupported modes remain unverified.
- Reset/replay: after several actions, Reset must restore the initial diagram,
  labels, values, enabled state and relevant feedback. Act again and compare to
  the first pass. Do not let stale state or duplicate handlers accumulate.
- Repeated/rapid input and limits: verify min/max, repeated activation, reset at
  an initial state and the defined out-of-range response. An invalid action must
  leave a coherent, specified state rather than NaN, extra partitions, duplicate
  submissions or a mismatch between representation and explanation.

## Exact mathematical expectations

For half-to-quarters equivalence, record the same whole before and after:

| State | Parts | Selected | Equal part area | Selected/whole | Visible label |
|---|---:|---:|---:|---:|---|
| Initial | 2 | 1 | 1/2 | 1/2 | 1/2 |
| Repartition by 2 | 4 | 2 | 1/4 | 1/2 | 2/4 |
| Reset | 2 | 1 | 1/2 | 1/2 | 1/2 |

Verify every original part was subdivided, including unselected parts; the whole
and selected area stay fixed; partitions are equal, contiguous and do not
overlap; actual visible notation agrees. Use exact integers/rationals for
mathematical facts. A declared small pixel tolerance is only for rendered
geometry and cannot excuse a different fraction or count. Read geometry and
computed visibility from the final render, then inspect the screenshots; SVG
presence or `data-correct=true` is not proof of visible mathematical meaning.

Retain legitimate alternatives in another concept family. For a grams/kilograms
conversion model, 1 kg and 1000 g label the same represented mass; 0.5 kg = 500 g
is valid. A constant balance/model is appropriate when only units change. Do
not apply the fraction demo's required diagram change to every control.

## Original manual regression examples and template

Read `examples/benchmarks/html-control-review.md` for original valid fraction and
conversion cases and deliberately faulty controls. Start the evidence record
from `examples/benchmarks/html-control-evidence-template.json`; its nulls,
UNVERIFIED verdicts and NOT_RUN state deliberately block any claim of execution.
Duplicate transition records for all controls, before states, bounds, replay,
claimed input modes and supported viewports. Do not accept an incomplete example
as the inventory or evidence for another lesson.

This plugin supplement provides manual instructions and authored examples only.
It adds no automated runner or new release gate. Browser acceptance for this
supplement is NOT_RUN; no interactive fixture behavior has been certified. An
unavailable browser is a concrete test blocker, never grounds for a PASS. Use
only already available, authorised browser tools with their security controls
intact; do not bypass URL/access restrictions, weaken sandboxing, install a
runtime, transmit student data or call a rendering service to complete this
check without the corresponding authority.

Independent instructional/visual review and intended-host/device acceptance
remain separate. These synthetic examples do not assess student learning and
cannot authenticate their own reviewer or certify a classroom pack.

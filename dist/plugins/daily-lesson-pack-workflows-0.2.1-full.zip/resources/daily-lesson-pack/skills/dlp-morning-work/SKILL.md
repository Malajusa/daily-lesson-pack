---
name: dlp-morning-work
description: Generate independent, book-executable Morning Work for projection as the opening slide of a Daily Lesson Pack.
---

# DLP Morning Work

## Mandatory evidence workflow (v3)

Read `references/qa-workflow-v3.md` and the applicable entries in
`references/qa-requirements.json` before generation or review. This workflow
governs release evidence and supersedes older run-ID-only independence checks
and report-only release commands below. Use `scripts/content_source.py` for
canonical task text and complete review coverage. Required checks cannot be
replaced by a broad component PASS. Only the complete-pack release command may
authorise classroom-ready output.

## Resolved instructional preferences

Read `references/creator-settings-contract.md` and use the orchestrator's frozen
`instructional_calibration` when present. Do not independently reload or save
private settings, change the requested warm-up count, or infer student attainment
from enrolment year. Legacy inputs use the documented public defaults, not hidden
chat memory. Existing final-artifact and independent-review gates still apply.

## Ownership

Own only Morning Work. Do not generate the Literacy warm-up, Shared Reading, Guided Reading or lesson instruction.

## Mandatory year-level context

Before generation, read `references/year-level-context-contract.md` and the active year-level profile supplied by the orchestrator.

The active profile controls retrieval pitch, reasonable prior knowledge, language load, expected independence and response complexity. Do not inherit another year level's examples or difficulty assumptions.

## Required output

Before generation, read
`examples/benchmarks/t3w8-wednesday-morning-work-exemplar.md` and verify the
checksum of
`assets/visual-exemplars/t3w8-wednesday-morning-work-exemplar.pptx`. Use it as
the teacher-approved benchmark for composition, task balance and projected
usability. Adapt all content to the current context; never copy its date,
calculations, sentence or fractions focus by default.

- Slide 1 titled `Morning Work`.
- Student task only: no decorative cover, timetable, date banner, `Get ready`, `Get out`, `You need`, routine reminder or generic materials list.
- Design an accessible 8-10 minute core task for the active profile. Add meaningful extensions that can carry independent work longer when arrival time allows, up to roughly 20-30 minutes, where the runtime classroom context supports this routine.
- Include retrieval plus at least one substantive application, explanation or improvement task appropriate to the active profile. Do not fill the slide with trivial busywork.
- Students should be able to begin with the level of independence expected by the active profile and runtime classroom context.

## Projected-slide and book contract

When the runtime classroom context specifies projection-and-books, assume the slide remains on the screen and students complete every response in their books.

- Every instruction must be possible with only the displayed slide and the authorised response resource.
- Do not tell students to circle, highlight, underline, cross out, label or draw on wording or images that exist only on the projected slide.
- When students choose from projected content, tell them to write the selected word, phrase, letter, number or corrected sentence in their book.
- If underlining or annotation is important, instruct students to copy the required text into their book first or use another executable response.
- Do not assume students have a printed copy unless the task explicitly supplies one.

## Precision of models and clues

A model described as precise must contain details specific to its topic.

- A habitat example should name the habitat and include a feature particular to it, such as rainforest rainfall, canopy layers, humidity or dense vegetation.
- A sentence is not precise merely because it names a broad habitat and says it provides food, water or shelter.
- The supporting clue must help students produce a more informative sentence, not repeat a vague success statement.

## Text independence

Morning Work must not reuse or pre-teach the day's Shared Reading passage. If a short reading context is used, it must be independent.

## Presentation

Use projected classroom readability. Important student-facing content should use the available space rather than sit small inside decorative panels. Do not add a whiteboard-response footer merely to state a classroom routine; obtain response-mode routines from runtime context.

## QA

Fail the component if:

- the active year-level profile is missing, unresolved or inconsistent with the orchestrator;
- task pitch relies on another year profile without explicit authorisation;
- Slide 1 is not the Morning Work task;
- any instruction requires students to mark projected-only content or an unavailable worksheet;
- the task depends on more teacher explanation than the active profile/runtime routine permits to begin;
- a model labelled precise remains generic or topic-free;
- the content duplicates Shared Reading;
- the slide is mostly routine or setup instructions;
- text is unnecessarily small, crowded or outside its intended panel.

#!/usr/bin/env python3
"""Daily Lesson Pack deck renderer: build, render, inspect, check.

Typical loop (see references/deck-renderer.md)::

    python scripts/dlp_deck_cli.py selftest                       # toolchain works?
    python scripts/dlp_deck_cli.py check spec.json --out-dir work # build + render + inspect + audits
    # look at work/contact-sheet.jpg and work/slides/*.png, fix the SPEC (not the PPTX), repeat

The renderer never edits a finished PPTX by hand.  Fix content, wording or the
spec and rebuild.  A passing ``check`` is a *screening* result; it never replaces
the independent rendered review that releases a Daily Lesson Pack.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from dlp_deck import DeckBuilder, LayoutError  # noqa: E402
from dlp_deck import inspect_deck, render  # noqa: E402
from dlp_deck.tokens import PROFILES, THEMES  # noqa: E402

SAMPLE = HERE.parent / "examples" / "deck-spec-sample.json"


def _load_spec(path: Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _builder(spec: dict, args, *, base_dir: Path) -> DeckBuilder:
    meta = dict(spec.get("meta", {}))
    for key in ("theme", "frame", "profile"):
        value = getattr(args, key, None)
        if value:
            meta[key] = value
    source = None
    content = getattr(args, "content", None) or meta.get("content")
    if content:
        from content_source import ContentSource
        source = ContentSource(content if Path(content).is_absolute() else base_dir / content)
    return DeckBuilder(theme=meta.get("theme", "dlp"), frame=meta.get("frame", "rail"), profile=meta.get("profile", "classroom"),
                       source=source, artifact_id=getattr(args, "artifact_id", None) or meta.get("artifact_id", "deck"),
                       title=meta.get("title", ""), warmup=bool(meta.get("warmup", False)),
                       page_numbers=bool(meta.get("page_numbers", False)), base_dir=str(base_dir))


def cmd_build(args) -> int:
    spec_path = Path(args.spec)
    spec = _load_spec(spec_path)
    builder = _builder(spec, args, base_dir=spec_path.parent)
    try:
        builder.build_from_spec(spec)
        report = builder.save(args.out)
    except LayoutError as exc:
        fail_path = Path(args.out).with_suffix(".layout-failures.json")
        fail_path.parent.mkdir(parents=True, exist_ok=True)
        fail_path.write_text(json.dumps(builder.failures, indent=2) + "\n", encoding="utf-8")
        print("BUILD FAILED - no deck written. Repair order: shorten wording -> remove duplicates -> merge/enlarge panels -> "
              "reduce margins -> split across slides. Never shrink below the role floor.", file=sys.stderr)
        for f in builder.failures:
            print(f"  slide {f['slide']} ({f['id']}): {f['code']}: {f['message']}", file=sys.stderr)
            for d in f.get("detail", [])[:3]:
                print(f"      panel {d['panel']!r} needs {d['needs_in']} in at {d['width_in']} in wide: {d['text'][:90]}", file=sys.stderr)
        print(f"  details: {fail_path}", file=sys.stderr)
        return 2
    layout_path = Path(args.out).with_suffix(".layout.json")
    layout_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if args.bindings_out:
        Path(args.bindings_out).write_text(json.dumps(report["bindings"], indent=2) + "\n", encoding="utf-8")
    for s in report["slides"]:
        sizes = ", ".join(f"{k} {v:g}pt" for k, v in s.get("sizes_pt", {}).items())
        print(f"slide {s['slide']:>2} {s['id']:<14} {s['layout']:<9} {sizes}  fill {s.get('occupancy', 0):.0%}"
              + ("  WARN " + "; ".join(s["warnings"]) if s.get("warnings") else ""))
    print(f"built {args.out} sha256={report['sha256'][:16]}… ({len(report['slides'])} slides, {len(report['bindings'])} bound text shapes)")
    return 0


def cmd_render(args) -> int:
    m = render.render_all(Path(args.deck), Path(args.out_dir), sheet_cols=args.cols)
    print(m["font"]["note"])
    print("contact sheet:", m["contact_sheet"])
    print("slides:", Path(args.out_dir) / "slides")
    return 0


def cmd_inspect(args) -> int:
    deck = Path(args.deck)
    out_dir = Path(args.out_dir)
    if args.pdf:
        pdf = Path(args.pdf)
    else:
        m = render.render_all(deck, out_dir)
        pdf = Path(m["pdf"])
        print(m["font"]["note"])
        print("contact sheet:", m["contact_sheet"])
    report = inspect_deck.inspect_deck(deck, pdf, profile_name=args.profile)
    out = Path(args.report) if args.report else out_dir / "inspect-report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(inspect_deck.format_report(report))
    return 1 if report["status"] == "FAIL" else 0


def _run_audit(script: str, deck: Path, out: Path, extra: list[str] | None = None) -> dict:
    cmd = [sys.executable, str(HERE / script), "--deck", str(deck), "--out", str(out)] + (extra or [])
    res = subprocess.run(cmd, capture_output=True, text=True)
    try:
        return {"script": script, "exit": res.returncode, **json.loads(res.stdout.strip().splitlines()[-1])}
    except Exception:
        return {"script": script, "exit": res.returncode, "overall_status": "error", "stderr": res.stderr[-400:]}


def cmd_check(args) -> int:
    spec_path = Path(args.spec)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    deck = out_dir / (spec_path.stem + ".pptx")
    ns = argparse.Namespace(spec=str(spec_path), out=str(deck), bindings_out=str(out_dir / "bindings.json"),
                            theme=args.theme, frame=args.frame, profile=args.profile, content=args.content, artifact_id=args.artifact_id)
    rc = cmd_build(ns)
    if rc:
        return rc
    spec = _load_spec(spec_path)
    profile = args.profile or spec.get("meta", {}).get("profile", "classroom")
    m = render.render_all(deck, out_dir)
    print(m["font"]["note"])
    report = inspect_deck.inspect_deck(deck, Path(m["pdf"]), profile_name=profile)
    (out_dir / "inspect-report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(inspect_deck.format_report(report))
    status = report["status"]
    audits = []
    if profile == "classroom":
        audits.append(_run_audit("audit_slide_typography.py", deck, out_dir / "audit-typography.json"))
        audits.append(_run_audit("audit_panel_containment.py", deck, out_dir / "audit-panel-containment.json"))
        for a in audits:
            print(f"{a['script']}: {a.get('overall_status')} (exit {a['exit']})")
            if a.get("exit") not in (0,):
                status = "FAIL"
    print(f"\nCHECK {status}")
    print(f"  deck           : {deck}")
    print(f"  contact sheet  : {m['contact_sheet']}   <- LOOK AT IT, then at slides/*.png at full size")
    print(f"  inspect report : {out_dir / 'inspect-report.json'}")
    summary = {"status": status, "deck": str(deck), "inspect": report["summary"], "audits": audits, "font": m["font"]}
    (out_dir / "check-summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return 0 if status in ("PASS", "WARN") else 1


def cmd_selftest(args) -> int:
    out_dir = Path(args.out_dir)
    ns = argparse.Namespace(spec=str(SAMPLE), out_dir=str(out_dir), theme=None, frame=None, profile=None, content=None, artifact_id=None)
    print("dlp_deck selftest: build + render + inspect the bundled sample spec")
    return cmd_check(ns)


def cmd_layouts(args) -> int:
    print(LAYOUT_HELP)
    return 0


LAYOUT_HELP = """Layouts (slide["layout"]):
  panels     bands: [[panel, panel], [panel]]        rows of side-by-side panels (most general)
  focus      primary: {role, blocks}, secondary: [{role, blocks}]   one dominant panel + supporting panels
  triad      tiers: [{label, text} x3], why: {label, text}          All / Most / Some cards + Why footer
  steps      items: [{head?, text, num?}], direction: row|column    numbered process
  columns    items: [{head?, text, role?, reveal?}], widths?        side-by-side panels
  cards      items: [...], cols: N                                  grid of cards
  statement  text, support?                                         one big statement
  section    title, eyebrow?, subtitle?                             section divider
Panel: {id, role: amber|blue|green|neutral|dark, blocks: [block], reveal?: n}
Block: {style: main|question|body|support|label|num, text | {ref, field} | image+alt, emphasis?, bullets?, dlp_role?, align?}
Text may be literal (free decks) or "@record/field" / {"ref": record, "field": field} (governed decks).
"""


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp):
        sp.add_argument("--theme", choices=sorted(THEMES))
        sp.add_argument("--frame", choices=["rail", "header"])
        sp.add_argument("--profile", choices=sorted(PROFILES))
        sp.add_argument("--content", help="ContentSource content.json (governed mode: all text comes from it)")
        sp.add_argument("--artifact-id", dest="artifact_id")

    b = sub.add_parser("build", help="spec -> pptx (fails closed on any content that does not fit)")
    b.add_argument("spec")
    b.add_argument("--out", required=True)
    b.add_argument("--bindings-out")
    common(b)
    b.set_defaults(func=cmd_build)

    r = sub.add_parser("render", help="pptx -> pdf + png per slide + contact sheet")
    r.add_argument("deck")
    r.add_argument("--out-dir", required=True)
    r.add_argument("--cols", type=int, default=3)
    r.set_defaults(func=cmd_render)

    i = sub.add_parser("inspect", help="measure the rendered deck (works on any pptx)")
    i.add_argument("deck")
    i.add_argument("--out-dir", default="inspect-out")
    i.add_argument("--pdf", help="use an existing PDF export instead of rendering with LibreOffice")
    i.add_argument("--report")
    i.add_argument("--profile", choices=sorted(PROFILES), default="classroom")
    i.set_defaults(func=cmd_inspect)

    c = sub.add_parser("check", help="build + render + inspect + plugin audits (the working loop)")
    c.add_argument("spec")
    c.add_argument("--out-dir", required=True)
    common(c)
    c.set_defaults(func=cmd_check)

    s = sub.add_parser("selftest", help="verify python-pptx / LibreOffice / PyMuPDF work on this host")
    s.add_argument("--out-dir", default="dlp-deck-selftest")
    s.set_defaults(func=cmd_selftest)

    l = sub.add_parser("layouts", help="list layouts and spec fields")
    l.set_defaults(func=cmd_layouts)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

"""Glue between the deck renderer and the repository's evidence workflow.

``build_deck_artifact`` is what a trusted ``ASSEMBLE_CANONICAL_PACK`` host
command calls for the *deck* deliverable.  It builds ``pack.pptx`` from a spec
whose every string is a ContentSource reference, registers one binding per text
shape, renders every slide to PNG (the per-page renders the manifest requires),
and runs the render-level inspector.  It does not decide pedagogy, release a
pack, or write the manifest - the host still assembles PDFs, the manifest and
hands the result to independent review.
"""
from __future__ import annotations

import hashlib
import shutil
import sys
from pathlib import Path
from typing import Optional

_SCRIPTS = Path(__file__).resolve().parents[1]
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

from . import inspect_deck, render  # noqa: E402
from .deck import DeckBuilder  # noqa: E402


def _sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build_deck_artifact(spec: dict, *, content_path, out_dir, artifact_id: str = "deck", deck_name: str = "pack.pptx",
                        renders_dir: str = "renders", run_inspect: bool = True) -> dict:
    """Build the governed deck and everything the manifest needs from it.

    Returns ``{"artifact": {...}, "bindings": [...], "renders": [...], "inspect": {...}, "layout": {...}}`` where
    ``artifact`` / ``bindings`` / ``renders`` can be appended directly to the manifest (paths relative to ``out_dir``).
    Raises ``LayoutError`` (nothing written) when any slide's content does not fit at its role floor.
    """
    from content_source import ContentSource

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    source = ContentSource(content_path)
    meta = spec.get("meta", {})
    builder = DeckBuilder(theme="dlp", frame="rail", profile="classroom", source=source, artifact_id=artifact_id,
                          title=meta.get("title", ""), warmup=bool(meta.get("warmup", False)), page_numbers=False,
                          base_dir=str(out_dir))
    builder.build_from_spec(spec)
    deck = out_dir / deck_name
    layout = builder.save(deck)
    builder.apply_bindings(source, artifact_id)
    deck_hash = _sha256(deck)

    work = out_dir / ".dlp-render-work"
    manifest = render.render_all(deck, work)
    final_dir = out_dir / renders_dir
    final_dir.mkdir(parents=True, exist_ok=True)
    renders = []
    for entry in manifest["renders"]:
        target = final_dir / f"{artifact_id}-{entry['page']:03d}.png"
        shutil.copy2(entry["path"], target)
        renders.append({"artifact": artifact_id, "page": entry["page"], "path": target.relative_to(out_dir).as_posix(),
                        "sha256": _sha256(target), "artifact_sha256": deck_hash})
    inspection = None
    if run_inspect:
        inspection = inspect_deck.inspect_deck(deck, Path(manifest["pdf"]), profile_name="classroom")
    contact = final_dir / f"{artifact_id}-contact-sheet.jpg"
    shutil.copy2(manifest["contact_sheet"], contact)
    shutil.rmtree(work, ignore_errors=True)
    return {
        "artifact": {"id": artifact_id, "role": "deck", "path": deck_name, "sha256": deck_hash, "pages": len(layout["slides"])},
        "bindings": list(source.bindings),
        "renders": renders,
        "inspect": inspection,
        "layout": layout,
        "contact_sheet": contact.relative_to(out_dir).as_posix(),
        "font": manifest["font"],
    }

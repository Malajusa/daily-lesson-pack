"""Render a PPTX to PDF and PNG so the result can be *looked at* and measured.

LibreOffice (``soffice``) renders the deck; PyMuPDF rasterises the PDF.  When
Trebuchet MS is not installed the renderer maps it to the closest metric font
available so wrapping approximates the real thing, and reports the substitution
so a reviewer knows the render is a proxy.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

PREFERRED_SUBSTITUTES = ["Trebuchet MS", "Liberation Sans", "Arimo", "Arial", "Helvetica", "Nimbus Sans", "DejaVu Sans"]


class RenderError(RuntimeError):
    pass


def find_soffice() -> str:
    for name in ("soffice", "libreoffice", "/usr/bin/soffice", "/Applications/LibreOffice.app/Contents/MacOS/soffice"):
        path = shutil.which(name) or (name if os.path.exists(name) else None)
        if path:
            return path
    raise RenderError("LibreOffice (soffice) was not found. Install it, or render with PowerPoint/Keynote and run "
                      "`dlp_deck.py inspect --pdf <exported.pdf>` on the exported PDF.")


def installed_families() -> set[str]:
    try:
        out = subprocess.run(["fc-list", ":", "family"], capture_output=True, text=True, timeout=30).stdout
    except (OSError, subprocess.TimeoutExpired):
        return set()
    fams = set()
    for line in out.splitlines():
        for fam in line.split(","):
            fams.add(fam.strip())
    return fams


def font_plan() -> dict:
    fams = installed_families()
    for candidate in PREFERRED_SUBSTITUTES:
        if candidate in fams:
            return {"requested": "Trebuchet MS", "rendered_with": candidate, "exact": candidate == "Trebuchet MS",
                    "note": ("Trebuchet MS is installed; widths are exact." if candidate == "Trebuchet MS" else
                             f"Trebuchet MS is not installed; rendering with {candidate}. Wrapping is approximate "
                             "(the layout model already includes a width safety factor).")}
    return {"requested": "Trebuchet MS", "rendered_with": None, "exact": False,
            "note": "No metric-compatible font found; wrapping in the render may differ materially."}


def _fontconfig_file(plan: dict, tmp: Path) -> Optional[Path]:
    if plan["exact"] or not plan["rendered_with"]:
        return None
    conf = tmp / "fonts.conf"
    conf.write_text(f"""<?xml version="1.0"?>
<!DOCTYPE fontconfig SYSTEM "fonts.dtd">
<fontconfig>
  <include ignore_missing="yes">/etc/fonts/fonts.conf</include>
  <match target="pattern">
    <test qual="any" name="family"><string>Trebuchet MS</string></test>
    <edit name="family" mode="assign" binding="strong"><string>{plan['rendered_with']}</string></edit>
  </match>
</fontconfig>
""", encoding="utf-8")
    return conf


def render_pdf(pptx: Path, out_dir: Path, timeout: int = 240) -> tuple[Path, dict]:
    pptx = Path(pptx).resolve()
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    soffice = find_soffice()
    plan = font_plan()
    with tempfile.TemporaryDirectory(prefix="dlp-render-") as td:
        tmp = Path(td)
        env = dict(os.environ)
        conf = _fontconfig_file(plan, tmp)
        if conf:
            env["FONTCONFIG_FILE"] = str(conf)
        env["HOME"] = str(tmp)
        profile = tmp / "profile"
        cmd = [soffice, f"-env:UserInstallation=file://{profile}", "--headless", "--norestore", "--convert-to", "pdf",
               "--outdir", str(out_dir), str(pptx)]
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env)
        except subprocess.TimeoutExpired as exc:
            raise RenderError(f"LibreOffice timed out after {timeout}s") from exc
    pdf = out_dir / (pptx.stem + ".pdf")
    if not pdf.is_file():
        raise RenderError("LibreOffice produced no PDF: " + (res.stderr or res.stdout)[-800:])
    return pdf, plan


def pdf_to_pngs(pdf: Path, out_dir: Path, *, width_px: int = 1920) -> list[Path]:
    try:
        import pymupdf as fitz
    except ImportError:  # PyMuPDF < 1.24.3
        import fitz
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    with fitz.open(pdf) as doc:
        for i, page in enumerate(doc, 1):
            zoom = width_px / page.rect.width
            pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
            path = out_dir / f"slide-{i:02d}.png"
            pix.save(path)
            paths.append(path)
    return paths


def contact_sheet(pngs: list[Path], out: Path, *, cols: int = 3, thumb_w: int = 640, label: bool = True) -> Path:
    from PIL import Image, ImageDraw
    if not pngs:
        raise RenderError("No slide images to assemble")
    thumbs = []
    for p in pngs:
        im = Image.open(p).convert("RGB")
        ratio = thumb_w / im.width
        thumbs.append(im.resize((thumb_w, int(im.height * ratio))))
    th = thumbs[0].height
    rows = (len(thumbs) + cols - 1) // cols
    pad, head = 10, 22 if label else 0
    sheet = Image.new("RGB", (cols * (thumb_w + pad) + pad, rows * (th + head + pad) + pad), (60, 60, 60))
    draw = ImageDraw.Draw(sheet)
    for i, im in enumerate(thumbs):
        x = pad + (i % cols) * (thumb_w + pad)
        y = pad + (i // cols) * (th + head + pad)
        if label:
            draw.text((x + 2, y + 5), f"slide {i + 1}", fill=(235, 235, 235))
        sheet.paste(im, (x, y + head))
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(out, quality=88)
    return out


def sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def render_all(pptx: Path, out_dir: Path, *, sheet_cols: int = 3) -> dict:
    """Render PDF, one PNG per slide, a contact sheet and a render manifest (path + sha256 per page)."""
    pptx = Path(pptx)
    out_dir = Path(out_dir)
    pdf, plan = render_pdf(pptx, out_dir)
    pngs = pdf_to_pngs(pdf, out_dir / "slides")
    sheet = contact_sheet(pngs, out_dir / "contact-sheet.jpg", cols=sheet_cols)
    deck_hash = sha256(pptx)
    manifest = {
        "deck": str(pptx), "artifact_sha256": deck_hash, "pdf": str(pdf), "pdf_sha256": sha256(pdf), "font": plan,
        "renders": [{"page": i, "path": str(p), "sha256": sha256(p), "artifact_sha256": deck_hash} for i, p in enumerate(pngs, 1)],
        "contact_sheet": str(sheet),
    }
    (out_dir / "render-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return manifest

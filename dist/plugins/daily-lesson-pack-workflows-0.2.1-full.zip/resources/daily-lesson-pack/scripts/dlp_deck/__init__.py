"""dlp_deck - the supported Daily Lesson Pack slide renderer.

Layout engine + PowerPoint writer + render/inspect loop.  See
``references/deck-renderer.md`` for the contract.
"""
from .deck import DeckBuilder, LayoutError  # noqa: F401

__version__ = "1.0.0"

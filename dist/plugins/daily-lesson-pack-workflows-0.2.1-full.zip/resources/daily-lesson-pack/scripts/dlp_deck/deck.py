"""DeckBuilder: turns a declarative deck spec into a PowerPoint using the fit engine.

Two modes
---------
* **Governed** (``source=ContentSource(...)``): every visible string must be a
  reference to a canonical ContentSource field.  The builder writes one text
  shape per field, records the ``(page, shape_id, record, field)`` bindings the
  manifest needs, and refuses literal text.  Only the approved ``dlp`` theme,
  ``rail`` frame and ``classroom`` profile are allowed.
* **Free** (no source): literal text is accepted.  Used for non-release decks
  (staff PD, briefings) so they can share the same visual quality.

Spec text values
----------------
``"literal"`` · ``{"ref": "record", "field": "prompt"}`` · ``"@record/field"``
with optional ``"emphasis": [{"text": "beak", "scale": 1.25, "bold": true}]``
on blocks.  Emphasis never changes the visible string.
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from . import engine, metrics, pptx_writer as W
from .engine import Band, Block, FitFailure, PanelSpec, PlacedBlock, PlacedPanel, Solution
from .tokens import (FRAME, FRAMES, PROFILES, ROLE_NAMES, SLIDE_H_IN, SLIDE_W_IN, THEMES, contrast, profile as get_profile,
                     theme as get_theme)

ROLE_LABEL = {"amber": "Reminder", "blue": "Question", "green": "Answer", "neutral": "Support", "dark": "Focus"}


class LayoutError(Exception):
    def __init__(self, failures: list[dict]):
        self.failures = failures
        lines = []
        for f in failures:
            lines.append(f"slide {f.get('slide')}: {f.get('code')}: {f.get('message')}")
        super().__init__("\n".join(lines))


@dataclass
class Text:
    value: str
    ref: Optional[tuple[str, str]] = None


class DeckBuilder:
    def __init__(self, *, theme: str = "dlp", frame: str = "rail", profile: str = "classroom", source=None,
                 artifact_id: str = "deck", title: str = "", warmup: bool = False, page_numbers: bool = False,
                 base_dir: Optional[str] = None):
        if theme not in THEMES:
            raise ValueError(f"Unknown theme {theme!r}; choose from {sorted(THEMES)}")
        if frame not in FRAMES:
            raise ValueError(f"Unknown frame {frame!r}; choose from {list(FRAMES)}")
        if profile not in PROFILES:
            raise ValueError(f"Unknown profile {profile!r}; choose from {sorted(PROFILES)}")
        self.theme_name, self.frame, self.profile_name = theme, frame, profile
        self.theme, self.profile = get_theme(theme), get_profile(profile)
        self.source = source
        self.governed = source is not None
        if self.governed:
            problems = []
            if theme != "dlp":
                problems.append("theme must be 'dlp'")
            if frame != "rail":
                problems.append("frame must be 'rail'")
            if profile != "classroom":
                problems.append("profile must be 'classroom'")
            if problems:
                raise ValueError("A Daily Lesson Pack release deck (ContentSource mode) must use the approved visual "
                                 "system: " + ", ".join(problems) + ".")
        self.artifact_id = artifact_id
        self.default_warmup = warmup
        self.page_numbers = page_numbers and not self.governed
        self.base_dir = Path(base_dir) if base_dir else Path.cwd()
        self.prs = W.new_presentation(theme, title)
        self.layout = self.prs.slide_layouts[0]
        self.reports: list[dict] = []
        self.bindings: list[dict] = []
        self.failures: list[dict] = []

    # ------------------------------------------------------------------ text
    def _text(self, value: Any, *, where: str) -> Text:
        """Resolve a spec value into text plus an optional ContentSource reference."""
        ref = None
        if isinstance(value, dict) and "ref" in value:
            ref = (str(value["ref"]), str(value["field"]))
        elif isinstance(value, str) and value.startswith("@") and "/" in value:
            rec, fld = value[1:].split("/", 1)
            ref = (rec, fld)
        if ref is not None:
            if self.source is None:
                raise ValueError(f"{where}: a ContentSource reference was given but the deck has no source")
            return Text(self.source.text(*ref), ref)
        if isinstance(value, dict):
            value = value.get("text", "")
        if not isinstance(value, str):
            raise ValueError(f"{where}: text must be a string or a reference")
        if self.governed and value.strip():
            raise ValueError(f"{where}: literal text {value[:50]!r} is not allowed in governed mode; "
                             "put it in ContentSource documents/tasks and reference it")
        return Text(value, None)

    def _block(self, spec: Any, *, default_style: str, where: str) -> Block:
        if isinstance(spec, (str,)) or (isinstance(spec, dict) and "ref" in spec and "style" not in spec and "text" not in spec):
            spec = {"text": spec}
        style = spec.get("style", default_style)
        if style not in self.profile["ranges"]:
            raise ValueError(f"{where}: unknown style {style!r}; choose from {sorted(self.profile['ranges'])}")
        if "image" in spec:
            path = Path(spec["image"])
            if not path.is_absolute():
                path = self.base_dir / path
            from PIL import Image
            with Image.open(path) as im:
                aspect = im.width / im.height
            if not spec.get("alt"):
                raise ValueError(f"{where}: images need alt text")
            return Block(style=style, paras=[], text="", image={"path": str(path), "alt": spec["alt"], "aspect": aspect,
                                                                  "max_h_in": float(spec.get("max_h_in", 3.2))})
        raw = spec.get("text", spec.get("ref"))
        if "ref" in spec and "text" not in spec:
            raw = {"ref": spec["ref"], "field": spec["field"]}
        t = self._text(raw, where=where)
        paras = metrics.plain_paras(t.value, bullets=bool(spec.get("bullets")), emphasis=spec.get("emphasis"))
        dlp_role = spec.get("dlp_role") or self.profile["dlp_roles"].get(style, "main")
        return Block(style=style, paras=paras, text=t.value, ref=t.ref, dlp_role=dlp_role, align=spec.get("align", "auto"),
                     bold=spec.get("bold"), color=spec.get("color"), fixed_pt=spec.get("size_pt"))

    # ------------------------------------------------------------ macro layouts
    def _panel_spec(self, spec: dict, pid: str, *, default_role: str, default_style: str, where: str) -> PanelSpec:
        role = spec.get("role", default_role)
        if role not in ROLE_NAMES:
            raise ValueError(f"{where}: unknown role {role!r}; choose from {ROLE_NAMES}")
        blocks_in = spec.get("blocks")
        if blocks_in is None:
            blocks_in = [spec]
        blocks = [self._block(b, default_style=default_style, where=f"{where}/block{i}") for i, b in enumerate(blocks_in)]
        return PanelSpec(id=spec.get("id", pid), role=role, blocks=blocks, accent=spec.get("accent", "bar"),
                         reveal=spec.get("reveal"), valign=spec.get("valign", "middle"),
                         pad_x=spec.get("pad_x"), pad_y=spec.get("pad_y"))

    def _bands(self, spec: dict, where: str) -> tuple[list[Band], str]:
        layout = spec.get("layout", "panels")
        role = spec.get("role", "blue")
        pid = lambda n: f"{spec.get('id', 'slide')}-{n}"  # noqa: E731
        bands: list[Band] = []

        if layout == "panels":
            for bi, band in enumerate(spec["bands"]):
                if isinstance(band, list):
                    band = {"panels": band}
                panels = [self._panel_spec(p, pid(f"b{bi}p{pi}"), default_role=role, default_style="main",
                                           where=f"{where}/band{bi}/panel{pi}")
                          for pi, p in enumerate(band["panels"])]
                bands.append(Band(panels=panels, widths=band.get("widths"), weight=band.get("weight", 1.0),
                                  cap=band.get("cap", 1.9), min_h_in=band.get("min_h_in", 0.0)))
        elif layout == "focus":
            primary = dict(spec["primary"]) if "primary" in spec else {"blocks": spec["blocks"]}
            primary.setdefault("role", role)
            bands.append(Band([self._panel_spec(primary, pid("main"), default_role=role, default_style="main",
                                                where=f"{where}/primary")], weight=2.0, cap=1.8))
            for si, sec in enumerate(spec.get("secondary", [])):
                sec = dict(sec)
                sec.setdefault("role", "neutral")
                bands.append(Band([self._panel_spec(sec, pid(f"sec{si}"), default_role="neutral", default_style="support",
                                                    where=f"{where}/secondary{si}")], weight=1.0, cap=1.4))
        elif layout == "triad":
            tier_role = spec.get("tier_role", role)
            panels = []
            for ti, tier in enumerate(spec["tiers"]):
                blocks = [{"style": "label", "dlp_role": "label", **_as_dict(tier["label"])},
                          {"style": spec.get("tier_style", "question"), **_as_dict(tier["text"])}]
                panels.append(self._panel_spec({"role": tier_role, "blocks": blocks, "valign": "top"},
                                               pid(f"tier{ti}"), default_role=tier_role, default_style="question",
                                               where=f"{where}/tier{ti}"))
            bands.append(Band(panels, weight=2.0, cap=1.7))
            if spec.get("why"):
                why = spec["why"]
                blocks = []
                if why.get("label"):
                    blocks.append({"style": "label", "dlp_role": "label", **_as_dict(why["label"])})
                blocks.append({"style": "support", "dlp_role": "why", **_as_dict(why["text"])})
                bands.append(Band([self._panel_spec({"role": spec.get("why_role", "green"), "blocks": blocks},
                                                    pid("why"), default_role="green", default_style="support",
                                                    where=f"{where}/why")], weight=1.0, cap=1.5))
        elif layout == "steps":
            items = spec["items"]
            direction = spec.get("direction", "row")
            numbered = spec.get("numbers", True)
            if self.governed:
                # a numeral is visible text, so in governed mode it must be a referenced field
                numbered = numbered and all("num" in it for it in items)
            item_role = spec.get("item_role", role)
            if direction == "row":
                panels = []
                for i, item in enumerate(items):
                    blocks = []
                    if numbered:
                        blocks.append({"style": "num", "color": "accent", "align": "l",
                                       **_as_dict(item.get("num", str(i + 1) if not self.governed else None))})
                    if item.get("head"):
                        blocks.append({"style": "label", **_as_dict(item["head"])})
                    blocks.append({"style": spec.get("text_style", "body"), **_as_dict(item["text"])})
                    panels.append(self._panel_spec({"role": item_role, "blocks": blocks, "valign": "top", "reveal": item.get("reveal")}, pid(f"step{i}"),
                                                   default_role=item_role, default_style="body", where=f"{where}/step{i}"))
                bands.append(Band(panels, weight=1.0, cap=1.4))
            else:
                for i, item in enumerate(items):
                    row = []
                    if numbered:
                        row.append(self._panel_spec({"role": "dark" if self.theme_name != "dlp" else "neutral",
                                                     "blocks": [{"style": "num", "align": "ctr",
                                                                 **_as_dict(item.get("num", str(i + 1) if not self.governed else None))}],
                                                     "pad_x": 0.16, "accent": None, "reveal": item.get("reveal")},
                                                    pid(f"num{i}"), default_role="neutral", default_style="num",
                                                    where=f"{where}/num{i}"))
                    blocks = []
                    if item.get("head"):
                        blocks.append({"style": "label", **_as_dict(item["head"])})
                    blocks.append({"style": spec.get("text_style", "body"), **_as_dict(item["text"])})
                    row.append(self._panel_spec({"role": item_role, "blocks": blocks, "reveal": item.get("reveal")}, pid(f"step{i}"),
                                                default_role=item_role, default_style="body", where=f"{where}/step{i}"))
                    bands.append(Band(row, widths=[1.0, 12.0] if numbered else None, weight=1.0, cap=1.35))
        elif layout in ("columns", "cards"):
            items = spec["items"]
            ncols = spec.get("cols", len(items)) if layout == "cards" else len(items)
            for start in range(0, len(items), ncols):
                row = []
                for i, item in enumerate(items[start:start + ncols], start=start):
                    blocks = []
                    if item.get("head"):
                        blocks.append({"style": "label", **_as_dict(item["head"])})
                    body = item.get("text")
                    if body is not None:
                        blocks.append({"style": spec.get("text_style", "body"), "bullets": item.get("bullets", False),
                                       **_as_dict(body)})
                    row.append(self._panel_spec({"role": item.get("role", role), "blocks": blocks, "valign": "top",
                                                 "reveal": item.get("reveal")}, pid(f"c{i}"), default_role=role,
                                                default_style="body", where=f"{where}/item{i}"))
                widths = spec.get("widths") if layout == "columns" else None
                bands.append(Band(row, widths=widths, weight=1.0, cap=1.4))
        elif layout == "statement":
            blocks = [{"style": "main", **_as_dict(spec["text"])}]
            if spec.get("support"):
                blocks.append({"style": "support", **_as_dict(spec["support"])})
            bands.append(Band([self._panel_spec({"role": spec.get("role", "dark"), "blocks": blocks}, pid("statement"),
                                                default_role="dark", default_style="main", where=f"{where}/statement")],
                              weight=1.0, cap=2.0))
        else:
            raise ValueError(f"{where}: unknown layout {layout!r}")
        return bands, role

    # ------------------------------------------------------------------ slides
    def add_slide(self, spec: dict) -> dict:
        n = len(self.reports) + 1
        sid = spec.get("id", f"s{n}")
        where = f"slide {n} ({sid})"
        if spec.get("layout") == "section":
            return self._add_section(spec, n, sid, where)
        spec = dict(spec)
        spec.setdefault("id", sid)
        bands, role = self._bands(spec, where)
        ids = [p.id for b in bands for p in b.panels]
        if len(ids) != len(set(ids)):
            raise ValueError(f"{where}: duplicate panel ids {sorted(i for i in ids if ids.count(i) > 1)}")
        if any(("|" in i) or (":" in i) or (not i) for i in ids):
            raise ValueError(f"{where}: panel ids must be non-empty and contain no '|' or ':'")
        primary_role = bands[0].panels[0].role if bands and bands[0].panels else role
        slide_role = spec.get("rail_role", spec.get("role", primary_role))
        warmup = spec.get("warmup", self.default_warmup)

        eyebrow = self._text(spec.get("eyebrow", self._default_eyebrow(spec, slide_role)), where=f"{where}/eyebrow")
        title = self._text(spec.get("title", ""), where=f"{where}/title")
        geometry = self._frame_geometry(eyebrow.value, title.value)
        region = (FRAME["margin_l"], geometry["body_top"], SLIDE_W_IN - FRAME["margin_l"] - FRAME["margin_r"],
                  FRAME["body_bottom"] - geometry["body_top"])
        sol = engine.solve(bands, region, profile_name=self.profile_name, warmup=warmup)
        report: dict = {"slide": n, "id": sid, "layout": spec.get("layout", "panels"), "role": slide_role,
                        "warmup": warmup, "ok": sol.ok, "warnings": list(sol.warnings)}
        if not geometry["eyebrow_ok"]:
            self._fail(report, "eyebrow_too_long", f"Eyebrow {eyebrow.value!r} does not fit on one line at 14 pt; shorten it.")
        if title.value and geometry["title_lines"] > 2:
            self._fail(report, "title_too_long", f"Title needs {geometry['title_lines']} lines; shorten it to at most two.")
        if not sol.ok:
            self._fail(report, sol.failure.code, sol.failure.message, detail=sol.failure.detail,
                       required_h_in=round(sol.failure.required_h_in, 2), available_h_in=round(sol.failure.available_h_in, 2))
            self.reports.append(report)
            return report
        self._check_contrast(report, sol, slide_role)
        report.update({"t": round(sol.t, 3), "sizes_pt": sol.sizes, "occupancy": round(sol.occupancy, 3),
                       "body_region_in": [round(v, 3) for v in region]})
        if not report["ok"]:
            self.reports.append(report)
            return report
        slide = self.prs.slides.add_slide(self.layout)
        shapes = self._draw(slide, n, spec, sol, slide_role, eyebrow, title, geometry)
        report["shapes"] = shapes
        if spec.get("notes"):
            note = self._text(spec["notes"], where=f"{where}/notes")
            slide.notes_slide.notes_text_frame.text = note.value
        self.reports.append(report)
        return report

    def _add_section(self, spec: dict, n: int, sid: str, where: str) -> dict:
        role = spec.get("role", "neutral")
        t_eye = self._text(spec.get("eyebrow", ""), where=f"{where}/eyebrow")
        t_title = self._text(spec.get("title", ""), where=f"{where}/title")
        t_sub = self._text(spec.get("subtitle", ""), where=f"{where}/subtitle") if spec.get("subtitle") else None
        slide = self.prs.slides.add_slide(self.layout)
        W.set_slide_background(slide, self.theme["bg"])
        colors = self.theme["roles"][role]
        shapes: list[dict] = []
        if self.frame == "rail":
            rail = W.add_rect(slide, 0, 0, FRAME["rail_w"], SLIDE_H_IN, fill=colors["strong"], name="Rail")
            W.send_to_back(rail)
            shapes.append(self._shape_info(rail, "rail"))
        left = 0.9
        width = SLIDE_W_IN - left - 0.9
        title_size = 60.0
        while title_size > 38:
            m = metrics.measure([metrics.Para([metrics.Run(t_title.value)])], title_size, width - 0.06, default_bold=True)
            if m.n_lines <= 2:
                break
            title_size -= 2
        m = metrics.measure([metrics.Para([metrics.Run(t_title.value)])], title_size, width - 0.06, default_bold=True)
        title_h = m.height_in + 0.2
        sub_h = 0.0
        if t_sub is not None:
            sub_h = metrics.measure([metrics.Para([metrics.Run(t_sub.value)])], 28.0, width - 0.06).height_in + 0.2 + 0.15
        y = max(1.6, (SLIDE_H_IN - (title_h + sub_h)) / 2 - 0.1)
        report = {"slide": n, "id": sid, "layout": "section", "role": role, "ok": True, "warnings": [],
                  "sizes_pt": {"title": title_size}}
        if t_eye.value:
            eb = W.add_textbox(slide, 0.60, FRAME["eyebrow_y"], SLIDE_W_IN - 0.60 - FRAME["margin_r"], FRAME["eyebrow_h"], name="Eyebrow")
            W.fill_paragraphs(eb.text_frame, [metrics.Para([metrics.Run(t_eye.value)])], size_pt=FRAME["eyebrow_pt"], bold=True,
                              color=colors["accent_text"], accent_color=colors["accent_text"], align="l")
            self._bind(t_eye, n, eb)
            shapes.append(self._shape_info(eb, "text", size=FRAME["eyebrow_pt"], text=t_eye.value))
        tb = slide.shapes.title
        tb.name = "Title"
        tb.left, tb.top, tb.width, tb.height = W.emu(left), W.emu(y), W.emu(width), W.emu(title_h)
        W.style_text_frame(tb.text_frame, anchor="top")
        W.fill_paragraphs(tb.text_frame, [metrics.Para([metrics.Run(t_title.value)])], size_pt=title_size, bold=True,
                          color=self.theme["ink"], accent_color=colors["accent_text"], align="l")
        self._bind(t_title, n, tb)
        shapes.append(self._shape_info(tb, "text", size=title_size, text=t_title.value))
        if t_sub is not None:
            sub = W.add_textbox(slide, left, y + title_h + 0.15, width, sub_h - 0.15, name="Subtitle")
            W.fill_paragraphs(sub.text_frame, [metrics.Para([metrics.Run(t_sub.value)])], size_pt=28.0, bold=False,
                              color=self.theme["muted"], accent_color=colors["accent_text"], align="l")
            self._bind(t_sub, n, sub)
            shapes.append(self._shape_info(sub, "text", size=28.0, text=t_sub.value))
        report["shapes"] = shapes
        self.reports.append(report)
        return report

    def _default_eyebrow(self, spec: dict, role: str) -> str:
        if self.governed:
            return ""
        comp = spec.get("component", "")
        label = ROLE_LABEL.get(role, "")
        return f"{comp.upper()} • {label.upper()}" if comp else label.upper()

    def _frame_geometry(self, eyebrow: str, title: str) -> dict:
        width = SLIDE_W_IN - 0.60 - FRAME["margin_r"]
        eb_size, eb_ok = engine.fit_eyebrow(eyebrow, width) if eyebrow else (FRAME["eyebrow_pt"], True)
        t_size, t_lines, t_h = engine.fit_title(title, width, self.profile_name) if title else (30.0, 1, FRAME["title_line_h_in"])
        if self.frame == "rail":
            body_top = FRAME["title_y"] + t_h + FRAME["title_gap_after"] + (0.0 if t_lines == 1 else 0.0)
            band_h = 0.0
        else:
            band_h = FRAME["title_y"] + t_h + 0.22
            body_top = band_h + 0.28
        return {"eyebrow_size": eb_size, "eyebrow_ok": eb_ok, "title_size": t_size, "title_lines": t_lines,
                "title_h": t_h, "body_top": round(body_top, 3), "band_h": band_h, "text_w": width}

    def _fail(self, report: dict, code: str, message: str, **extra) -> None:
        item = {"slide": report["slide"], "id": report["id"], "code": code, "message": message, **extra}
        self.failures.append(item)
        report.setdefault("failures", []).append(item)
        report["ok"] = False

    def _check_contrast(self, report: dict, sol: Solution, slide_role: str) -> None:
        for pp in sol.panels:
            colors = self.theme["roles"][pp.spec.role]
            ink = pp.spec.ink or colors["ink"]
            ratio = contrast(ink, colors["fill"])
            if ratio < 4.5:
                self._fail(report, "low_contrast", f"Panel {pp.spec.id!r}: ink {ink} on {colors['fill']} is {ratio:.2f}:1 (< 4.5:1)")
            accent = colors["accent_text"] if colors["ink"] != "FFFFFF" else self.theme["band_kicker"]
            for pb in pp.blocks:
                if pb.block.color == "accent" or any(r.color == "accent" for p in pb.block.paras for r in p.runs):
                    r2 = contrast(accent, colors["fill"])
                    if r2 < 4.5:
                        self._fail(report, "low_contrast", f"Panel {pp.spec.id!r}: accent text {accent} on "
                                                         f"{colors['fill']} is {r2:.2f}:1 (< 4.5:1)")

    # ------------------------------------------------------------------ drawing
    def _bind(self, t: Text, page: int, shape) -> None:
        if t.ref is not None:
            self.bindings.append({"artifact": self.artifact_id, "record": t.ref[0], "field": t.ref[1], "page": page,
                                  "shape_id": shape.shape_id})
        elif self.governed and t.value.strip():
            raise ValueError(f"page {page}: governed text without a source reference: {t.value[:60]!r}")

    def _shape_info(self, shape, kind: str, *, size: Optional[float] = None, text: str = "", panel: str = "") -> dict:
        return {"name": shape.name, "shape_id": shape.shape_id, "kind": kind,
                "box_in": [round(shape.left / 914400, 4), round(shape.top / 914400, 4),
                           round(shape.width / 914400, 4), round(shape.height / 914400, 4)],
                "size_pt": size, "text": text, "panel": panel}

    def _draw(self, slide, n: int, spec: dict, sol: Solution, slide_role: str, eyebrow: Text, title: Text, geo: dict) -> list[dict]:
        W.set_slide_background(slide, self.theme["bg"])
        colors = self.theme["roles"][slide_role]
        shapes: list[dict] = []
        if self.frame == "rail":
            rail = W.add_rect(slide, 0, 0, FRAME["rail_w"], SLIDE_H_IN, fill=colors["strong"], name="Rail")
            W.send_to_back(rail)
            shapes.append(self._shape_info(rail, "rail"))
            eb_color, title_color = colors["accent_text"], self.theme["ink"]
        else:
            band = W.add_rect(slide, 0, 0, SLIDE_W_IN, geo["band_h"], fill=self.theme["band"], name="Header band")
            rule = W.add_rect(slide, 0, geo["band_h"], SLIDE_W_IN, 0.06, fill=self.theme["band_rule"], name="Header rule")
            W.send_to_back(rule)
            W.send_to_back(band)
            shapes.append(self._shape_info(band, "band"))
            shapes.append(self._shape_info(rule, "rule"))
            eb_color, title_color = self.theme["band_kicker"], self.theme["band_ink"]
        text_x = 0.60
        if eyebrow.value:
            eb = W.add_textbox(slide, text_x, FRAME["eyebrow_y"], geo["text_w"], FRAME["eyebrow_h"], name="Eyebrow")
            W.fill_paragraphs(eb.text_frame, [metrics.Para([metrics.Run(eyebrow.value)])], size_pt=geo["eyebrow_size"],
                              bold=True, color=eb_color, accent_color=eb_color, align="l")
            self._bind(eyebrow, n, eb)
            shapes.append(self._shape_info(eb, "text", size=geo["eyebrow_size"], text=eyebrow.value))
        if title.value:
            tb = slide.shapes.title
            tb.name = "Title"
            tb.left, tb.top, tb.width, tb.height = W.emu(text_x), W.emu(FRAME["title_y"]), W.emu(geo["text_w"]), W.emu(geo["title_h"])
            W.style_text_frame(tb.text_frame, anchor="middle")
            W.fill_paragraphs(tb.text_frame, [metrics.Para([metrics.Run(title.value)])], size_pt=geo["title_size"], bold=True,
                              color=title_color, accent_color=eb_color, align="l")
            self._bind(title, n, tb)
            shapes.append(self._shape_info(tb, "text", size=geo["title_size"], text=title.value))
        else:
            ph = slide.shapes.title
            ph._element.getparent().remove(ph._element)

        reveal_groups: dict[int, list[tuple[int, str]]] = {}
        for pp in sol.panels:
            rc = self.theme["roles"][pp.spec.role]
            pid = pp.spec.id
            panel_shape = W.add_rect(slide, pp.x, pp.y, pp.w, pp.h, fill=rc["fill"], line=rc["line"], line_pt=FRAME["panel_line_pt"],
                                     radius_in=FRAME["corner_in"], name=f"DLP:panel:{pid}")
            shapes.append(self._shape_info(panel_shape, "panel", panel=pid))
            group: list[tuple[int, str]] = [(panel_shape.shape_id, "sp")]
            if pp.spec.accent == "bar":
                bar = W.add_rect(slide, pp.x + 0.0, pp.y + FRAME["corner_in"], 0.09, max(0.1, pp.h - 2 * FRAME["corner_in"]),
                                 fill=rc["strong"], name=f"Accent {pid}")
                shapes.append(self._shape_info(bar, "accent", panel=pid))
                group.append((bar.shape_id, "sp"))
            for pb in pp.blocks:
                blk = pb.block
                if blk.image:
                    pic = W.add_picture(slide, blk.image["path"], pb.x, pb.y, pb.w, pb.h, alt=blk.image["alt"], name=f"Picture {pid}")
                    shapes.append(self._shape_info(pic, "picture", panel=pid))
                    group.append((pic.shape_id, "pic"))
                    continue
                tb = W.add_textbox(slide, pb.x, pb.y, pb.w, pb.h, name=f"DLP:{blk.dlp_role}|panel={pid}")
                W.style_text_frame(tb.text_frame, anchor=pb.anchor)
                ink = pp.spec.ink or rc["ink"]
                accent = rc["accent_text"] if rc["ink"] != "FFFFFF" else self.theme["band_kicker"]
                color = ink if blk.color in (None, "ink") else (accent if blk.color == "accent" else blk.color)
                W.fill_paragraphs(tb.text_frame, blk.paras, size_pt=pb.size_pt, bold=engine.is_bold(blk, self.profile),
                                  color=color, accent_color=accent, align=pb.align)
                self._bind(Text(blk.text, blk.ref), n, tb)
                shapes.append(self._shape_info(tb, "text", size=pb.size_pt, text=blk.text, panel=pid))
                group.append((tb.shape_id, "text"))
            if pp.spec.reveal is not None:
                reveal_groups.setdefault(int(pp.spec.reveal), []).extend(group)
        if reveal_groups:
            W.add_appear_sequence(slide, [reveal_groups[k] for k in sorted(reveal_groups)])
        if self.page_numbers:
            pn = W.add_textbox(slide, SLIDE_W_IN - 1.0, SLIDE_H_IN - 0.45, 0.5, 0.3, name="Page number")
            W.fill_paragraphs(pn.text_frame, [metrics.Para([metrics.Run(str(n))])], size_pt=14, bold=False,
                              color=self.theme["muted"], accent_color=self.theme["muted"], align="r")
        return shapes

    # --------------------------------------------------------------------- output
    def build_from_spec(self, spec: dict) -> None:
        for s in spec["slides"]:
            self.add_slide(s)

    def save(self, path) -> dict:
        if self.failures:
            raise LayoutError(self.failures)
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.prs.save(path)
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        report = {"deck": str(path), "sha256": sha, "theme": self.theme_name, "frame": self.frame, "profile": self.profile_name,
                  "governed": self.governed, "slides": self.reports, "bindings": self.bindings}
        return report

    def apply_bindings(self, source=None, artifact_id: Optional[str] = None) -> list[dict]:
        """Register every recorded shape binding on a ContentSource (call after save)."""
        source = source or self.source
        out = []
        for b in self.bindings:
            out.append(source.bind(artifact_id or b["artifact"], b["record"], b["field"], b["page"], shape_id=b["shape_id"]))
        return out


def _as_dict(value: Any) -> dict:
    """Normalise a text-ish spec value into keyword form for block construction."""
    if value is None:
        return {"text": ""}
    if isinstance(value, dict):
        if "ref" in value and "field" in value:
            return {"ref": value["ref"], "field": value["field"], **{k: v for k, v in value.items() if k not in ("ref", "field")}}
        return dict(value)
    return {"text": value}


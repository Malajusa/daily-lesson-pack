"""Low-level python-pptx helpers.  No layout decisions are made here."""
from __future__ import annotations

import copy
import re
from typing import Iterable, Optional

from lxml import etree
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Emu, Pt

from . import metrics
from .tokens import EMU_PER_IN, FONT, FRAME, SLIDE_H_IN, SLIDE_W_IN, THEMES

NS_A = "http://schemas.openxmlformats.org/drawingml/2006/main"
NS_P = "http://schemas.openxmlformats.org/presentationml/2006/main"


def emu(inches: float) -> Emu:
    return Emu(int(round(inches * EMU_PER_IN)))


def rgb(hexstr: str) -> RGBColor:
    return RGBColor.from_string(hexstr.upper().lstrip("#"))


# ---------------------------------------------------------------------------
# Presentation scaffolding
# ---------------------------------------------------------------------------
def new_presentation(theme_name: str, title: str = "") -> Presentation:
    theme = THEMES[theme_name]
    prs = Presentation()
    prs.slide_width = emu(SLIDE_W_IN)
    prs.slide_height = emu(SLIDE_H_IN)
    # keep only the "Title Only" layout, renamed; remove the rest so the master stays tidy
    keep = None
    for layout in list(prs.slide_layouts):
        if layout.name == "Title Only":
            keep = layout
    for layout in list(prs.slide_layouts):
        if layout is not keep:
            try:
                prs.slide_layouts.remove(layout)
            except Exception:
                pass
    if keep is not None:
        keep.name = "DLP Content"
        _style_layout_title(keep, theme)
    _patch_theme(prs, theme)
    _set_master_background(prs, theme["bg"])
    if title:
        prs.core_properties.title = title
    prs.core_properties.author = ""
    return prs


def _style_layout_title(layout, theme: dict) -> None:
    for ph in layout.placeholders:
        if ph.placeholder_format.type is not None and "TITLE" in str(ph.placeholder_format.type):
            ph.left, ph.top = emu(0.60), emu(FRAME["title_y"])
            ph.width, ph.height = emu(SLIDE_W_IN - 0.60 - FRAME["margin_r"]), emu(FRAME["title_line_h_in"])
    # drop footer/date/number placeholders from the layout (we never use them)
    for ph in list(layout.placeholders):
        t = str(ph.placeholder_format.type)
        if any(k in t for k in ("DATE", "FOOTER", "SLIDE_NUMBER")):
            ph._element.getparent().remove(ph._element)


def _patch_theme(prs, theme: dict) -> None:
    master = prs.slide_master
    for rel in master.part.rels.values():
        if rel.reltype.endswith("/theme"):
            part = rel.target_part
            xml = part.blob.decode("utf-8")
            xml = re.sub(r'(<a:majorFont>\s*<a:latin typeface=")[^"]*(")', r"\g<1>%s\g<2>" % FONT, xml)
            xml = re.sub(r'(<a:minorFont>\s*<a:latin typeface=")[^"]*(")', r"\g<1>%s\g<2>" % FONT, xml)
            roles = theme["roles"]
            palette = {
                "dk1": theme["ink"], "lt1": "FFFFFF", "dk2": theme["band"], "lt2": theme["bg"],
                "accent1": roles["blue"]["strong"], "accent2": roles["green"]["strong"],
                "accent3": roles["amber"]["strong"], "accent4": roles["neutral"]["strong"],
                "accent5": roles["blue"]["line"], "accent6": roles["green"]["line"],
                "hlink": roles["blue"]["strong"], "folHlink": theme["muted"],
            }
            for tag, value in palette.items():
                xml = re.sub(r"(<a:%s>\s*)<a:(?:srgbClr|sysClr)[^>]*?(?:/>|>.*?</a:(?:srgbClr|sysClr)>)" % tag,
                             r'\g<1><a:srgbClr val="%s"/>' % value, xml, count=1, flags=re.S)
            xml = re.sub(r'<a:theme ([^>]*)name="[^"]*"', r'<a:theme \1name="DLP deck system"', xml, count=1)
            part._blob = xml.encode("utf-8")


def _set_master_background(prs, bg_hex: str) -> None:
    master = prs.slide_master
    cSld = master._element.find(qn("p:cSld"))
    existing = cSld.find(qn("p:bg"))
    if existing is not None:
        cSld.remove(existing)
    bg = etree.SubElement(cSld, qn("p:bg"))
    cSld.remove(bg)
    cSld.insert(0, bg)
    bgPr = etree.SubElement(bg, qn("p:bgPr"))
    fill = etree.SubElement(bgPr, qn("a:solidFill"))
    clr = etree.SubElement(fill, qn("a:srgbClr"))
    clr.set("val", bg_hex)
    etree.SubElement(bgPr, qn("a:effectLst"))


def set_slide_background(slide, bg_hex: str) -> None:
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = rgb(bg_hex)


# ---------------------------------------------------------------------------
# Shapes
# ---------------------------------------------------------------------------
def _strip_style(shape) -> None:
    el = shape._element
    style = el.find(qn("p:style"))
    if style is not None:
        el.remove(style)


def add_rect(slide, x, y, w, h, *, fill: Optional[str], line: Optional[str] = None, line_pt: float = 1.5,
             radius_in: float = 0.0, name: str = "Shape", descr: Optional[str] = None):
    shape_type = MSO_SHAPE.ROUNDED_RECTANGLE if radius_in > 0 else MSO_SHAPE.RECTANGLE
    shp = slide.shapes.add_shape(shape_type, emu(x), emu(y), emu(w), emu(h))
    _strip_style(shp)
    if radius_in > 0:
        shp.adjustments[0] = min(0.5, radius_in / max(0.01, min(w, h)))
    if fill:
        shp.fill.solid()
        shp.fill.fore_color.rgb = rgb(fill)
    else:
        shp.fill.background()
    if line:
        shp.line.color.rgb = rgb(line)
        shp.line.width = Pt(line_pt)
    else:
        shp.line.fill.background()
    shp.name = name
    _set_descr(shp, descr if descr is not None else "")
    _make_decorative(shp) if descr is None else None
    return shp


def _set_descr(shape, text: str) -> None:
    cNvPr = shape._element.xpath(".//p:cNvPr")[0]
    cNvPr.set("descr", text)


def _make_decorative(shape) -> None:
    """Mark a purely visual shape as decorative so screen readers skip it."""
    cNvPr = shape._element.xpath(".//p:cNvPr")[0]
    ext_lst = cNvPr.find(qn("a:extLst"))
    if ext_lst is None:
        ext_lst = etree.SubElement(cNvPr, qn("a:extLst"))
    ext = etree.SubElement(ext_lst, qn("a:ext"))
    ext.set("uri", "{C183D7F6-B498-43B3-948B-1728B52AA6E4}")
    deco = etree.SubElement(ext, "{http://schemas.microsoft.com/office/drawing/2017/decorative}decorative",
                            nsmap={"adec": "http://schemas.microsoft.com/office/drawing/2017/decorative"})
    deco.set("val", "1")


def send_to_back(shape) -> None:
    """Move a shape to the bottom of the z-order (just above the group properties) so titles stay first in reading order."""
    el = shape._element
    tree = el.getparent()
    tree.remove(el)
    tree.insert(2, el)


def add_line(slide, x1, y1, x2, y2, *, color: str, width_pt: float = 1.5, name: str = "Rule"):
    from pptx.enum.shapes import MSO_CONNECTOR
    conn = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, emu(x1), emu(y1), emu(x2), emu(y2))
    conn.line.color.rgb = rgb(color)
    conn.line.width = Pt(width_pt)
    conn.name = name
    _strip_style(conn)
    conn.line.color.rgb = rgb(color)
    conn.line.width = Pt(width_pt)
    return conn


def add_picture(slide, path: str, x, y, w, h, *, alt: str, name: str = "Picture"):
    pic = slide.shapes.add_picture(path, emu(x), emu(y), emu(w), emu(h))
    pic.name = name
    _set_descr(pic, alt)
    return pic


_ALIGN = {"l": PP_ALIGN.LEFT, "ctr": PP_ALIGN.CENTER, "r": PP_ALIGN.RIGHT}
_ANCHOR = {"top": MSO_ANCHOR.TOP, "middle": MSO_ANCHOR.MIDDLE, "bottom": MSO_ANCHOR.BOTTOM}


def style_text_frame(tf, *, anchor: str = "middle", inset_in: float = FRAME["text_inset_in"]) -> None:
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = emu(inset_in)
    tf.vertical_anchor = _ANCHOR[anchor]


def fill_paragraphs(tf, paras: list[metrics.Para], *, size_pt: float, bold: bool, color: str,
                    accent_color: str, align: str, gap_scale: float = 1.0) -> None:
    """Write paragraphs/runs into an (empty) text frame with explicit font, size and colour on every run."""
    first = True
    for index, para in enumerate(paras):
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.alignment = _ALIGN[align]
        p.line_spacing = 1.0
        if index:
            gap_em = para.gap_before_em if para.gap_before_em is not None else metrics.PARA_GAP_EM
            p.space_before = Pt(round(gap_em * size_pt * para.scale, 1))
        else:
            p.space_before = Pt(0)
        p.space_after = Pt(0)
        _set_bullet(p, para.bullet, size_pt * para.scale, accent_color)
        for run in para.runs:
            if run.text == "":
                continue
            r = p.add_run()
            r.text = run.text
            f = r.font
            f.name = FONT
            f.size = Pt(round(size_pt * para.scale * run.scale * 2) / 2)
            f.bold = bool(run.bold or bold)
            f.italic = bool(run.italic)
            col = run.color
            if col == "accent":
                col = accent_color
            f.color.rgb = rgb(col or color)
        # make an end-paragraph run property so empty lines keep the right height
        _end_para_props(p, size_pt * para.scale)


def _end_para_props(p, size_pt: float) -> None:
    pel = p._p
    end = pel.find(qn("a:endParaRPr"))
    if end is None:
        end = etree.SubElement(pel, qn("a:endParaRPr"))
    end.set("sz", str(int(round(size_pt * 100))))
    for child in list(end):
        end.remove(child)
    latin = etree.SubElement(end, qn("a:latin"))
    latin.set("typeface", FONT)


def _set_bullet(p, bullet: bool, size_pt: float, color: str) -> None:
    pPr = p._p.get_or_add_pPr()
    for tag in ("a:buNone", "a:buChar", "a:buAutoNum", "a:buFont", "a:buClr", "a:buSzPct"):
        for el in pPr.findall(qn(tag)):
            pPr.remove(el)
    if bullet:
        indent = int(metrics.BULLET_INDENT_EM * size_pt * 12700)
        pPr.set("marL", str(indent))
        pPr.set("indent", str(-indent))
        clr = etree.SubElement(pPr, qn("a:buClr"))
        c = etree.SubElement(clr, qn("a:srgbClr"))
        c.set("val", color)
        font = etree.SubElement(pPr, qn("a:buFont"))
        font.set("typeface", "Arial")
        ch = etree.SubElement(pPr, qn("a:buChar"))
        ch.set("char", "•")
    else:
        pPr.set("marL", "0")
        pPr.set("indent", "0")
        etree.SubElement(pPr, qn("a:buNone"))


def add_textbox(slide, x, y, w, h, *, name: str):
    tb = slide.shapes.add_textbox(emu(x), emu(y), emu(w), emu(h))
    tb.name = name
    style_text_frame(tb.text_frame)
    return tb


# ---------------------------------------------------------------------------
# Animation: on-click Appear (entrance preset 1)
# ---------------------------------------------------------------------------
def add_appear_sequence(slide, clicks: list[list[tuple[int, str]]]) -> None:
    """``clicks`` is a list (one per click) of lists of (shape_id, kind) where kind is 'sp' or 'text'.

    The first shape of a click is a clickEffect; the rest are withEffect so a
    panel and its text appear together.
    """
    if not clicks:
        return
    p = "{%s}" % NS_P
    timing = etree.Element(p + "timing", nsmap={"p": NS_P, "a": NS_A})
    tnLst = etree.SubElement(timing, p + "tnLst")
    par0 = etree.SubElement(tnLst, p + "par")
    ctn_counter = [0]

    def ctn(parent, **attrs):
        ctn_counter[0] += 1
        el = etree.SubElement(parent, p + "cTn", id=str(ctn_counter[0]))
        for k, v in attrs.items():
            el.set(k, v)
        return el

    root = ctn(par0, dur="indefinite", restart="never", nodeType="tmRoot")
    root_children = etree.SubElement(root, p + "childTnLst")
    seq = etree.SubElement(root_children, p + "seq", concurrent="1", nextAc="seek")
    main = ctn(seq, dur="indefinite", nodeType="mainSeq")
    main_children = etree.SubElement(main, p + "childTnLst")
    bld = []
    for click in clicks:
        outer = etree.SubElement(main_children, p + "par")
        o = ctn(outer, fill="hold")
        st = etree.SubElement(o, p + "stCondLst")
        etree.SubElement(st, p + "cond", delay="indefinite")
        oc = etree.SubElement(o, p + "childTnLst")
        inner = etree.SubElement(oc, p + "par")
        i = ctn(inner, fill="hold")
        st2 = etree.SubElement(i, p + "stCondLst")
        etree.SubElement(st2, p + "cond", delay="0")
        ic = etree.SubElement(i, p + "childTnLst")
        for n, (spid, kind) in enumerate(click):
            eff = etree.SubElement(ic, p + "par")
            e = ctn(eff, presetID="1", presetClass="entr", presetSubtype="0", fill="hold", grpId="0",
                    nodeType="clickEffect" if n == 0 else "withEffect")
            est = etree.SubElement(e, p + "stCondLst")
            etree.SubElement(est, p + "cond", delay="0")
            ec = etree.SubElement(e, p + "childTnLst")
            setel = etree.SubElement(ec, p + "set")
            cb = etree.SubElement(setel, p + "cBhvr")
            c = ctn(cb, dur="1", fill="hold")
            cst = etree.SubElement(c, p + "stCondLst")
            etree.SubElement(cst, p + "cond", delay="0")
            tgt = etree.SubElement(cb, p + "tgtEl")
            etree.SubElement(tgt, p + "spTgt", spid=str(spid))
            attrs = etree.SubElement(cb, p + "attrNameLst")
            an = etree.SubElement(attrs, p + "attrName")
            an.text = "style.visibility"
            to = etree.SubElement(setel, p + "to")
            etree.SubElement(to, p + "strVal", val="visible")
            bld.append((spid, kind))
    prev = etree.SubElement(seq, p + "prevCondLst")
    pc = etree.SubElement(prev, p + "cond", evt="onPrev", delay="0")
    pt = etree.SubElement(pc, p + "tgtEl")
    etree.SubElement(pt, p + "sldTgt")
    nxt = etree.SubElement(seq, p + "nextCondLst")
    nc = etree.SubElement(nxt, p + "cond", evt="onNext", delay="0")
    nt = etree.SubElement(nc, p + "tgtEl")
    etree.SubElement(nt, p + "sldTgt")
    bldLst = etree.SubElement(timing, p + "bldLst")
    for spid, kind in bld:
        el = etree.SubElement(bldLst, p + "bldP", spid=str(spid), grpId="0")
        if kind == "sp":
            el.set("animBg", "1")
    sld = slide._element
    for old in sld.findall(qn("p:timing")):
        sld.remove(old)
    ext = sld.find(qn("p:extLst"))
    if ext is not None:
        ext.addprevious(timing)
    else:
        sld.append(timing)

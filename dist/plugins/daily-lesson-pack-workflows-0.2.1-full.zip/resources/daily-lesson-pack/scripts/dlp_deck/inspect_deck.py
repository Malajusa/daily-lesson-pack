"""Render-level inspection of a PPTX against its own rendered PDF.

Geometry audits check where text boxes *are*.  This inspector checks where the
ink *lands*: it locates every shape's text in the rendered PDF (character by
character), then measures the rendered text against its text box, its panel,
its neighbours and the slide edge.  It works on any PPTX, not only decks built
with this package, so it can be used to diagnose a deck produced elsewhere.

Hard failures (block): text outside its text box or panel, text over other text,
text on the slide edge, sizes below the role floor, text scaled by the renderer,
insufficient contrast, empty slide.
Warnings (must be looked at): orphan last line, under-filled panel, low canvas
use, text that could not be located in the render.
"""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

from .tokens import PROFILES, SLIDE_H_IN, SLIDE_W_IN, contrast

EDGE_MARGIN_IN = 0.25
PANEL_CLEAR_FAIL_IN = 0.10
PANEL_CLEAR_WARN_IN = 0.15
BOX_TOL_IN = 0.04
PANEL_TOL_IN = 0.02
SIZE_TOL_PT = 0.6


@dataclass
class ShapeRec:
    name: str
    shape_id: int
    box: tuple[float, float, float, float]     # x, y, w, h (in)
    text: str = ""
    sizes: list[float] = field(default_factory=list)
    colours: list[Optional[str]] = field(default_factory=list)
    bolds: list[bool] = field(default_factory=list)
    fill: Optional[str] = None
    is_panel_candidate: bool = False
    owner: Optional[str] = None
    panel_id: Optional[str] = None
    kind: str = "other"


def _flatten(shapes):
    for sh in shapes:
        if sh.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from _flatten(sh.shapes)
        else:
            yield sh


def _fill_hex(shape) -> Optional[str]:
    try:
        if shape.fill.type == 1:
            return str(shape.fill.fore_color.rgb)
    except Exception:
        return None
    return None


def _read_slide(slide, slide_w_in: float, slide_h_in: float) -> list[ShapeRec]:
    recs: list[ShapeRec] = []
    for sh in _flatten(slide.shapes):
        x, y, w, h = (sh.left or 0) / 914400, (sh.top or 0) / 914400, (sh.width or 0) / 914400, (sh.height or 0) / 914400
        rec = ShapeRec(name=sh.name or "", shape_id=sh.shape_id, box=(x, y, w, h))
        if getattr(sh, "has_text_frame", False) and sh.text_frame.text.strip():
            rec.text = sh.text_frame.text
            for p in sh.text_frame.paragraphs:
                for r in p.runs:
                    if not r.text.strip():
                        continue
                    size = r.font.size.pt if r.font.size else None
                    if size is None and p.font.size:
                        size = p.font.size.pt
                    rec.sizes.append(size if size is not None else 0.0)
                    try:
                        rec.colours.append(str(r.font.color.rgb) if r.font.color and r.font.color.type is not None else None)
                    except Exception:
                        rec.colours.append(None)
                    rec.bolds.append(bool(r.font.bold))
        rec.fill = _fill_hex(sh)
        if rec.fill and sh.shape_type != MSO_SHAPE_TYPE.PICTURE:
            area = w * h
            if area <= 0.92 * slide_w_in * slide_h_in and w >= 0.45 and h >= 0.28:
                rec.is_panel_candidate = True
        if rec.name.startswith("DLP:panel:"):
            rec.kind = "panel"
            rec.panel_id = rec.name[len("DLP:panel:"):].strip()
        elif rec.text:
            rec.kind = "text"
            if "|panel=" in rec.name:
                rec.owner = rec.name.split("|panel=", 1)[1].split("|", 1)[0].strip()
        recs.append(rec)
    return recs


def _norm_chars(s: str) -> str:
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", s))


def _pdf_chars(page):
    """Return (string, per-char list of (bbox, size, baseline_y))."""
    raw = page.get_text("rawdict")
    chars, parts = [], []
    for block in raw.get("blocks", []):
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                size = span.get("size", 0.0)
                for ch in span.get("chars", []):
                    c = ch["c"]
                    n = _norm_chars(c)
                    for sub in n:
                        parts.append(sub)
                        chars.append((tuple(ch["bbox"]), size, ch["origin"][1], span.get("font", "")))
    return "".join(parts), chars


def _union(bboxes):
    x0 = min(b[0] for b in bboxes)
    y0 = min(b[1] for b in bboxes)
    x1 = max(b[2] for b in bboxes)
    y1 = max(b[3] for b in bboxes)
    return x0, y0, x1, y1


def _is_warmup(texts: list[str]) -> bool:
    joined = "\n".join(texts).lower()
    return "warm-up" in joined or "warm up" in joined


def _floor(rec: ShapeRec, profile: dict, warmup: bool, title_like: bool) -> Optional[float]:
    """Role floor in pt for a text shape, or None when the shape is exempt (title/eyebrow)."""
    if title_like:
        return None
    staff = not profile.get("release", True)
    role = rec.name.split("|", 1)[0].lower()
    text = " ".join(rec.text.split()).lower()
    structural = text in {"all", "most", "some", "why", "answer", "model", "we do", "retrieval", "review"}
    if staff:
        if role in ("dlp:label",) or structural:
            return profile["ranges"]["label"][0]
        if role in ("dlp:instruction", "dlp:explanation", "dlp:cue", "dlp:why"):
            return profile["ranges"]["support"][0]
        return profile["ranges"]["body"][0]
    if role == "dlp:label" or structural:
        return 22.0
    if role in ("dlp:instruction", "dlp:explanation", "dlp:cue", "dlp:why"):
        return 28.0
    return 36.0 if warmup else 24.0


def inspect_deck(pptx_path: Path, pdf_path: Path, *, profile_name: str = "classroom", png_dir: Optional[Path] = None) -> dict:
    try:
        import pymupdf as fitz
    except ImportError:  # PyMuPDF < 1.24.3
        import fitz
    profile = PROFILES[profile_name]
    prs = Presentation(str(pptx_path))
    slide_w_in = prs.slide_width / 914400
    slide_h_in = prs.slide_height / 914400
    doc = fitz.open(str(pdf_path))
    report: dict = {"deck": str(pptx_path), "pdf": str(pdf_path), "artifact_sha256": hashlib.sha256(Path(pptx_path).read_bytes()).hexdigest(),
                    "profile": profile_name, "slides": [], "fonts_in_render": [], "summary": {}}
    issues_total_fail = issues_total_warn = 0
    fonts: dict[str, int] = {}
    if len(doc) != len(prs.slides):
        report["status"] = "FAIL"
        report["error"] = f"Render has {len(doc)} pages but the deck has {len(prs.slides)} slides"
        return report

    for index, (slide, page) in enumerate(zip(prs.slides, doc), 1):
        recs = _read_slide(slide, slide_w_in, slide_h_in)
        scale = 1.0 / 72.0 * (page.rect.width / (slide_w_in * 72.0))  # pt -> in (page may be scaled)
        sstr_all, chars_all = _pdf_chars(page)
        # bullet glyphs are drawn by the renderer but are not part of the shape text
        keep = [k for k, ch in enumerate(sstr_all) if ch != "•"]
        sstr = "".join(sstr_all[k] for k in keep)
        chars = [chars_all[k] for k in keep]
        for c in chars:
            fonts[c[3]] = fonts.get(c[3], 0) + 1
        issues: list[dict] = []
        texts = [r for r in recs if r.text]
        warmup = _is_warmup([r.text for r in texts])
        panels = [r for r in recs if r.is_panel_candidate]
        explicit_panels = {r.panel_id: r for r in recs if r.kind == "panel"}
        located: list[tuple[ShapeRec, tuple[float, float, float, float], list]] = []
        cursor = 0
        for rec in texts:
            target = _norm_chars(rec.text).replace("•", "")
            if not target:
                continue
            pos = sstr.find(target, cursor)
            if pos < 0:
                pos = sstr.find(target)
            if pos < 0:
                issues.append(_issue("warn", "text_not_located_in_render", rec,
                                     "Could not locate this text in the rendered page (glyph substitution or clipping); check the PNG by eye."))
                continue
            cursor = pos + len(target)
            matched = chars[pos:pos + len(target)]
            ub = _union([m[0] for m in matched])
            ub_in = (ub[0] * scale, ub[1] * scale, ub[2] * scale, ub[3] * scale)
            located.append((rec, ub_in, matched))

            x, y, w, h = rec.box
            title_like = (y < slide_h_in * 0.16 and h < slide_h_in * 0.18 and not rec.name.lower().startswith("dlp:"))
            # 1) text vs its own box
            if (ub_in[3] > y + h + BOX_TOL_IN or ub_in[1] < y - BOX_TOL_IN or
                    ub_in[2] > x + w + BOX_TOL_IN or ub_in[0] < x - BOX_TOL_IN):
                issues.append(_issue("fail", "text_outside_text_box", rec,
                                     f"Rendered text spans x {ub_in[0]:.2f}-{ub_in[2]:.2f}, y {ub_in[1]:.2f}-{ub_in[3]:.2f} in; "
                                     f"its box is x {x:.2f}-{x + w:.2f}, y {y:.2f}-{y + h:.2f}. Enlarge the box/panel, shorten or split."))
            # 2) panel containment of the rendered ink
            panel = None
            if rec.owner and rec.owner in explicit_panels:
                panel = explicit_panels[rec.owner]
            else:
                cx, cy = (ub_in[0] + ub_in[2]) / 2, (ub_in[1] + ub_in[3]) / 2
                best = None
                for cand in panels:
                    if cand is rec:
                        continue
                    px, py, pw, ph = cand.box
                    if px <= cx <= px + pw and py <= cy <= py + ph:
                        if best is None or pw * ph < best.box[2] * best.box[3]:
                            best = cand
                panel = best
                if panel is None and rec.is_panel_candidate:
                    panel = rec
            if panel is not None:
                px, py, pw, ph = panel.box
                clear = {"left": ub_in[0] - px, "top": ub_in[1] - py, "right": px + pw - ub_in[2], "bottom": py + ph - ub_in[3]}
                worst_edge, worst = min(clear.items(), key=lambda kv: kv[1])
                if worst < -PANEL_TOL_IN:
                    issues.append(_issue("fail", "text_escapes_panel", rec,
                                         f"Rendered text crosses the {worst_edge} edge of panel {panel.name!r} by {-worst:.2f} in. "
                                         "Enlarge/reflow the panel, shorten the text or split the slide (do not shrink below the role floor)."))
                elif worst < PANEL_CLEAR_FAIL_IN:
                    issues.append(_issue("fail", "text_touches_panel_edge", rec,
                                         f"Rendered text is only {worst:.2f} in from the {worst_edge} edge of {panel.name!r} (minimum {PANEL_CLEAR_FAIL_IN:.2f} in; target 0.15-0.25 in)."))
                elif worst < PANEL_CLEAR_WARN_IN:
                    issues.append(_issue("warn", "tight_panel_padding", rec,
                                         f"Rendered text is {worst:.2f} in from the {worst_edge} edge of {panel.name!r}; target 0.15-0.25 in."))
            # 3) slide edge (page markers are exempt)
            page_marker = rec.text.strip().isdigit() and y > slide_h_in * 0.82
            if not page_marker:
                if (ub_in[0] < 0.05 or ub_in[2] > slide_w_in - 0.05 or ub_in[1] < 0.02 or ub_in[3] > slide_h_in - 0.02):
                    issues.append(_issue("fail", "text_off_slide", rec, "Rendered text touches or crosses the slide boundary."))
                elif (ub_in[0] < EDGE_MARGIN_IN or ub_in[2] > slide_w_in - EDGE_MARGIN_IN or ub_in[1] < 0.08 or
                      ub_in[3] > slide_h_in - 0.12):
                    issues.append(_issue("warn", "text_near_slide_edge", rec,
                                         f"Rendered text is within {EDGE_MARGIN_IN:.2f} in of the slide edge; keep projected content inside the safe area."))
            # 4) size floors (from the file)
            floor = None if page_marker else _floor(rec, profile, warmup, title_like)
            if floor is not None and rec.sizes:
                smallest = min(rec.sizes)
                if smallest == 0.0:
                    issues.append(_issue("fail", "font_size_unknown", rec, "Run has no explicit size; set sizes explicitly on every run."))
                elif smallest + 1e-6 < floor:
                    issues.append(_issue("fail", "below_role_floor", rec, f"Smallest run is {smallest:g} pt; floor for this role is {floor:g} pt."))
            # 5) renderer scaled the text?
            declared = sorted(set(round(s, 1) for s in rec.sizes if s))
            rendered = sorted(set(round(m[1], 1) for m in matched))
            if declared and any(all(abs(r - d) > SIZE_TOL_PT for d in declared) for r in rendered):
                issues.append(_issue("fail", "render_font_size_differs", rec,
                                     f"Declared sizes {declared} but rendered sizes {rendered}: the renderer shrank or scaled the text."))
            # 6) orphan last line
            baselines = sorted({round(m[2], 0) for m in matched})
            if len(baselines) >= 2 and rec.kind == "text" and len(target) > 24:
                last = [(k, m) for k, m in enumerate(matched) if round(m[2], 0) == baselines[-1]]
                last_chars = "".join(sstr[pos + k] for k, _ in last)
                lb = _union([m[0] for _, m in last])
                width_ratio = ((lb[2] - lb[0]) * scale) / max(0.01, w)
                if len(last_chars) <= 9 and width_ratio < 0.25:
                    issues.append(_issue("warn", "orphan_last_line", rec,
                                         f"Last line is only {last_chars!r}; rebalance the wording or the panel width."))
            # 7) contrast
            bg = slide_bg_hex(slide, prs)
            fill_for_text = panel.fill if panel is not None and panel.fill else bg
            for col, size, bold in zip(rec.colours, rec.sizes, rec.bolds):
                if col and fill_for_text:
                    need = 3.0 if (size >= 24 or (bold and size >= 18.66)) else 4.5
                    ratio = contrast(col, fill_for_text)
                    if ratio < need:
                        issues.append(_issue("fail", "low_contrast", rec, f"Text colour {col} on {fill_for_text} is {ratio:.2f}:1 (needs {need:g}:1)."))
                        break

        # 8) overlaps between different text shapes (rendered ink)
        for i in range(len(located)):
            for j in range(i + 1, len(located)):
                a, b = located[i][1], located[j][1]
                ix = min(a[2], b[2]) - max(a[0], b[0])
                iy = min(a[3], b[3]) - max(a[1], b[1])
                if ix > 0.02 and iy > 0.02:
                    small = min((a[2] - a[0]) * (a[3] - a[1]), (b[2] - b[0]) * (b[3] - b[1]))
                    if ix * iy > 0.05 * small:
                        issues.append(_issue("fail", "text_overlaps_text", located[i][0],
                                             f"Rendered text overlaps {located[j][0].name!r} ({ix:.2f} x {iy:.2f} in)."))
        # 9) canvas use + blank check
        body_panels = [r for r in panels if r.box[1] > 0.9 and r.box[2] < slide_w_in * 0.98]
        covered = sum(r.box[2] * r.box[3] for r in body_panels)
        body_area = (slide_w_in - 1.0) * (slide_h_in - 1.4)
        coverage = min(1.0, covered / body_area) if body_area else 0.0
        if texts and coverage < 0.40 and not any(r.name.lower().startswith("title") for r in recs if r.box[1] > 1.5):
            issues.append({"severity": "warn", "code": "low_canvas_use", "shape": "(slide)",
                           "message": f"Filled panels cover only {coverage:.0%} of the body region; check whether content could be larger or reflowed."})
        ink = _ink_fraction(page)
        if ink < 0.01:
            issues.append({"severity": "fail", "code": "near_blank_slide", "shape": "(slide)", "message": f"Only {ink:.1%} of the slide has ink."})
        fails = sum(i["severity"] == "fail" for i in issues)
        warns = sum(i["severity"] == "warn" for i in issues)
        issues_total_fail += fails
        issues_total_warn += warns
        report["slides"].append({"slide": index, "status": "FAIL" if fails else ("WARN" if warns else "PASS"), "warmup": warmup,
                                 "text_shapes": len(texts), "located": len(located), "panel_coverage": round(coverage, 3),
                                 "ink_fraction": round(ink, 3), "issues": issues})
    report["fonts_in_render"] = sorted(fonts, key=lambda k: -fonts[k])[:6]
    report["summary"] = {"slides": len(prs.slides), "fail": issues_total_fail, "warn": issues_total_warn,
                         "slides_failing": sum(s["status"] == "FAIL" for s in report["slides"]),
                         "slides_with_warnings": sum(s["status"] == "WARN" for s in report["slides"])}
    report["status"] = "FAIL" if issues_total_fail else ("WARN" if issues_total_warn else "PASS")
    return report


def slide_bg_hex(slide, prs) -> Optional[str]:
    try:
        fill = slide.background.fill
        if fill.type == 1:
            return str(fill.fore_color.rgb)
    except Exception:
        pass
    try:
        bg = prs.slide_master._element.xpath(".//p:bg//a:srgbClr/@val")
        if bg:
            return bg[0]
    except Exception:
        pass
    return "FFFFFF"


def _issue(sev: str, code: str, rec: ShapeRec, message: str) -> dict:
    return {"severity": sev, "code": code, "shape": rec.name, "shape_id": rec.shape_id, "text": " ".join(rec.text.split())[:80], "message": message}


def _ink_fraction(page) -> float:
    try:
        import pymupdf as fitz
    except ImportError:  # PyMuPDF < 1.24.3
        import fitz
    pix = page.get_pixmap(matrix=fitz.Matrix(0.2, 0.2), alpha=False)
    data = pix.samples
    n = pix.width * pix.height
    if n == 0:
        return 0.0
    step = pix.n
    sample = ((pix.height // 2) * pix.width + (pix.width - 2)) * step     # right margin = slide background
    bg = data[sample:sample + 3]
    count = 0
    for i in range(0, n * step, step):
        if abs(data[i] - bg[0]) + abs(data[i + 1] - bg[1]) + abs(data[i + 2] - bg[2]) > 24:
            count += 1
    return count / n


def format_report(report: dict, *, show_warnings: bool = True) -> str:
    lines = []
    if report.get("error"):
        return "FAIL " + report["error"]
    s = report["summary"]
    lines.append(f"INSPECT {report['status']}: {s['slides']} slides, {s['fail']} failures on {s['slides_failing']} slides, {s['warn']} warnings")
    lines.append(f"render fonts: {', '.join(report['fonts_in_render'])}")
    for sl in report["slides"]:
        for it in sl["issues"]:
            if it["severity"] == "warn" and not show_warnings:
                continue
            lines.append(f"  slide {sl['slide']:>2} {it['severity'].upper():4} {it['code']}: {it['shape']} - {it['message']}")
    return "\n".join(lines)

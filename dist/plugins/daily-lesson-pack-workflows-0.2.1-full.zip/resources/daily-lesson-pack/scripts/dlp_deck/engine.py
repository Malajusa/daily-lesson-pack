"""Content-aware layout engine.

The standards say *the container must fit the content*.  This engine does that:

1. Content declares an instructional role (``main``, ``question``, ``body``,
   ``support``, ``label``).  Each role has a size range (the floor is a hard
   floor).
2. All panels on a slide share one interpolation parameter ``t`` in [0, 1] that
   maps every role to a size inside its range, so sibling cards always match and
   the hierarchy between roles is preserved.
3. The engine finds the largest ``t`` for which every band of panels fits in the
   body region, using measured wrapped text height (not a guess).
4. Spare height is handed to the bands that need it (capped, so a short answer
   does not sit in a giant empty box) and any remainder is centred.
5. If even ``t = 0`` (every role at its floor) does not fit, the engine reports
   a ``FitFailure`` with the numbers and the repair order from the standards.
   It never shrinks below a floor and never lets text leave its panel.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from . import metrics
from .metrics import Para, Measure, snap
from .tokens import FRAME, PROFILES

SLACK_IN = 0.05            # extra height per text box so the last line never kisses the edge
MIN_BLOCK_GAP_IN = 0.14


# ---------------------------------------------------------------------------
# Specification objects
# ---------------------------------------------------------------------------
@dataclass
class Block:
    style: str                         # main | question | body | support | label | num
    paras: list[Para]
    text: str                          # exact visible text (for bindings and reports)
    ref: Optional[tuple[str, str]] = None
    dlp_role: Optional[str] = None     # main|instruction|explanation|cue|why|label
    align: str = "auto"                # l | ctr | r | auto
    bold: Optional[bool] = None        # None = style default
    color: Optional[str] = None        # None = panel ink, 'accent' = role accent text, or hex
    image: Optional[dict] = None       # {"path", "alt", "aspect", "max_h_in"}
    name: Optional[str] = None
    fixed_pt: Optional[float] = None   # exact size (must still respect the floor)


@dataclass
class PanelSpec:
    id: str
    role: str
    blocks: list[Block]
    accent: Optional[str] = "bar"      # 'bar' (left accent strip) or None
    reveal: Optional[int] = None       # on-click appear order
    valign: str = "middle"
    pad_x: Optional[float] = None
    pad_y: Optional[float] = None
    ink: Optional[str] = None
    decorative: bool = False           # draw no panel, only the blocks (rare)


@dataclass
class Band:
    panels: list[PanelSpec]
    widths: Optional[list[float]] = None
    weight: float = 1.0
    cap: float = 1.9                   # max growth relative to content height
    min_h_in: float = 0.0
    fixed_h_in: Optional[float] = None


@dataclass
class PlacedBlock:
    block: Block
    x: float
    y: float
    w: float
    h: float
    size_pt: float
    measure: Optional[Measure]
    align: str
    anchor: str = "middle"             # vertical anchor inside the text box


@dataclass
class PlacedPanel:
    spec: PanelSpec
    x: float
    y: float
    w: float
    h: float
    blocks: list[PlacedBlock]
    content_h: float = 0.0


@dataclass
class FitFailure:
    code: str
    message: str
    required_h_in: float
    available_h_in: float
    detail: list[dict] = field(default_factory=list)


@dataclass
class Solution:
    ok: bool
    t: float = 0.0
    sizes: dict = field(default_factory=dict)
    panels: list[PlacedPanel] = field(default_factory=list)
    band_heights: list[float] = field(default_factory=list)
    needed_h_in: float = 0.0
    available_h_in: float = 0.0
    occupancy: float = 0.0
    failure: Optional[FitFailure] = None
    warnings: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Sizing helpers
# ---------------------------------------------------------------------------
def style_range(style: str, profile: dict, warmup: bool) -> tuple[float, float]:
    lo, hi = profile["ranges"][style]
    if warmup and style in ("main", "question"):
        lo = max(lo, profile.get("warmup_main_floor", lo))
        hi = max(hi, lo)
    return lo, hi


def size_for(style: str, t: float, profile: dict, warmup: bool) -> float:
    lo, hi = style_range(style, profile, warmup)
    return max(lo, snap(lo + t * (hi - lo)))


def is_bold(block: Block, profile: dict) -> bool:
    if block.bold is not None:
        return block.bold
    return bool(profile["bold"].get(block.style, False))


def pad_x_for(panel: "PanelSpec", panel_w: float) -> float:
    """Horizontal padding: the exemplar's generous 0.34 in on wide panels, 0.24 in on narrow cards (>= 0.15 required)."""
    if panel.pad_x is not None:
        return panel.pad_x
    return FRAME["pad_x"] if panel_w >= 6.0 else 0.24


def _inner_w(panel_w: float, pad_x: float) -> float:
    return panel_w - 2 * pad_x - 2 * FRAME["text_inset_in"]


def block_height(block: Block, size_pt: float, inner_w: float, profile: dict) -> tuple[float, Optional[Measure]]:
    if block.image:
        aspect = float(block.image.get("aspect", 1.5))
        h = min(float(block.image.get("max_h_in", 3.0)), inner_w / aspect)
        return h, None
    meas = metrics.measure(block.paras, size_pt, inner_w, default_bold=is_bold(block, profile))
    return meas.height_in + 2 * FRAME["text_inset_in"] + SLACK_IN, meas


def _gap_in(next_size_pt: float) -> float:
    return max(MIN_BLOCK_GAP_IN, FRAME["block_gap_em"] * next_size_pt / 72.0)


def panel_content_height(panel: PanelSpec, w: float, sizes: dict, profile: dict, warmup: bool, t: float) -> float:
    pad_x = pad_x_for(panel, w)
    inner_w = _inner_w(w, pad_x)
    total, count = 0.0, 0
    for blk in panel.blocks:
        size = blk.fixed_pt or sizes[blk.style]
        h, _ = block_height(blk, size, inner_w, profile)
        if count:
            total += _gap_in(size)
        total += h
        count += 1
    return total


def panel_needed_height(panel: PanelSpec, w: float, sizes: dict, profile: dict, warmup: bool, t: float) -> float:
    pad_y = panel.pad_y if panel.pad_y is not None else FRAME["pad_y"]
    return panel_content_height(panel, w, sizes, profile, warmup, t) + 2 * pad_y


def band_widths(band: Band, region_w: float, gap_x: float) -> list[float]:
    n = len(band.panels)
    weights = band.widths or [1.0] * n
    usable = region_w - gap_x * (n - 1)
    total = float(sum(weights))
    return [usable * w / total for w in weights]


# ---------------------------------------------------------------------------
# Solver
# ---------------------------------------------------------------------------
def solve(bands: list[Band], region: tuple[float, float, float, float], *, profile_name: str = "classroom",
          warmup: bool = False, gap_x: Optional[float] = None, gap_y: Optional[float] = None) -> Solution:
    """Lay out ``bands`` (rows of side-by-side panels) inside ``region`` = (x, y, w, h) inches."""
    profile = PROFILES[profile_name]
    x0, y0, rw, rh = region
    gx = FRAME["gap_x"] if gap_x is None else gap_x
    gy = FRAME["gap_y"] if gap_y is None else gap_y
    styles = sorted({b.style for band in bands for p in band.panels for b in p.blocks if not b.image})

    def sizes_at(t: float) -> dict:
        return {s: size_for(s, t, profile, warmup) for s in styles}

    def band_needed(band: Band, sizes: dict, t: float) -> float:
        if band.fixed_h_in is not None:
            return band.fixed_h_in
        widths = band_widths(band, rw, gx)
        need = max(panel_needed_height(p, w, sizes, profile, warmup, t) for p, w in zip(band.panels, widths))
        return max(need, band.min_h_in)

    def total_needed(t: float) -> tuple[float, list[float], dict]:
        sizes = sizes_at(t)
        needs = [band_needed(b, sizes, t) for b in bands]
        return sum(needs) + gy * (len(bands) - 1), needs, sizes

    total0, needs0, sizes0 = total_needed(0.0)
    if total0 > rh + 1e-6:
        detail = []
        for bi, (band, need) in enumerate(zip(bands, needs0)):
            widths = band_widths(band, rw, gx)
            for p, w in zip(band.panels, widths):
                h = panel_needed_height(p, w, sizes0, profile, warmup, 0.0)
                detail.append({"band": bi, "panel": p.id, "needs_in": round(h, 2),
                               "width_in": round(w, 2),
                               "text": " / ".join(b.text[:70] for b in p.blocks if not b.image)})
        detail.sort(key=lambda d: -d["needs_in"])
        fail = FitFailure(
            code="content_does_not_fit_at_floor_size",
            message=(f"Content needs {total0:.2f} in of body height at the minimum role sizes "
                     f"{ {k: v for k, v in sizes0.items()} } but only {rh:.2f} in is available. "
                     "Repair in this order: shorten wording, remove duplicated text, merge or enlarge "
                     "panels, reduce margins, split across slides. Do not shrink below the role floor."),
            required_h_in=total0, available_h_in=rh, detail=detail)
        return Solution(ok=False, t=0.0, sizes=sizes0, needed_h_in=total0, available_h_in=rh, failure=fail)

    # largest feasible t (bisection, then a short downward walk for non-monotonic wraps)
    lo, hi = 0.0, 1.0
    if total_needed(1.0)[0] <= rh + 1e-6:
        best = 1.0
    else:
        for _ in range(28):
            mid = (lo + hi) / 2
            if total_needed(mid)[0] <= rh + 1e-6:
                lo = mid
            else:
                hi = mid
        best = lo
    # prefer a size with no orphan last line if one is available within 2 pt of the maximum
    best = _avoid_orphans(bands, best, total_needed, rh, sizes_at, rw, gx, profile, warmup)
    total, needs, sizes = total_needed(best)
    while total > rh + 1e-6 and best > 0:
        best = max(0.0, best - 0.01)
        total, needs, sizes = total_needed(best)

    # distribute spare height
    spare = rh - total
    heights = list(needs)
    caps = [needs[i] * bands[i].cap if bands[i].fixed_h_in is None else needs[i] for i in range(len(bands))]
    weights = [(bands[i].weight * needs[i]) if bands[i].fixed_h_in is None else 0.0 for i in range(len(bands))]
    for _ in range(8):
        if spare <= 1e-4:
            break
        room = [max(0.0, caps[i] - heights[i]) if weights[i] > 0 else 0.0 for i in range(len(bands))]
        active = [i for i in range(len(bands)) if room[i] > 1e-4]
        if not active:
            break
        wsum = sum(weights[i] for i in active)
        used = 0.0
        for i in active:
            add = min(room[i], spare * weights[i] / wsum)
            heights[i] += add
            used += add
        spare -= used
    offset = max(0.0, spare) / 2.0 if spare > 0.05 else 0.0

    placed: list[PlacedPanel] = []
    y = y0 + offset
    text_area = 0.0
    for bi, band in enumerate(bands):
        widths = band_widths(band, rw, gx)
        x = x0
        for p, w in zip(band.panels, widths):
            pp = _place_panel(p, x, y, w, heights[bi], sizes, profile, warmup, best)
            placed.append(pp)
            for pb in pp.blocks:
                text_area += pb.w * (pb.measure.height_in if pb.measure else pb.h)
            x += w + gx
        y += heights[bi] + gy
    occupancy = sum(pp.w * pp.h for pp in placed) / (rw * rh) if rw * rh else 0.0
    warnings = []
    for pp in placed:
        inner_h = pp.h - 2 * (pp.spec.pad_y if pp.spec.pad_y is not None else FRAME["pad_y"])
        if inner_h > 0 and pp.content_h / inner_h < 0.45 and best >= 0.999:
            warnings.append(f"panel {pp.spec.id!r} uses only {pp.content_h / inner_h:.0%} of its height at the maximum role size")
    return Solution(ok=True, t=best, sizes=sizes, panels=placed, band_heights=heights,
                    needed_h_in=total, available_h_in=rh, occupancy=occupancy, warnings=warnings)


def _avoid_orphans(bands, best, total_needed, rh, sizes_at, rw, gx, profile, warmup):
    """If the best size leaves a one-word last line, try up to 2 pt smaller."""
    def has_orphan(t: float) -> bool:
        sizes = sizes_at(t)
        for band in bands:
            widths = band_widths(band, rw, gx)
            for p, w in zip(band.panels, widths):
                pad_x = pad_x_for(p, w)
                inner_w = _inner_w(w, pad_x)
                for blk in p.blocks:
                    if blk.image or blk.style in ("label", "num"):
                        continue
                    meas = metrics.measure(blk.paras, blk.fixed_pt or sizes[blk.style], inner_w,
                                           default_bold=is_bold(blk, profile))
                    if meas.orphan and len(blk.text) > 24:
                        return True
        return False

    if best <= 0 or not has_orphan(best):
        return best
    step = 0.02
    t = best
    for _ in range(6):
        t = max(0.0, t - step)
        if total_needed(t)[0] <= rh + 1e-6 and not has_orphan(t):
            return t
    return best


def _place_panel(p: PanelSpec, x: float, y: float, w: float, h: float, sizes: dict, profile: dict,
                 warmup: bool, t: float) -> PlacedPanel:
    pad_x = pad_x_for(p, w)
    pad_y = p.pad_y if p.pad_y is not None else FRAME["pad_y"]
    inner_w = _inner_w(w, pad_x)
    inset = FRAME["text_inset_in"]
    n = len(p.blocks)
    heights, measures, block_sizes = [], [], []
    for blk in p.blocks:
        size = blk.fixed_pt or sizes.get(blk.style, 0.0)
        bh, meas = block_height(blk, size, inner_w, profile)
        heights.append(bh)
        measures.append(meas)
        block_sizes.append(size)
    gaps = [_gap_in(block_sizes[i]) for i in range(1, n)]
    content = sum(heights) + sum(gaps)
    inner_h = h - 2 * pad_y
    placed: list[PlacedBlock] = []
    left = x + pad_x
    if n == 1:
        blk = p.blocks[0]
        bh = heights[0]
        # one block: the text box fills the padded interior and the renderer centres it,
        # so a late re-wrap in a different font can never push text out of the panel
        box_h = inner_h
        top = y + pad_y
        anchor = "middle" if p.valign == "middle" else "top"
        if blk.image:
            box_h = bh
            top = y + pad_y + max(0.0, (inner_h - bh) / 2)
        pb = PlacedBlock(blk, left, top, inner_w + 2 * inset, box_h, block_sizes[0], measures[0],
                         _resolve_align(blk, measures[0]), anchor)
        _balance(pb, inner_w, inset, profile)
        placed.append(pb)
    else:
        free = max(0.0, inner_h - content)
        top = y + pad_y + (free / 2 if p.valign == "middle" else 0.0)
        cy = top
        for i, blk in enumerate(p.blocks):
            if i:
                cy += gaps[i - 1]
            pb = PlacedBlock(blk, left, cy, inner_w + 2 * inset, heights[i], block_sizes[i],
                             measures[i], _resolve_align(blk, measures[i]), "middle")
            _balance(pb, inner_w, inset, profile)
            if i == n - 1 and p.valign == "top":
                # the last text box runs to the bottom of the padded interior (anchored top)
                pb.h = max(pb.h, (y + h - pad_y) - cy)
                pb.anchor = "top"
            placed.append(pb)
            cy += heights[i]
    return PlacedPanel(p, x, y, w, h, placed, content_h=content)


def _balance(pb: PlacedBlock, inner_w: float, inset: float, profile: dict) -> None:
    """Narrow the text box a little when the last line would be a lone short word (classic balanced wrap)."""
    blk, meas = pb.block, pb.measure
    if meas is None or not meas.orphan or blk.style in ("label", "num") or len(blk.text) <= 24:
        return
    lines = meas.n_lines
    full_x, full_w = pb.x, pb.w
    for k in range(1, 9):
        w2 = inner_w * (1 - 0.04 * k)
        m2 = metrics.measure(blk.paras, pb.size_pt, w2, default_bold=is_bold(blk, profile))
        if m2.n_lines > lines:
            return
        if not m2.orphan:
            pb.w = w2 + 2 * inset
            pb.measure = m2
            if pb.align == "ctr":
                pb.x = full_x + (full_w - pb.w) / 2
            return


def _resolve_align(blk: Block, meas: Optional[Measure]) -> str:
    if blk.align in ("l", "ctr", "r"):
        return blk.align
    if meas is None:
        return "ctr"
    if blk.style in ("main", "question", "num") and meas.n_lines <= 1:
        return "ctr"
    if blk.style == "label":
        return "l"
    return "l"


# ---------------------------------------------------------------------------
# Title / eyebrow fitting
# ---------------------------------------------------------------------------
def fit_title(text: str, width_in: float, profile_name: str = "classroom") -> tuple[float, int, float]:
    """Return (size_pt, n_lines, box_height_in).  Prefer one line at 30 pt down to 26 pt, then two lines."""
    lo, hi = PROFILES[profile_name]["title"]
    inset = FRAME["text_inset_in"]
    inner = width_in - 2 * inset
    para = [Para([metrics.Run(text)])]
    size = hi
    while size >= lo - 1e-9:
        m = metrics.measure(para, size, inner, default_bold=True)
        if m.n_lines == 1:
            return size, 1, FRAME["title_line_h_in"]
        size -= 1.0
    # two lines at the lower end of the range
    size = lo
    m = metrics.measure(para, size, inner, default_bold=True)
    if m.n_lines == 2:
        return size, 2, m.height_in + 2 * inset + 0.12
    return size, m.n_lines, m.height_in + 2 * inset + 0.12


def fit_eyebrow(text: str, width_in: float, size_pt: float = FRAME["eyebrow_pt"]) -> tuple[float, bool]:
    inner = width_in - 2 * FRAME["text_inset_in"]
    para = [Para([metrics.Run(text)])]
    size = size_pt
    while size >= 14.0:
        m = metrics.measure(para, size, inner, default_bold=True)
        if m.n_lines == 1:
            return size, True
        size -= 1.0
    return 14.0, False

"""Design tokens for the Daily Lesson Pack deck system.

Everything visual lives here so that a slide never invents a colour, a size or a
margin.  The default theme (``dlp``) and frame (``rail``) reproduce the approved
visual exemplar (full-height role rail, uppercase eyebrow, bold plain-language
title, role-coloured panels, Trebuchet MS).  Other themes/frames exist for
non-lesson decks (for example staff PD) and are never used for a Daily Lesson
Pack release.
"""
from __future__ import annotations

FONT = "Trebuchet MS"
SLIDE_W_IN = 13.333
SLIDE_H_IN = 7.5
EMU_PER_IN = 914400

# ---------------------------------------------------------------------------
# Roles
# ---------------------------------------------------------------------------
ROLE_NAMES = ("amber", "blue", "green", "neutral", "dark")

# What each role means in the approved grammar.  The label is what the eyebrow
# says so that colour is never the only carrier of meaning.
ROLE_MEANING = {
    "amber": "Reminder / teacher model / rule",
    "blue": "Question / student task / reading passage",
    "green": "Answer / successful model / success evidence",
    "neutral": "Concise cue, evidence, definition or secondary direction",
    "dark": "Strong emphasis panel (non-lesson decks only)",
}

# ---------------------------------------------------------------------------
# Themes.  ``fill``/``line`` colour a panel, ``strong`` colours the rail and
# accent bars, ``ink`` is the text colour *on the panel fill* and ``accent_text``
# is the text colour used for coloured words *on the slide background*.
# Contrast of every pair is asserted in tests (>= 4.5:1 for text).
# ---------------------------------------------------------------------------
THEMES: dict[str, dict] = {
    "dlp": {
        "label": "Daily Lesson Pack (approved exemplar grammar)",
        "bg": "F8F6F0",
        "ink": "111827",
        "muted": "475569",
        "band": "103A5E",          # header-frame band
        "band_ink": "FFFFFF",
        "band_kicker": "FFE08A",
        "band_rule": "D6A900",
        "roles": {
            "amber": dict(fill="FFF3BF", line="D6A900", strong="D6A900", ink="111827", accent_text="7A5C00"),
            "blue": dict(fill="EAF2F8", line="7AA7C7", strong="005A9C", ink="111827", accent_text="005A9C"),
            "green": dict(fill="EAF7EE", line="70A77C", strong="1B7F3A", ink="111827", accent_text="1B7F3A"),
            "neutral": dict(fill="FFFFFF", line="CBD5E1", strong="103A5E", ink="111827", accent_text="103A5E"),
            "dark": dict(fill="103A5E", line="103A5E", strong="103A5E", ink="FFFFFF", accent_text="103A5E"),
        },
        "lesson_release_ok": True,
    },
    "green": {
        "label": "Green and off-white (staff / community decks)",
        "bg": "F7F5EC",
        "ink": "14231A",
        "muted": "4A5A50",
        "band": "14452F",
        "band_ink": "FFFFFF",
        "band_kicker": "A8D98F",
        "band_rule": "A8D98F",
        "roles": {
            "amber": dict(fill="E3F1D3", line="A9D08E", strong="6FA63F", ink="163B22", accent_text="2E5E1E"),
            "blue": dict(fill="F2EEDA", line="CFC8A0", strong="A39A5C", ink="14452F", accent_text="14452F"),
            "green": dict(fill="1B5E3B", line="3F8F5F", strong="2A7D4B", ink="FFFFFF", accent_text="1B6E4A"),
            "neutral": dict(fill="FFFFFF", line="D7DFD3", strong="14452F", ink="14231A", accent_text="14452F"),
            "dark": dict(fill="14452F", line="14452F", strong="14452F", ink="FFFFFF", accent_text="14452F"),
        },
        "lesson_release_ok": False,
    },
    "navy": {
        "label": "Navy and gold (legacy Claude-side header frame)",
        "bg": "F8F6F0",
        "ink": "111827",
        "muted": "475569",
        "band": "103A5E",
        "band_ink": "FFFFFF",
        "band_kicker": "FFE08A",
        "band_rule": "D6A900",
        "roles": {
            "amber": dict(fill="FFF3BF", line="D6A900", strong="D6A900", ink="111827", accent_text="7A5C00"),
            "blue": dict(fill="EAF2F8", line="7AA7C7", strong="005A9C", ink="111827", accent_text="005A9C"),
            "green": dict(fill="EAF7EE", line="70A77C", strong="1B7F3A", ink="111827", accent_text="1B7F3A"),
            "neutral": dict(fill="FFFFFF", line="CBD5E1", strong="103A5E", ink="111827", accent_text="103A5E"),
            "dark": dict(fill="103A5E", line="103A5E", strong="103A5E", ink="FFFFFF", accent_text="103A5E"),
        },
        "lesson_release_ok": False,
    },
}

FRAMES = ("rail", "header")

# ---------------------------------------------------------------------------
# Frame geometry (inches).  Mirrors the approved exemplar.
# ---------------------------------------------------------------------------
FRAME = {
    "rail_w": 0.167,
    "margin_l": 0.62,
    "margin_r": 0.62,
    "eyebrow_y": 0.19,
    "eyebrow_h": 0.42,
    "eyebrow_pt": 18.0,
    "title_y": 0.65,
    "title_line_h_in": 0.54,        # one line at the maximum title size
    "title_pt_max": 30.0,
    "title_pt_min": 26.0,
    "title_gap_after": 0.22,         # between title block and body
    "body_bottom": 6.96,             # lowest allowed edge of body content
    "gap_x": 0.26,                   # between panels in a band
    "gap_y": 0.24,                   # between bands
    "pad_x": 0.34,                   # panel padding, horizontal (>= 0.15 required)
    "pad_y": 0.28,                   # panel padding, vertical   (>= 0.15 required)
    "block_gap_em": 0.42,            # gap between blocks in a panel, in multiples of base size
    "corner_in": 0.167,
    "panel_line_pt": 1.5,
    "text_inset_in": 0.03,           # text-frame inset, keeps glyphs off the box edge
    "header_band_h": 0.0,            # computed per slide for the header frame
}

# ---------------------------------------------------------------------------
# Type scale profiles (points).  ``classroom`` encodes the projected-readability
# standard; ``staff`` is a relaxed scale for decks read in a meeting room.
# The range is (floor, ceiling).  The engine chooses the largest size in the
# range that fits; if the floor does not fit the content must be rewritten,
# reflowed or split - it is never shrunk below the floor.
# ---------------------------------------------------------------------------
PROFILES: dict[str, dict] = {
    "classroom": {
        "label": "Projected classroom teaching (DLP standards)",
        "ranges": {
            "main": (32.0, 54.0),       # main question / answer / key expression
            "question": (32.0, 44.0),
            "body": (28.0, 36.0),       # passage, model, explanation of substance
            "support": (28.0, 34.0),    # instruction, explanation, cue, why
            "label": (22.0, 28.0),      # All / Most / Some, WHY, step heads
            "num": (30.0, 44.0),        # numerals marking steps
        },
        "warmup_main_floor": 36.0,
        "title": (26.0, 30.0),
        "bold": {"main": True, "question": True, "body": False, "support": False, "label": True, "num": True},
        "dlp_roles": {
            "main": "main", "question": "main", "body": "main",
            "support": "explanation", "label": "label", "num": "label",
        },
        "release": True,
    },
    "staff": {
        "label": "Staff / meeting-room presentation",
        "ranges": {
            "main": (22.0, 40.0),
            "question": (20.0, 34.0),
            "body": (16.0, 28.0),
            "support": (14.0, 24.0),
            "label": (12.0, 22.0),
            "num": (22.0, 40.0),
        },
        "warmup_main_floor": 24.0,
        "title": (26.0, 30.0),
        "bold": {"main": True, "question": True, "body": False, "support": False, "label": True, "num": True},
        "dlp_roles": {
            "main": "main", "question": "main", "body": "main",
            "support": "explanation", "label": "label", "num": "label",
        },
        "release": False,
    },
}

# Roles a block may declare for the shape name (``DLP:<role>|panel=<id>``).
DLP_TEXT_ROLES = ("main", "instruction", "explanation", "cue", "why", "label")
# Roles with the 28 pt supporting-text floor in the quality standard.
SUPPORT_DLP_ROLES = ("instruction", "explanation", "cue", "why")

# Minimum text contrast (WCAG): normal text and large text (>= 24 pt, or >= 18.66 pt bold)
MIN_CONTRAST = 4.5
MIN_CONTRAST_LARGE = 3.0


def theme(name: str) -> dict:
    try:
        return THEMES[name]
    except KeyError as exc:
        raise ValueError(f"Unknown theme {name!r}; choose from {sorted(THEMES)}") from exc


def profile(name: str) -> dict:
    try:
        return PROFILES[name]
    except KeyError as exc:
        raise ValueError(f"Unknown type profile {name!r}; choose from {sorted(PROFILES)}") from exc


def hex_to_rgb(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    return int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16)


def _lin(c: float) -> float:
    c = c / 255.0
    return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4


def luminance(value: str) -> float:
    r, g, b = hex_to_rgb(value)
    return 0.2126 * _lin(r) + 0.7152 * _lin(g) + 0.0722 * _lin(b)


def contrast(a: str, b: str) -> float:
    la, lb = luminance(a), luminance(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)

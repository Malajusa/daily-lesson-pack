"""Text measurement without needing the real font installed.

Trebuchet MS is not available on most build hosts, so widths come from baked
Arial-compatible (Liberation Sans) advance tables with a safety factor.  The
model is deliberately conservative: it predicts *at least* as many lines as a
real renderer produces, so a layout that fits in the model fits on screen.
``tests/test_dlp_deck.py`` calibrates the model against a real render.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from pathlib import Path

_DATA = json.loads((Path(__file__).parent / "data" / "widths.json").read_text(encoding="utf-8"))
_DEFAULT_W = _DATA["meta"]["default"]

# Trebuchet MS sets a little wider than Arial for narrow letters (i, l, t, f, r)
# and a little narrower for round ones; net effect is a few per cent.  The extra
# margin also covers kerning-less measurement and bold synthesis.
SAFETY = 1.05
# Natural single line spacing is ~1.16 em for Trebuchet MS and ~1.15 for Arial.
LINE_HEIGHT = 1.2
PARA_GAP_EM = 0.38
BULLET_INDENT_EM = 0.9


@dataclass
class Run:
    text: str
    bold: bool = False
    italic: bool = False
    scale: float = 1.0          # relative to the paragraph base size
    color: str | None = None    # hex, None = block default


@dataclass
class Para:
    runs: list[Run]
    scale: float = 1.0          # relative to the block base size
    bullet: bool = False
    gap_before_em: float | None = None

    @property
    def text(self) -> str:
        return "".join(r.text for r in self.runs)


def char_width(ch: str, bold: bool = False, italic: bool = False) -> float:
    if ch == "\u00a0":          # no-break space is as wide as a space (and never a wrap point)
        ch = " "
    table = _DATA["bold" if bold else ("italic" if italic else "regular")]
    return table.get(ch, _DEFAULT_W) / 1000.0


def text_width_pt(text: str, size_pt: float, bold: bool = False, italic: bool = False,
                  safety: float = SAFETY) -> float:
    return sum(char_width(c, bold, italic) for c in text) * size_pt * safety


@dataclass
class ParaLayout:
    lines: list[str]
    line_widths_pt: list[float]
    height_pt: float
    gap_before_pt: float


@dataclass
class Measure:
    height_pt: float
    paras: list[ParaLayout]
    widest_pt: float
    n_lines: int
    orphan: bool                # last line of a multi-line paragraph is one short word
    base_pt: float

    @property
    def height_in(self) -> float:
        return self.height_pt / 72.0


def _tokens(para: Para):
    """Split a paragraph into (text, bold, italic, scale, glue) tokens.

    Spaces are separate tokens.  Words break after a hyphen like real renderers
    do; the piece after the hyphen is ``glue`` (no space is inserted before it).
    """
    out = []

    def emit_word(word, run):
        pieces = []
        buf = ""
        for i, ch in enumerate(word):
            buf += ch
            if ch == "-" and i + 1 < len(word) and word[i + 1].isalnum() and i > 0 and word[i - 1].isalnum():
                pieces.append(buf)
                buf = ""
        if buf:
            pieces.append(buf)
        for n, piece in enumerate(pieces):
            out.append((piece, run.bold, run.italic, run.scale, n > 0))

    for run in para.runs:
        buf = ""
        for ch in run.text:
            if ch in (" ", "\n"):
                if buf:
                    emit_word(buf, run)
                    buf = ""
                out.append((ch, run.bold, run.italic, run.scale, False))
            else:
                buf += ch
        if buf:
            emit_word(buf, run)
    return out


def wrap_para(para: Para, base_pt: float, width_pt: float, *, default_bold: bool = False,
              safety: float = SAFETY) -> ParaLayout:
    size = base_pt * para.scale
    indent = BULLET_INDENT_EM * size if para.bullet else 0.0
    avail = max(1.0, width_pt - indent)
    lines: list[str] = []
    widths: list[float] = []
    cur, cur_w, cur_scale = "", 0.0, 1.0
    line_scales: list[float] = []
    pending_space = ("", 0.0)

    def flush(force_empty=False):
        nonlocal cur, cur_w, cur_scale
        if cur or force_empty:
            lines.append(cur.rstrip())
            widths.append(cur_w)
            line_scales.append(cur_scale)
        cur, cur_w, cur_scale = "", 0.0, 1.0

    for text, bold, italic, scale, glue in _tokens(para):
        b = bold or default_bold
        if text == "\n":
            flush(force_empty=True)
            pending_space = ("", 0.0)
            continue
        if text == " ":
            w = text_width_pt(" ", size * scale, b, italic, safety)
            if cur:
                pending_space = (" ", w)
            continue
        w = text_width_pt(text, size * scale, b, italic, safety)
        sp, spw = ("", 0.0) if glue else pending_space
        if cur and cur_w + spw + w > avail:
            flush()
            sp, spw = "", 0.0
        if w > avail:
            # very long token: break by characters
            for ch in text:
                cw = text_width_pt(ch, size * scale, b, italic, safety)
                if cur and cur_w + cw > avail:
                    flush()
                cur += ch
                cur_w += cw
                cur_scale = max(cur_scale, scale)
            pending_space = ("", 0.0)
            continue
        cur += sp + text
        cur_w += spw + w
        cur_scale = max(cur_scale, scale)
        pending_space = ("", 0.0)
    flush()
    if not lines:
        lines, widths, line_scales = [""], [0.0], [1.0]
    height = sum(size * s * LINE_HEIGHT for s in line_scales)
    return ParaLayout(lines, widths, height, 0.0)


def measure(paras: list[Para], base_pt: float, width_in: float, *, default_bold: bool = False,
            safety: float = SAFETY) -> Measure:
    width_pt = width_in * 72.0
    layouts = []
    total = 0.0
    widest = 0.0
    n_lines = 0
    for index, para in enumerate(paras):
        lay = wrap_para(para, base_pt, width_pt, default_bold=default_bold, safety=safety)
        gap_em = para.gap_before_em if para.gap_before_em is not None else PARA_GAP_EM
        lay.gap_before_pt = 0.0 if index == 0 else gap_em * base_pt * para.scale
        total += lay.height_pt + lay.gap_before_pt
        widest = max(widest, max(lay.line_widths_pt))
        n_lines += len(lay.lines)
        layouts.append(lay)
    orphan = False
    for lay, para in zip(layouts, paras):
        if len(lay.lines) >= 2:
            last = lay.lines[-1].strip()
            if last and " " not in last and len(last) <= 9:
                orphan = True
    return Measure(total, layouts, widest, n_lines, orphan, base_pt)


def snap(size_pt: float, step: float = 0.5) -> float:
    return math.floor(size_pt / step + 1e-9) * step


def plain_paras(text: str, *, bullets: bool = False, emphasis: list[dict] | None = None) -> list[Para]:
    """Build paragraphs from plain text.

    Newlines separate paragraphs.  ``emphasis`` is a list of
    ``{"text": substring, "bold": bool, "scale": float, "color": "accent"|hex}``
    applied to the first occurrence in each paragraph that contains it.  The
    visible text is never altered, so source bindings stay exact.
    """
    paras = []
    for raw in text.split("\n"):
        runs = _split_runs(raw, emphasis or [])
        paras.append(Para(runs=runs, bullet=bullets))
    return paras


def _split_runs(text: str, emphasis: list[dict]) -> list[Run]:
    spans = []
    for item in emphasis:
        needle = item["text"]
        idx = text.find(needle)
        if idx >= 0 and needle:
            spans.append((idx, idx + len(needle), item))
    spans.sort(key=lambda s: s[0])
    runs, pos = [], 0
    for start, end, item in spans:
        if start < pos:
            continue
        if start > pos:
            runs.append(Run(text[pos:start]))
        runs.append(Run(text[start:end], bold=item.get("bold", True), scale=float(item.get("scale", 1.0)),
                        color=item.get("color", "accent")))
        pos = end
    if pos < len(text):
        runs.append(Run(text[pos:]))
    if not runs:
        runs.append(Run(text))
    return runs

---
name: dlp-shared-reading
description: Generate whole-class Shared Reading as alternating paragraph-and-question slides followed immediately by matched answer slides.
---

# dlp-shared-reading original contract

Read `../../resources/daily-lesson-pack/skills/dlp-shared-reading/SKILL.md` in full before applying this skill. It contains the complete installed workflow, source hierarchy, mandatory checks and scope boundaries. Resolve all of its relative resource and script paths against `../../resources/daily-lesson-pack/skills/dlp-shared-reading/`. The original runtime tree, registry, package manifests and source hashes are preserved under `resources/daily-lesson-pack/`.

Follow the full original contract without substituting an ad-hoc generation or release path. This plugin does not install Python packages, rendering tools, an execution adapter, durable classroom storage or independent reviewers. Missing dependencies or evidence remain blocked or unreleased under the original contract; never invent execution or release evidence.

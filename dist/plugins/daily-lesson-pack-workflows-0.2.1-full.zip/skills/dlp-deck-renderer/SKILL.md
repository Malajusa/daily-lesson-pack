---
name: dlp-deck-renderer
description: Build, render and inspect a teaching or staff slide deck (PPTX) from a spec so text fits, panels contain their content and the result matches the Daily Lesson Pack visual exemplar. Use whenever a deck must be created or visually repaired.
---

# dlp-deck-renderer

Read `../../resources/daily-lesson-pack/references/deck-renderer.md` in full before building or fixing any deck. Resolve its relative paths against `../../resources/daily-lesson-pack/`. The orchestrator `SKILL.md` there stays authoritative for content, sequencing, evidence and release.

Do not write slide geometry by hand or with a generic `python-pptx` script. The repository builder measures text, sizes each panel to its content, refuses content that cannot fit at the role floor, renders every slide and inspects the render:

```text
cd ../../resources/daily-lesson-pack
python scripts/dlp_deck_cli.py selftest                      # toolchain present?
python scripts/dlp_deck_cli.py check spec.json --out-dir work
```

Then open `work/contact-sheet.jpg` and each `work/slides/*.png`, look at them, change the **spec** (never the finished PPTX) and repeat until `CHECK PASS` and the slides read well. A `FitFailure` means rewrite, reflow or split the content (repair order in `slide-deck-quality-standards.md`); it never means "use a smaller font".

For a Daily Lesson Pack deck use governed mode (every string a ContentSource reference, theme `dlp`, frame `rail`, profile `classroom`) through `dlp_deck.assembly.build_deck_artifact`. Staff or community decks may use the `green`/`navy` themes, `header` frame and `staff` profile, and must be described as not Daily Lesson Pack release material.

A passing `check` is a screening result. It does not release a pack: release still needs the independent rendered-review evidence bound to the deck hash. If LibreOffice or PyMuPDF is missing, say the deck is unverified; never report an unrendered deck as checked.
